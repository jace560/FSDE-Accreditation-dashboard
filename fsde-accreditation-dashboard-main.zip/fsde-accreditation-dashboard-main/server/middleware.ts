import { getToken } from "next-auth/jwt";
import { NextResponse } from "next/server";
import type { NextRequest } from "next/server";
import { USER_ROLE } from "./types";
import { ROUTES } from "./utils";

export async function middleware(req: NextRequest) {
  const { pathname } = req.nextUrl;
  const token = await getToken({
    req,
    secret: process.env.NEXTAUTH_SECRET,
  });

  // console.log("No token found. Redirecting to login...", token, pathname);

  const publicRoutes = ["/", "/api/auth"];
  if (publicRoutes.includes(pathname)) {
    return NextResponse.next();
  }

  if (!token && !pathname.startsWith("/api/auth")) {
    console.log("No token found. Redirecting to login...", token, pathname);

    if (pathname.startsWith("/api")) {
      return new NextResponse(
        JSON.stringify({ error: "Unauthorized access" }),
        {
          status: 401,
          headers: { "Content-Type": "application/json" },
        }
      );
    } else {
      const redirectUrl = new URL("/", req.url);
      redirectUrl.searchParams.set("message", "login_required");
      return NextResponse.redirect(redirectUrl);
    }
  }

  if (
    token &&
    pathname.startsWith("/admin") &&
    token.Role !== USER_ROLE.ADMIN &&
    token.Role !== USER_ROLE.SUPER_ADMIN
  ) {
    const redirectUrl = new URL("/user-dashboard", req.url);
    redirectUrl.searchParams.set("message", "unauthorized");
    return NextResponse.redirect(redirectUrl);
  }

  const roleMethodRestrictions: Record<USER_ROLE, Record<string, string[]>> = {
    [USER_ROLE.SUPER_ADMIN]: {}, // ✅ Super Admin has full access
    [USER_ROLE.ADMIN]: {
      "/api/admin": ["DELETE", "PUT"],
      "/api/admin/users": ["PUT", "DELETE"],
    },
    [USER_ROLE.USER]: {
      "/api/admin": ["GET", "POST", "PUT", "DELETE"],
      "/api/courses": ["POST", "DELETE"],
      "/api/courses/[courseID]": ["POST", "DELETE"],
      "/api/courses/[courseID]/lo-performance": ["POST", "DELETE"],
      "/api/courses/[courseID]/student-grades": ["POST", "DELETE"],
      "/api/admin/threshold": ["POST"],
    },
  };

  const userRestrictions =
    (token && roleMethodRestrictions[token.Role as USER_ROLE]) || {};
  for (const restrictedRoute in userRestrictions) {
    if (pathname.startsWith(restrictedRoute)) {
      const restrictedMethods = userRestrictions[restrictedRoute];
      if (restrictedMethods.includes(req.method)) {
        console.log(
          `Forbidden ${req.method} request to ${pathname} for role ${
            token && token.Role
          }`
        );
        return new NextResponse(
          JSON.stringify({
            error: `Forbidden: ${req.method} requests to this endpoint require higher access.`,
          }),
          { status: 403, headers: { "Content-Type": "application/json" } }
        );
      }
    }
  }

  return NextResponse.next();
}

export const config = {
  matcher: [
    "/dashboard",
    "/admin",
    "/courses/:path*",
    "/api/:path*",
    "/analytics",
  ],
};
