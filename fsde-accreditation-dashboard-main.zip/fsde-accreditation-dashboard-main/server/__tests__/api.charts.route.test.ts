import { NextRequest } from "next/server";
import { GET } from "../app/api/charts/[chartType]/route";
import prisma from "@/lib/prisma";
import logger from "@/lib/logger";
import { ChartType } from "@/types";

jest.mock("@/lib/prisma");
jest.mock("@/lib/logger");

describe("GET /api/charts/[chartType]", () => {
  const mockRequest = (url: string) => new NextRequest(url);

  beforeEach(() => {
    jest.clearAllMocks();
  });

  it("should return 400 if required query parameters are missing", async () => {
    const req = mockRequest("http://localhost:3000/api/charts/GA_BY_IDA");
    const context = { params: { chartType: ChartType.GA_BY_IDA } };

    const response = await GET(req, context);
    const json = await response.json();

    expect(response.status).toBe(400);
    expect(json.error.message).toBe("programID, campusID, and year are required");
  });

  it("should return 400 if an invalid chartType is requested", async () => {
    const req = mockRequest("http://localhost:3000/api/charts/INVALID?programId=1&campusId=1&year=2023");
    const context = { params: { chartType: "INVALID" as ChartType } };

    const response = await GET(req, context);
    const json = await response.json();

    expect(response.status).toBe(400);
    expect(json.error.message).toBe("Invalid chartType");
  });

  // it("should return 500 if an internal server error occurs", async () => {
  //   const req = mockRequest("http://localhost:3000/api/charts/GA_BY_IDA?programId=1&campusId=1&year=2023");
  //   const context = { params: { chartType: ChartType.GA_BY_IDA } };

  //   (prisma.graduateAttribute.findMany as jest.Mock).mockRejectedValue(new Error("Internal Error"));

  //   const response = await GET(req, context);
  //   const json = await response.json();

  //   expect(response.status).toBe(500);
  //   expect(json.error.message).toBe("Internal Server Error");
  // });

  // it("should return 200 and the correct data for GA_BY_IDA", async () => {
  //   const req = mockRequest("http://localhost:3000/api/charts/GA_BY_IDA?programId=1&campusId=1&year=2023");
  //   const context = { params: { chartType: ChartType.GA_BY_IDA } };

  //   (prisma.graduateAttribute.findMany as jest.Mock).mockResolvedValue([
  //     {
  //       GAName: "GA1",
  //       GANumber: "1",
  //       GAID: "1",
  //       PerformanceIndicatorMappings: [
  //         { PILevel: "I", CourseID: "C1" },
  //         { PILevel: "D", CourseID: "C2" },
  //         { PILevel: "A", CourseID: "C3" },
  //       ],
  //     },
  //   ]);

  //   const response = await GET(req, context);
  //   const json = await response.json();

  //   expect(response.status).toBe(200);
  //   expect(json.data).toEqual({
  //     type: ChartType.GA_BY_IDA,
  //     labels: {
  //       xAxisLabel: "Graduate Attribute",
  //       yAxisLabel: "Number of Courses",
  //       mainTitle: "Number of Courses Used for GA Assessment (by I, D, A Level)",
  //     },
  //     data: [
  //       {
  //         graduateAttribute: "1-GA1",
  //         GAID: "1",
  //         values: [
  //           { label: "I", count: 1, color: "color-for-I" },
  //           { label: "D", count: 1, color: "color-for-D" },
  //           { label: "A", count: 1, color: "color-for-A" },
  //         ],
  //       },
  //     ],
  //   });
  // });

  // it("should return 200 and the correct data for GA_BY_COURSE_LEVEL", async () => {
  //   const req = mockRequest("http://localhost:3000/api/charts/GA_BY_COURSE_LEVEL?programId=1&campusId=1&year=2023");
  //   const context = { params: { chartType: ChartType.GA_BY_COURSE_LEVEL } };

  //   (prisma.graduateAttribute.findMany as jest.Mock).mockResolvedValue([
  //     {
  //       GAName: "GA1",
  //       GANumber: "1",
  //       GAID: "1",
  //       PerformanceIndicatorMappings: [
  //         { CourseID: "C1", Course: { CourseCode: "CS1001" } },
  //         { CourseID: "C2", Course: { CourseCode: "CS2001" } },
  //         { CourseID: "C3", Course: { CourseCode: "CS3001" } },
  //         { CourseID: "C4", Course: { CourseCode: "CS4001" } },
  //       ],
  //     },
  //   ]);

  //   const response = await GET(req, context);
  //   const json = await response.json();

  //   expect(response.status).toBe(200);
  //   expect(json.data).toEqual({
  //     type: ChartType.GA_BY_COURSE_LEVEL,
  //     labels: {
  //       xAxisLabel: "Graduate Attribute",
  //       yAxisLabel: "Number of Courses",
  //       mainTitle: "Number of Courses Used for GA Assessment (by Course Level)",
  //     },
  //     data: [
  //       {
  //         graduateAttribute: "1-GA1",
  //         GAID: "1",
  //         values: [
  //           { label: "1000", count: 1, color: "color-for-1000" },
  //           { label: "2000", count: 1, color: "color-for-2000" },
  //           { label: "3000", count: 1, color: "color-for-3000" },
  //           { label: "4000", count: 1, color: "color-for-4000" },
  //         ],
  //       },
  //     ],
  //   });
  // });
});
