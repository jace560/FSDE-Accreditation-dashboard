import { configureStore } from "@reduxjs/toolkit";
import dummyReducer from "./slices/dummy-slice";
import { coursesApi } from "./api/courses";
import { chartsApi } from "./api/charts";
import { authApi } from "./api/auth";
import { adminApi } from "./api/admin";
export const store = configureStore({
  reducer: {
    dummy: dummyReducer,
    [coursesApi.reducerPath]: coursesApi.reducer,
    [chartsApi.reducerPath]: chartsApi.reducer,
    [authApi.reducerPath]: authApi.reducer,
    [adminApi.reducerPath]: adminApi.reducer,
  },
  middleware: (getDefaultMiddleware) =>
    getDefaultMiddleware()
      .concat(coursesApi.middleware)
      .concat(chartsApi.middleware)
      .concat(authApi.middleware)
      .concat(adminApi.middleware)
});

export type RootState = ReturnType<typeof store.getState>;