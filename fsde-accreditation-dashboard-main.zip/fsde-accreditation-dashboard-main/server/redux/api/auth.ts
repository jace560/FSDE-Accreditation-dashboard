import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import {
  ApiResponse,
  AuthResponseDto,
  ChartDataReturnDto,
  ChartQueryParams,
  ForgotPasswordDto,
  ResetPasswordDto,
  VerifyAccountDto,
} from "../../types";
import { SignUpFormData } from "@/app/components/app-auth-page";

export const authApi = createApi({
  reducerPath: "auth",
  baseQuery: fetchBaseQuery({ baseUrl: "/api/auth", credentials: "include" }),
  tagTypes: ["AUTH"],
  endpoints: (builder) => ({
    register: builder.mutation<ApiResponse<any>, SignUpFormData>({
      query: (signUpData: SignUpFormData) => ({
        url: "/register",
        method: "POST",
        body: signUpData,
      }),
      invalidatesTags: ["AUTH"],
    }),

    verifyAccount: builder.mutation<AuthResponseDto, VerifyAccountDto>({
      query: ({ token }) => ({
        url: `/verify-email?token=${token}`,
        method: "GET",
      }),
    }),

    forgotPassword: builder.mutation<AuthResponseDto, ForgotPasswordDto>({
      query: (data) => ({
        url: "/forgot-password",
        method: "POST",
        body: data,
      }),
    }),

    resetPassword: builder.mutation<AuthResponseDto, ResetPasswordDto>({
      query: (data) => ({
        url: `/reset-password`,
        method: "POST",
        body: data,
      }),
    }),
  }),
});

export const {
  useRegisterMutation,
  useVerifyAccountMutation,
  useForgotPasswordMutation,
  useResetPasswordMutation,
} = authApi;
