import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import {
  ApiResponse,
  CourseInformationSheet,
  CourseInformationSheetDto,
  GetCourseDetailsQuery,
  GetCourseDetailsResponseDto,
  GetCoursesQuery,
  GetCoursesResponse,
  GradeRequestDto,
  UpdateCourseInformationDto,
} from "../../types";
import { Course } from "@prisma/client";

export const coursesApi = createApi({
  reducerPath: "courses",
  baseQuery: fetchBaseQuery({ baseUrl: "/api", credentials: "include" }),
  tagTypes: ["Courses", "CourseDetails", "CourseLOPerformance", "CoursesYears"],

  endpoints: (builder) => ({
    getCourses: builder.query<GetCoursesResponse, GetCoursesQuery>({
      query: (queryParams: GetCoursesQuery) => {
        const params = new URLSearchParams();
        if (queryParams.courseNameQuery)
          params.append("courseNameQuery", queryParams.courseNameQuery);
        if (queryParams.programId)
          params.append("programId", queryParams.programId);
        if (queryParams.campusId)
          params.append("campusId", queryParams.campusId);
        if (queryParams.year) params.append("year", queryParams.year);
        if (queryParams.semester)
          params.append("semester", queryParams.semester);
        if (queryParams.page) params.append("page", queryParams.page);
        if (queryParams.limit) params.append("limit", queryParams.limit);

        return {
          url: `/courses?${params.toString()}`,
          credentials: "include",
        };
      },
      providesTags: ["Courses"],
    }),
    getCourseMappingDetails: builder.query<
      GetCourseDetailsResponseDto,
      GetCourseDetailsQuery
    >({
      query: (queryParams: GetCourseDetailsQuery) => {
        const params = new URLSearchParams();
        if (queryParams.mappingVersion)
          params.append("mappingVersion", queryParams.mappingVersion);

        return `/courses/${queryParams.courseID}?${params.toString()}`;
      },
      providesTags: ["CourseDetails"],
    }),
    getCourseLOPerformance: builder.query<
      ApiResponse<null>,
      { mappingVersion: string; courseId: string }
    >({
      query: (query: { mappingVersion: string; courseId: string }) => {
        return `/courses/${query.courseId}/lo-performance?mappingVersion=${query.mappingVersion}`;
      },
      providesTags: ["CourseLOPerformance"],
    }),
    getCourseYears: builder.query<{ years: string[] }, void>({
      query: () => ({
        url: `/courses/years`,
      }),
      providesTags: ["CoursesYears"],
    }),
    updateCourseInformation: builder.mutation<
      ApiResponse<null>,
      UpdateCourseInformationDto
    >({
      query: (courseInformationSheetDto: UpdateCourseInformationDto) => ({
        url: `/courses/${courseInformationSheetDto.courseId}`,
        method: "PUT",
        body: courseInformationSheetDto.courseInformationSheet,
      }),
      invalidatesTags: ["CourseLOPerformance"],
    }),

    postCourseInformation: builder.mutation<
      ApiResponse<Course>,
      CourseInformationSheetDto
    >({
      query: (courseInformationSheet: CourseInformationSheetDto) => ({
        url: "/courses",
        method: "POST",
        body: courseInformationSheet,
      }),
      invalidatesTags: ["Courses", "CoursesYears"],
    }),

    postStudentGradeSheetInformation: builder.mutation<
      ApiResponse<void>,
      GradeRequestDto
    >({
      query: (postStudentGradeSheet: GradeRequestDto) => ({
        url: `/courses/${postStudentGradeSheet.courseID}/student-grades`,
        method: "PUT",
        body: postStudentGradeSheet,
      }),
      // invalidatesTags: ["CoursesYears"],
    }),
    deleteCourse: builder.mutation<ApiResponse<void>, string>({
      query: (courseId: string) => ({
        url: `/courses?courseId=${courseId}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Courses", "CoursesYears"],
    }),
  }),
});

export const {
  useGetCoursesQuery,
  usePostCourseInformationMutation,
  useDeleteCourseMutation,
  useGetCourseMappingDetailsQuery,
  useUpdateCourseInformationMutation,
  useGetCourseLOPerformanceQuery,
  usePostStudentGradeSheetInformationMutation,
  useGetCourseYearsQuery,
} = coursesApi;
