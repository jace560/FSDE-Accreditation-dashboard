import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import {
  ThresholdUpdateRequest,
  Threshold,
  UsersReturnDto,
  GetUsersQuery,
  updateUserRoleDto,
  updateStatusRoleDto,
} from "@/types";

const API_URL = "/api/admin";

export const adminApi = createApi({
  reducerPath: "adminApi",
  baseQuery: fetchBaseQuery({ baseUrl: API_URL }),
  tagTypes: ["Thresholds", "Users"],
  endpoints: (builder) => ({
    fetchThresholds: builder.query<{ thresholds: Threshold[] }, void>({
      query: () => "/threshold",
      providesTags: ["Thresholds"],
    }),
    updateThresholds: builder.mutation<void, ThresholdUpdateRequest>({
      query: (thresholdRequest) => ({
        url: "/threshold",
        method: "POST",
        body: thresholdRequest,
      }),
      invalidatesTags: ["Thresholds"],
    }),
    getUsers: builder.query<UsersReturnDto, GetUsersQuery>({
      query: ({ page, limit, role, nameSearchQuery }) => {
        const params = new URLSearchParams();
        if (page) params.append("page", page);
        if (limit) params.append("limit", limit);
        if (role) params.append("role", role);
        if (nameSearchQuery) params.append("nameSearchQuery", nameSearchQuery);
        return { url: `/users?${params.toString()}` };
      },
      providesTags: ["Users"],
    }),
    updateUserRole: builder.mutation<void, updateUserRoleDto>({
      query: ({ userID, role }) => ({
        url: `/users/${userID}/role`,
        method: "PUT",
        body: { userID, role },
      }),
      invalidatesTags: ["Users"],
    }),
    updateUserStatus: builder.mutation<void, updateStatusRoleDto>({
      query: ({ userID, status }) => ({
        url: `/users/${userID}/status`,
        method: "PUT",
        body: { userID, status },
      }),
      invalidatesTags: ["Users"],
    }),
    deleteUser: builder.mutation<void, { userID: string }>({
      query: ({ userID }) => ({
        url: `/users/${userID}`,
        method: "DELETE",
      }),
      invalidatesTags: ["Users"],
    }),
  }),
});

export const {
  useFetchThresholdsQuery,
  useUpdateThresholdsMutation,
  useGetUsersQuery,
  useUpdateUserRoleMutation,
  useUpdateUserStatusMutation,
  useDeleteUserMutation,
} = adminApi;

export default adminApi;
