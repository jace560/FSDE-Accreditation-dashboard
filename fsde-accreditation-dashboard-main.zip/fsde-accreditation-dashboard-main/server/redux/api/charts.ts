import { createApi, fetchBaseQuery } from "@reduxjs/toolkit/query/react";
import { ApiResponse, ChartDataReturnDto, ChartQueryParams } from "../../types";

export const chartsApi = createApi({
  reducerPath: "charts",
  baseQuery: fetchBaseQuery({
    baseUrl: "/api/charts/",
    credentials: "include",
  }),
  tagTypes: ["Chart", "ChartExcel"],
  endpoints: (builder) => ({
    // charts/GA_BY_IDA?programID=560b7280-7f52-455d-8312-68b168ef3357&campusID=ee5463cb-31c2-4d86-9c80-dc943a5d7706&year=2017-18
    getChartData: builder.query<
      ApiResponse<ChartDataReturnDto>,
      ChartQueryParams
    >({
      query: (query: ChartQueryParams) => {
        const params = new URLSearchParams();
        if (query.programId) params.append("programId", query.programId);
        if (query.campusId) params.append("campusId", query.campusId);
        if (query.year) params.append("year", query.year);
        if (query.semester) params.append("semester", query.semester);
        if (query.graduateAttribute)
          params.append("graduateAttribute", query.graduateAttribute);
        return `${query.chartType}?${params.toString()}`;
      },
      providesTags: ["Chart"],
    }),
    getChartExcelData: builder.query<ApiResponse<null>, ChartQueryParams>({
      query: (query: ChartQueryParams) => {
        const params = new URLSearchParams();
        if (query.programId) params.append("programId", query.programId);
        if (query.campusId) params.append("campusId", query.campusId);
        if (query.year) params.append("year", query.year);
        if (query.semester) params.append("semester", query.semester);
        if (query.graduateAttribute)
          params.append("graduateAttribute", query.graduateAttribute);
        return `${query.chartType}/excel?${params.toString()}`;
      },
      providesTags: ["ChartExcel"],
    }),
  }),
});

export const { useGetChartDataQuery, useGetChartExcelDataQuery } = chartsApi;
