import { createSlice, PayloadAction } from "@reduxjs/toolkit";

interface DummyState {
  value: string;
}

const initialState: DummyState = {
  value: "Hello, Redux!",
};

const dummySlice = createSlice({
  name: "dummy",
  initialState,
  reducers: {
    updateValue(state, action: PayloadAction<string>) {
      state.value = action.payload;
    },
  },
});

export const { updateValue } = dummySlice.actions;
export default dummySlice.reducer;
