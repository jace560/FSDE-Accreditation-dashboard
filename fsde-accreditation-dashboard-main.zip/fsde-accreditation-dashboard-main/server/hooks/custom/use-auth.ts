"use client";
import { USER_ROLE } from "@/types";
import { useSession } from "next-auth/react";

export function useAuth() {
  const { data: session, status } = useSession();

  const role = session?.user?.Role;
  const isAdmin = role === USER_ROLE.SUPER_ADMIN || role === USER_ROLE.ADMIN;
  const isSuperAdmin = role === USER_ROLE.SUPER_ADMIN;

  return { isAdmin, role, status, session, isSuperAdmin }; // ✅ Export multiple values
}
