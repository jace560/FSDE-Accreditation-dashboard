import { ToastAction } from "@radix-ui/react-toast";
import { useToast } from "../use-toast";
import { CheckCircle, XCircle, AlertTriangle } from "lucide-react";

export function useCustomToast() {
  const { toast } = useToast();

  const showSuccessToast = (message: string) => {
    toast({
      title: (
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "0.5rem",
          }}
        >
          <CheckCircle
            style={{
              width: "1rem",
              height: "1rem",
              color: "#22c55e",
            }}
          />
          Success!
        </div>
      ) as unknown as string,
      description: message,
      variant: "success",
    });
  };

  const showErrorToast = (message: string) => {
    toast({
      variant: "destructive",
      title: (
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "0.5rem",
          }}
        >
          <XCircle
            style={{
              width: "1rem",
              height: "1rem",
            }}
          />
          Error
        </div>
      ) as unknown as string,
      description: message,
    });
  };

  const showWarningToast = (message: string) => {
    toast({
      title: (
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "0.5rem",
          }}
        >
          <AlertTriangle
            style={{
              width: "1rem",
              height: "1rem",
              color: "#eab308",
            }}
          />
          Warning
        </div>
      ) as unknown as string,
      description: message,
      variant: "warning",
    });
  };

  const showConfirmationToast = (
    message: string,
    actionMessage: string,
    actionToPerform: () => void
  ) => {
    toast({
      title: (
        <div
          style={{
            display: "flex",
            alignItems: "center",
            gap: "0.5rem",
            color: "#eab308", // Warning color
            fontWeight: "bold",
          }}
        >
          <AlertTriangle
            style={{
              width: "1rem",
              height: "1rem",
            }}
          />
          Warning
        </div>
      ) as unknown as string,
      description: (
        <div
          style={{
            marginTop: "0.5rem",
          }}
        >
          {message}
        </div>
      ),
      variant: "warning",
      action: (
        <ToastAction
          onClick={() => actionToPerform()}
          altText={actionMessage}
          style={{
            backgroundColor: "#eab308",
            color: "#fff",
            padding: "0.5rem 1rem",
            borderRadius: "0.25rem",
            fontSize: "0.875rem",
            fontWeight: "bold",
            cursor: "pointer",
          }}
        >
          {actionMessage}
        </ToastAction>
      ),
    });
  };

  return {
    showSuccessToast,
    showErrorToast,
    showWarningToast,
    showConfirmationToast,
  };
}
