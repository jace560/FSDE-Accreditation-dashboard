import { v4 as uuidv4 } from "uuid";
import prisma from "../lib/prisma";
import { USER_ROLE, USER_STATUS } from "../types";
import bcrypt from "bcryptjs";

export enum PILevel {
  Introduce = "I",
  Apply = "A",
  Develop = "D",
}

type Threshold = {
  label: string;
  min: number;
  max: number;
  proportion: number;
};

type Semester = "Fall" | "Winter" | "Summer";

async function main(): Promise<void> {
  console.log("🌱 Starting seeding...");

  // 2) Delete existing data
  // console.log("🔎 Clearing existing data...");
  // await prisma.grade.deleteMany();
  // await prisma.assessmentToolLearningObjectiveMapping.deleteMany();
  // await prisma.learningObjectivePerformanceIndicatorMapping.deleteMany();
  // await prisma.learningObjective.deleteMany();
  // await prisma.assessmentTool.deleteMany();
  // await prisma.course.deleteMany();
  // await prisma.campusProgram.deleteMany();
  // await prisma.graduateAttribute.deleteMany();
  // await prisma.program.deleteMany();
  // await prisma.campus.deleteMany();
  // await prisma.user.deleteMany();

  console.log("🔎 Existing data cleared.");

  const semesters: Semester[] = ["Fall", "Winter", "Summer"];

  // 3) Seed Graduate Attributes (same as original)
  // const graduateAttributes = [
  //   { number: 1, name: "KB", description: "Knowledge base in engineering" },
  //   { number: 2, name: "PA", description: "Problem analysis" },
  //   {
  //     number: 3,
  //     name: "Inv",
  //     description: "Investigation of complex problems",
  //   },
  //   { number: 4, name: "Des", description: "Design" },
  //   { number: 5, name: "Tools", description: "Use of engineering tools" },
  //   { number: 6, name: "Team", description: "Individual and team work" },
  //   { number: 7, name: "Comm", description: "Communication skills" },
  //   { number: 8, name: "Prof", description: "Professionalism" },
  //   {
  //     number: 9,
  //     name: "Impacts",
  //     description: "Impact of engineering on society & environment",
  //   },
  //   { number: 10, name: "Ethics", description: "Ethics and equity" },
  //   {
  //     number: 11,
  //     name: "Econ",
  //     description: "Economics and project management",
  //   },
  //   { number: 12, name: "LL", description: "Life-long learning" },
  // ];

  // console.log("🌱 Seeded graduate attributes");

  // // 4) Seed campuses
  // await prisma.campus.createMany({
  //   data: [{ CampusName: "UPEI Charlottetown" }, { CampusName: "UPEI Cairo" }],
  // });
  // console.log("🌱 Seeded campuses: UPEI Charlottetown and Cairo");

  // // 5) Seed program
  // const program = await prisma.program.create({
  //   data: {
  //     ProgramName: "Bachelor of Science in Sustainable Design Engineering",
  //   },
  // });
  // console.log(
  //   "🌱 Seeded program: Bachelor of Science in Sustainable Design Engineering"
  // );

  // // 6) Seed Graduate Attributes
  // await prisma.graduateAttribute.createMany({
  //   data: graduateAttributes.map((ga) => ({
  //     GANumber: ga.number,
  //     GAName: ga.name,
  //     GADescription: ga.description,
  //     ProgramID: program.ProgramID,
  //   })),
  // });

  // // 7) Seed campus-program relationships
  // const campuses = await prisma.campus.findMany();
  // await prisma.campusProgram.createMany({
  //   data: campuses.map((campus) => ({
  //     CampusID: campus.CampusID,
  //     ProgramID: program.ProgramID,
  //   })),
  // });
  // console.log("🌱 Seeded campus-program relationships");

  // const hashedPassword = await bcrypt.hash("RootPassword0011@iRR", 10);

  // const user = await prisma.user.create({
  //   data: {
  //     FirstName: "Charles",
  //     LastName: "Akintunde",
  //     Email: "icakintunde@upei.ca",
  //     Password: hashedPassword,
  //     Role: USER_ROLE.SUPER_ADMIN,
  //     Status: USER_STATUS.ACTIVE,
  //   },
  // });

  // const hashedPassword2 = await bcrypt.hash("Gideon12$Sdge", 10);

  // const user2 = await prisma.user.create({
  //   data: {
  //     FirstName: "Gideon",
  //     LastName: "Landry",
  //     Email: "gilandry@upei.ca",
  //     Password: hashedPassword2,
  //     Role: USER_ROLE.ADMIN,
  //     Status: USER_STATUS.ACTIVE,
  //   },
  // });

  const hashedPassword3 = await bcrypt.hash("RootPassword0011@iRR", 10);

  await prisma.user.create({
    data: {
      FirstName: "Abdulrahman",
      LastName: "Abdelmwlla",
      Email: "aaabdelmwlla@upei.ca",
      Password: hashedPassword3,
      Role: USER_ROLE.SUPER_ADMIN,
      Status: USER_STATUS.ACTIVE,
    },
  });

  // const hashedPassword4 = await bcrypt.hash("Gideon12$Sdge", 10);

  await prisma.user.create({
    data: {
      FirstName: "Wayne",
      LastName: "Peters",
      Email: "wpeters@upei.ca",
      Password: hashedPassword3,
      Role: USER_ROLE.SUPER_ADMIN,
      Status: USER_STATUS.ACTIVE,
    },
  });

  // const hashedPassword2 = await bcrypt.hash("Gideon12$Sdge", 10);

  await prisma.user.create({
    data: {
      FirstName: "Stephanie",
      LastName: "Crocker",
      Email: "stcrocker@upei.ca",
      Password: hashedPassword3,
      Role: USER_ROLE.SUPER_ADMIN,
      Status: USER_STATUS.ACTIVE,
    },
  });
  // console.log("🌱 Seeded Root User");
  // console.log("🌱 Seeded Root User");

  // console.log("✅ Seeding complete.");
}

main()
  .catch((e) => {
    console.error("❌ Error during seeding:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
    console.log("✅ Prisma Client disconnected.");
  });
