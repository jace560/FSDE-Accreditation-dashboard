-- CreateTable
CREATE TABLE "Program" (
    "ProgramID" UUID NOT NULL,
    "ProgramName" TEXT NOT NULL,

    CONSTRAINT "Program_pkey" PRIMARY KEY ("ProgramID")
);

-- CreateTable
CREATE TABLE "Campus" (
    "CampusID" UUID NOT NULL,
    "CampusName" TEXT NOT NULL,

    CONSTRAINT "Campus_pkey" PRIMARY KEY ("CampusID")
);

-- CreateTable
CREATE TABLE "CampusProgram" (
    "CampusProgramID" UUID NOT NULL,
    "CampusID" UUID NOT NULL,
    "ProgramID" UUID NOT NULL,

    CONSTRAINT "CampusProgram_pkey" PRIMARY KEY ("CampusProgramID")
);

-- CreateTable
CREATE TABLE "Course" (
    "CourseID" UUID NOT NULL,
    "CourseCode" TEXT NOT NULL,
    "CourseName" TEXT NOT NULL,
    "CampusID" UUID NOT NULL,
    "SemesterName" TEXT NOT NULL,
    "SectionNumber" INTEGER NOT NULL DEFAULT 1,
    "Year" TEXT NOT NULL,

    CONSTRAINT "Course_pkey" PRIMARY KEY ("CourseID")
);

-- CreateTable
CREATE TABLE "GraduateAttribute" (
    "GAID" UUID NOT NULL,
    "GAName" TEXT NOT NULL,
    "GANumber" INTEGER NOT NULL,
    "GADescription" TEXT NOT NULL,
    "ProgramID" UUID NOT NULL,

    CONSTRAINT "GraduateAttribute_pkey" PRIMARY KEY ("GAID")
);

-- CreateTable
CREATE TABLE "LearningObjective" (
    "LOID" UUID NOT NULL,
    "LOName" TEXT NOT NULL,
    "CourseID" UUID NOT NULL,
    "Description" TEXT NOT NULL,
    "MappingVersion" UUID NOT NULL,
    "IsCurrent" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "LearningObjective_pkey" PRIMARY KEY ("LOID")
);

-- CreateTable
CREATE TABLE "AssessmentTool" (
    "ATID" UUID NOT NULL,
    "ATName" TEXT NOT NULL,
    "Weight" DOUBLE PRECISION NOT NULL,
    "Description" TEXT NOT NULL,
    "CourseID" UUID NOT NULL,
    "MappingVersion" UUID NOT NULL,
    "IsCurrent" BOOLEAN NOT NULL DEFAULT true,

    CONSTRAINT "AssessmentTool_pkey" PRIMARY KEY ("ATID")
);

-- CreateTable
CREATE TABLE "AssessmentToolLearningObjectiveMapping" (
    "ATLOID" UUID NOT NULL,
    "ATID" UUID NOT NULL,
    "LOID" UUID NOT NULL,
    "Weight" DOUBLE PRECISION NOT NULL,
    "CourseID" UUID NOT NULL,

    CONSTRAINT "AssessmentToolLearningObjectiveMapping_pkey" PRIMARY KEY ("ATLOID")
);

-- CreateTable
CREATE TABLE "LearningObjectivePerformanceIndicatorMapping" (
    "LOPIID" UUID NOT NULL,
    "LOID" UUID NOT NULL,
    "PILevel" TEXT NOT NULL,
    "GAID" UUID NOT NULL,
    "CourseID" UUID NOT NULL,

    CONSTRAINT "LearningObjectivePerformanceIndicatorMapping_pkey" PRIMARY KEY ("LOPIID")
);

-- CreateTable
CREATE TABLE "Grade" (
    "GradeID" UUID NOT NULL,
    "StudentIdentifier" UUID NOT NULL,
    "ATID" UUID NOT NULL,
    "CourseID" UUID NOT NULL,
    "GradePercentage" DOUBLE PRECISION NOT NULL,

    CONSTRAINT "Grade_pkey" PRIMARY KEY ("GradeID")
);

-- CreateTable
CREATE TABLE "Threshold" (
    "ThresholdID" UUID NOT NULL,
    "Threshold" TEXT NOT NULL,
    "ThresholdSign" TEXT NOT NULL,
    "ThresholdValue" DOUBLE PRECISION NOT NULL,

    CONSTRAINT "Threshold_pkey" PRIMARY KEY ("ThresholdID")
);

-- CreateTable
CREATE TABLE "User" (
    "UserID" UUID NOT NULL,
    "FirstName" TEXT NOT NULL,
    "LastName" TEXT NOT NULL,
    "Email" TEXT NOT NULL,
    "Password" TEXT NOT NULL,
    "Role" TEXT NOT NULL,
    "Status" TEXT NOT NULL,

    CONSTRAINT "User_pkey" PRIMARY KEY ("UserID")
);

-- CreateIndex
CREATE INDEX "Program_ProgramName_idx" ON "Program"("ProgramName");

-- CreateIndex
CREATE INDEX "Campus_CampusName_idx" ON "Campus"("CampusName");

-- CreateIndex
CREATE INDEX "CampusProgram_CampusID_ProgramID_idx" ON "CampusProgram"("CampusID", "ProgramID");

-- CreateIndex
CREATE INDEX "Course_CampusID_idx" ON "Course"("CampusID");

-- CreateIndex
CREATE INDEX "Course_CourseCode_CampusID_SemesterName_SectionNumber_Year_idx" ON "Course"("CourseCode", "CampusID", "SemesterName", "SectionNumber", "Year");

-- CreateIndex
CREATE UNIQUE INDEX "Course_CourseCode_CampusID_SemesterName_SectionNumber_Year_key" ON "Course"("CourseCode", "CampusID", "SemesterName", "SectionNumber", "Year");

-- CreateIndex
CREATE UNIQUE INDEX "GraduateAttribute_GANumber_key" ON "GraduateAttribute"("GANumber");

-- CreateIndex
CREATE INDEX "GraduateAttribute_GANumber_idx" ON "GraduateAttribute"("GANumber");

-- CreateIndex
CREATE INDEX "LearningObjective_LOName_idx" ON "LearningObjective"("LOName");

-- CreateIndex
CREATE INDEX "LearningObjective_IsCurrent_idx" ON "LearningObjective"("IsCurrent");

-- CreateIndex
CREATE INDEX "LearningObjective_MappingVersion_idx" ON "LearningObjective"("MappingVersion");

-- CreateIndex
CREATE INDEX "LearningObjective_CourseID_idx" ON "LearningObjective"("CourseID");

-- CreateIndex
CREATE INDEX "LearningObjective_LOName_IsCurrent_idx" ON "LearningObjective"("LOName", "IsCurrent");

-- CreateIndex
CREATE INDEX "AssessmentTool_CourseID_ATName_idx" ON "AssessmentTool"("CourseID", "ATName");

-- CreateIndex
CREATE INDEX "AssessmentTool_MappingVersion_idx" ON "AssessmentTool"("MappingVersion");

-- CreateIndex
CREATE INDEX "AssessmentTool_IsCurrent_idx" ON "AssessmentTool"("IsCurrent");

-- CreateIndex
CREATE INDEX "AssessmentToolLearningObjectiveMapping_ATID_LOID_CourseID_idx" ON "AssessmentToolLearningObjectiveMapping"("ATID", "LOID", "CourseID");

-- CreateIndex
CREATE INDEX "LearningObjectivePerformanceIndicatorMapping_LOID_PILevel_G_idx" ON "LearningObjectivePerformanceIndicatorMapping"("LOID", "PILevel", "GAID", "CourseID");

-- CreateIndex
CREATE INDEX "Grade_StudentIdentifier_idx" ON "Grade"("StudentIdentifier");

-- CreateIndex
CREATE INDEX "Grade_CourseID_ATID_idx" ON "Grade"("CourseID", "ATID");

-- CreateIndex
CREATE UNIQUE INDEX "Threshold_Threshold_key" ON "Threshold"("Threshold");

-- CreateIndex
CREATE UNIQUE INDEX "User_Email_key" ON "User"("Email");

-- AddForeignKey
ALTER TABLE "CampusProgram" ADD CONSTRAINT "CampusProgram_CampusID_fkey" FOREIGN KEY ("CampusID") REFERENCES "Campus"("CampusID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "CampusProgram" ADD CONSTRAINT "CampusProgram_ProgramID_fkey" FOREIGN KEY ("ProgramID") REFERENCES "Program"("ProgramID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Course" ADD CONSTRAINT "Course_CampusID_fkey" FOREIGN KEY ("CampusID") REFERENCES "Campus"("CampusID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GraduateAttribute" ADD CONSTRAINT "GraduateAttribute_ProgramID_fkey" FOREIGN KEY ("ProgramID") REFERENCES "Program"("ProgramID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LearningObjective" ADD CONSTRAINT "LearningObjective_CourseID_fkey" FOREIGN KEY ("CourseID") REFERENCES "Course"("CourseID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AssessmentTool" ADD CONSTRAINT "AssessmentTool_CourseID_fkey" FOREIGN KEY ("CourseID") REFERENCES "Course"("CourseID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AssessmentToolLearningObjectiveMapping" ADD CONSTRAINT "AssessmentToolLearningObjectiveMapping_ATID_fkey" FOREIGN KEY ("ATID") REFERENCES "AssessmentTool"("ATID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AssessmentToolLearningObjectiveMapping" ADD CONSTRAINT "AssessmentToolLearningObjectiveMapping_CourseID_fkey" FOREIGN KEY ("CourseID") REFERENCES "Course"("CourseID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "AssessmentToolLearningObjectiveMapping" ADD CONSTRAINT "AssessmentToolLearningObjectiveMapping_LOID_fkey" FOREIGN KEY ("LOID") REFERENCES "LearningObjective"("LOID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LearningObjectivePerformanceIndicatorMapping" ADD CONSTRAINT "LearningObjectivePerformanceIndicatorMapping_CourseID_fkey" FOREIGN KEY ("CourseID") REFERENCES "Course"("CourseID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LearningObjectivePerformanceIndicatorMapping" ADD CONSTRAINT "LearningObjectivePerformanceIndicatorMapping_GAID_fkey" FOREIGN KEY ("GAID") REFERENCES "GraduateAttribute"("GAID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "LearningObjectivePerformanceIndicatorMapping" ADD CONSTRAINT "LearningObjectivePerformanceIndicatorMapping_LOID_fkey" FOREIGN KEY ("LOID") REFERENCES "LearningObjective"("LOID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Grade" ADD CONSTRAINT "Grade_ATID_fkey" FOREIGN KEY ("ATID") REFERENCES "AssessmentTool"("ATID") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Grade" ADD CONSTRAINT "Grade_CourseID_fkey" FOREIGN KEY ("CourseID") REFERENCES "Course"("CourseID") ON DELETE CASCADE ON UPDATE CASCADE;
