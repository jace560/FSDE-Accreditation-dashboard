import { v4 as uuidv4 } from "uuid";
import prisma from "../../server/lib/prisma";
import { USER_ROLE, USER_STATUS } from "../types";
import bcrypt from "bcryptjs";
export enum PILevel {
  Introduce = "I",
  Apply = "A",
  Develop = "D",
}

type Threshold = {
  label: string;
  min: number;
  max: number;
  proportion: number;
};

type Semester = "Fall" | "Winter" | "Summer";

async function main(): Promise<void> {
  console.log("🌱 Starting seeding...");

  // 2) Delete existing data
  console.log("🔎 Clearing existing data...");
  // await prisma.grade.deleteMany();
  // await prisma.assessmentToolLearningObjectiveMapping.deleteMany();
  // await prisma.learningObjectivePerformanceIndicatorMapping.deleteMany();
  // await prisma.learningObjective.deleteMany();
  // await prisma.assessmentTool.deleteMany();
  await prisma.course.deleteMany();
  // await prisma.campusProgram.deleteMany();
  // await prisma.graduateAttribute.deleteMany();
  // await prisma.program.deleteMany();
  // await prisma.campus.deleteMany();
  // await prisma.user.deleteMany();
  console.log("🔎 Existing data cleared.");

  // const semesters: Semester[] = ["Fall", "Winter", "Summer"];

  // // 3) Seed Graduate Attributes (same as original)
  // const graduateAttributes = [
  //   { number: 1, name: "KB", description: "Knowledge base in engineering" },
  //   { number: 2, name: "PA", description: "Problem analysis" },
  //   {
  //     number: 3,
  //     name: "Inv",
  //     description: "Investigation of complex problems",
  //   },
  //   { number: 4, name: "Des", description: "Design" },
  //   { number: 5, name: "Tools", description: "Use of engineering tools" },
  //   { number: 6, name: "Team", description: "Individual and team work" },
  //   { number: 7, name: "Comm", description: "Communication skills" },
  //   { number: 8, name: "Prof", description: "Professionalism" },
  //   {
  //     number: 9,
  //     name: "Impacts",
  //     description: "Impact of engineering on society & environment",
  //   },
  //   { number: 10, name: "Ethics", description: "Ethics and equity" },
  //   {
  //     number: 11,
  //     name: "Econ",
  //     description: "Economics and project management",
  //   },
  //   { number: 12, name: "LL", description: "Life-long learning" },
  // ];

  console.log("🌱 Seeded graduate attributes");

  // // 4) Seed campuses
  // await prisma.campus.createMany({
  //   data: [{ CampusName: "UPEI Charlottetown" }, { CampusName: "UPEI Cairo" }],
  // });
  // console.log("🌱 Seeded campuses: UPEI Charlottetown and Cairo");

  // // 5) Seed program
  // const program = await prisma.program.create({
  //   data: {
  //     ProgramName: "Bachelor of Science in Sustainable Design Engineering",
  //   },
  // });
  // console.log(
  //   "🌱 Seeded program: Bachelor of Science in Sustainable Design Engineering"
  // );

  // // 6) Seed Graduate Attributes
  // await prisma.graduateAttribute.createMany({
  //   data: graduateAttributes.map((ga) => ({
  //     GANumber: ga.number,
  //     GAName: ga.name,
  //     GADescription: ga.description,
  //     ProgramID: program.ProgramID,
  //   })),
  // });

  // // 7) Seed campus-program relationships
  // const campuses = await prisma.campus.findMany();
  // await prisma.campusProgram.createMany({
  //   data: campuses.map((campus) => ({
  //     CampusID: campus.CampusID,
  //     ProgramID: program.ProgramID,
  //   })),
  // });
  // console.log("🌱 Seeded campus-program relationships");

  // const usersData = Array.from({ length: 200 }).map(() => {
  //   const firstName = firstNames[Math.floor(Math.random() * firstNames.length)];
  //   const lastName = lastNames[Math.floor(Math.random() * lastNames.length)];
  //   const email = `${firstName.toLowerCase()}.${lastName.toLowerCase()}${Math.floor(
  //     Math.random() * 100
  //   )}@example.com`;

  //   return {
  //     UserID: uuidv4(),
  //     FirstName: firstName,
  //     LastName: lastName,
  //     Email: email,
  //     Role: Object.values(USER_ROLE)[
  //       Math.floor(Math.random() * Object.values(USER_ROLE).length)
  //     ],
  //     Status:
  //       Object.values(USER_STATUS)[
  //         Math.floor(Math.random() * Object.values(USER_STATUS).length)
  //       ],
  //     Password: "hashed_password_here", // Simulating a hashed password
  //   };
  // });

  // const hashedPassword = await bcrypt.hash("RootPassword0011@iRR", 10);

  // const user = await prisma.user.create({
  //   data: {
  //     FirstName: "Charles",
  //     LastName: "Akintunde",
  //     Email: "icakintunde@upei.ca",
  //     Password: hashedPassword,
  //     Role: USER_ROLE.SUPER_ADMIN,
  //     Status: USER_STATUS.ACTIVE,
  //   },
  // });

  // await prisma.user.createMany({
  //   data: usersData,
  //   skipDuplicates: true, // Avoid inserting duplicate emails
  // });

  console.log("✅ Successfully seeded 200 users!");

  // 8) Generate courses for each year in the range
  const startYear = 2015;
  const endYear = 2024;

  const allCoursesData = [];
  // for (let year = startYear; year <= endYear; year++) {
  //   for (const c of coursePIData.courses) {
  //     for (const campus of campuses) {
  //       const semester =
  //         semesters[Math.floor(Math.random() * semesters.length)];

  //       // Format year as "2021-22" etc.
  //       const academicYear = `${year}-${(year + 1).toString().slice(-2)}`;

  //       allCoursesData.push({
  //         CourseCode: c.courseCode,
  //         CourseName: `Engineering Course ${c.courseCode}`,
  //         CampusID: campus.CampusID,
  //         SemesterName: semester,
  //         SectionNumber: 1,
  //         Year: academicYear,
  //       });
  //     }
  //   }
  // }

  // await prisma.course.createMany({ data: allCoursesData });
  // console.log("🌱 Seeded courses for all years");

  // // 9) Prepare lookups
  // const dbCourses = await prisma.course.findMany();

  // // Convert ["4I", "5I", ...] into a simpler lookup: coursePILookup[courseCode] -> string[] of PIs
  // const coursePILookup: Record<string, string[]> = {};
  // for (const item of coursePIData.courses) {
  //   coursePILookup[item.courseCode] = item.pis;
  // }

  // // fetch the GAs from DB, so we can find GAID by number
  // const dbGAs = await prisma.graduateAttribute.findMany();
  // const gaByNumber: Record<number, (typeof dbGAs)[number]> = {};
  // for (const ga of dbGAs) {
  //   gaByNumber[ga.GANumber] = ga;
  // }

  // // 10) For each course, create multiple mapping versions, LOs, ATs, etc.
  // for (const course of dbCourses) {
  //   // We'll create 1-2 mapping versions per course, for demonstration
  //   const totalMappings = Math.floor(Math.random() * 2) + 1;

  //   for (let versionIndex = 0; versionIndex < totalMappings; versionIndex++) {
  //     const mappingVersion = uuidv4();
  //     const isCurrent = versionIndex === totalMappings - 1;

  //     // 10.1) Create 10 LOs
  //     const learningObjectivesData = Array.from({ length: 10 }, (_, i) => ({
  //       LOName: `LO${i + 1}`,
  //       CourseID: course.CourseID,
  //       MappingVersion: mappingVersion,
  //       Description: `LO${i + 1} Description`,
  //       IsCurrent: isCurrent,
  //     }));
  //     await prisma.learningObjective.createMany({
  //       data: learningObjectivesData,
  //     });

  //     // 10.2) Create 8-10 Assessment Tools
  //     const numATs = Math.floor(Math.random() * 3) + 8; // 8 to 10
  //     const weights = distributeWeights(numATs, 100);
  //     const assessmentToolsData = Array.from({ length: numATs }, (_, i) => ({
  //       ATName: `AT${i + 1}`,
  //       Weight: weights[i],
  //       Description: `Assessment Tool ${i + 1} for ${course.CourseName}`,
  //       CourseID: course.CourseID,
  //       MappingVersion: mappingVersion,
  //       IsCurrent: isCurrent,
  //     }));
  //     await prisma.assessmentTool.createMany({ data: assessmentToolsData });

  //     // fetch the newly created LOs & ATs
  //     const learningObjectives = await prisma.learningObjective.findMany({
  //       where: {
  //         CourseID: course.CourseID,
  //         MappingVersion: mappingVersion,
  //       },
  //     });
  //     const assessmentTools = await prisma.assessmentTool.findMany({
  //       where: {
  //         CourseID: course.CourseID,
  //         MappingVersion: mappingVersion,
  //       },
  //     });

  //     // 10.3) AT -> LO mapping
  //     const atLoMappings = assessmentTools.flatMap((at) => {
  //       const loWeights = distributeWeights(learningObjectives.length, 100);
  //       return learningObjectives.map((lo, idx) => ({
  //         ATID: at.ATID,
  //         LOID: lo.LOID,
  //         Weight: loWeights[idx],
  //         CourseID: course.CourseID,
  //       }));
  //     });
  //     await prisma.assessmentToolLearningObjectiveMapping.createMany({
  //       data: atLoMappings,
  //     });

  //     // 10.4) LO -> GA (PI) mapping
  //     // For this mapping version, use all the PIs defined in the course PI JSON
  //     const coursePIs = coursePILookup[course.CourseCode] || [];

  //     // If there are no PIs for this course, skip this mapping version.
  //     if (!coursePIs.length) {
  //       continue;
  //     }

  //     // For each learning objective (LO) for this mapping version...
  //     const LOMappings = [];
  //     for (const lo of learningObjectives) {
  //       // ...create a mapping record for every PI from the JSON.
  //       for (const pi of coursePIs) {
  //         const gaNumber = parseInt(pi.slice(0, -1), 10);
  //         const piLevelLetter = pi.slice(-1);
  //         let piLevel: PILevel;
  //         switch (piLevelLetter) {
  //           case "I":
  //             piLevel = PILevel.Introduce;
  //             break;
  //           case "D":
  //             piLevel = PILevel.Develop;
  //             break;
  //           default:
  //             piLevel = PILevel.Apply;
  //             break;
  //         }
  //         const gaRecord = gaByNumber[gaNumber];
  //         if (!gaRecord) continue;
  //         LOMappings.push({
  //           LOID: lo.LOID,
  //           PILevel: piLevel,
  //           GAID: gaRecord.GAID,
  //           CourseID: course.CourseID,
  //           // Optionally, include MappingVersion if needed:
  //           // MappingVersion: mappingVersion,
  //         });
  //       }
  //     }
  //     await prisma.learningObjectivePerformanceIndicatorMapping.createMany({
  //       data: LOMappings,
  //     });

  //     // 10.5) Generate random student grades
  //     const studentsPerCourse = 20;
  //     const assessmentToolsLocal = assessmentTools; // just for clarity
  //     const gradesData = Array.from({ length: studentsPerCourse }, () => {
  //       const studentId = uuidv4();
  //       return assessmentToolsLocal.map((at) => {
  //         const threshold = selectThreshold(gradeThresholds);
  //         const rawGrade = generateGrade(threshold.min, threshold.max);
  //         const adjustedGrade = (rawGrade * at.Weight) / 100;
  //         return {
  //           GradeID: uuidv4(),
  //           StudentIdentifier: studentId,
  //           ATID: at.ATID,
  //           CourseID: course.CourseID,
  //           GradePercentage: adjustedGrade,
  //         };
  //       });
  //     }).flat();

  //     await prisma.grade.createMany({ data: gradesData });
  //   }
  // }

  console.log("✅ Seeding complete.");
}

// Example thresholds
const gradeThresholds: Threshold[] = [
  { label: "Exceeds", min: 80, max: 100, proportion: 0.4 },
  { label: "Acceptable", min: 65, max: 79.99, proportion: 0.3 },
  { label: "Marginal", min: 50, max: 64.99, proportion: 0.2 },
  { label: "Fail", min: 0, max: 49.99, proportion: 0.1 },
];

function distributeWeights(count: number, total: number) {
  const weights = Array.from({ length: count }, () => Math.random());
  const sum = weights.reduce((a, b) => a + b, 0);
  return weights.map((w) => Math.round((w / sum) * total));
}

function selectThreshold(thresholds: Threshold[]) {
  const random = Math.random();
  let cumulative = 0;
  for (const threshold of thresholds) {
    cumulative += threshold.proportion;
    if (random < cumulative) return threshold;
  }
  return thresholds[thresholds.length - 1];
}

function generateGrade(min: number, max: number) {
  return Math.round(Math.random() * (max - min) + min);
}

// Helper to shuffle an array in-place
function shuffleArray<T>(array: T[]): T[] {
  for (let i = array.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    [array[i], array[j]] = [array[j], array[i]];
  }
  return array;
}

// Helper to pick `count` random distinct items from an array
function pickRandom<T>(arr: T[], count: number): T[] {
  if (count >= arr.length) {
    return arr;
  }
  const shuffled = shuffleArray(arr.slice());
  return shuffled.slice(0, count);
}

main()
  .catch((e) => {
    console.error("❌ Error during seeding:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
    console.log("✅ Prisma Client disconnected.");
  });

const coursePIData = {
  courses: [
    {
      courseCode: "ENGN1210",
      pis: ["4I", "5I", "6I", "7I", "8I", "9I", "10I", "11I"],
    },
    {
      courseCode: "ENGN1230",
      pis: ["1I", "2I"],
    },
    {
      courseCode: "ENGN1410",
      pis: ["1I", "4I", "5I", "6I", "7I", "9I", "11I", "12I"],
    },
    {
      courseCode: "ENGN2210",
      pis: ["2I", "4I", "5I", "6I", "7I", "8I", "9I", "10I", "11I"],
    },
    {
      courseCode: "ENGN2310",
      pis: ["1I", "2D", "5I"],
    },
    {
      courseCode: "ENGN2610",
      pis: ["1I", "2D", "5I"],
    },
    {
      courseCode: "ENGN2810",
      pis: ["1I", "2D", "5I"],
    },
    {
      courseCode: "ENGN3220",
      pis: ["1D", "3D", "5D", "6D"],
    },
    {
      courseCode: "ENGN3340",
      pis: ["1I", "2D", "3D"],
    },
    {
      courseCode: "ENGN3440",
      pis: ["1I", "3D", "6D", "9I"],
    },
    {
      courseCode: "ENGN3540",
      pis: ["1I", "2D", "4D", "5D", "8D"],
    },
    {
      courseCode: "ENGN3630",
      pis: ["1I", "2D", "5D"],
    },
    {
      courseCode: "ENGN3710",
      pis: ["4D", "5D", "6D", "7D", "8D", "9D", "10D", "11D", "12D"],
    },
    {
      courseCode: "ENGN3810",
      pis: ["1D", "3D", "5D", "9D", "11D"],
    },
    {
      courseCode: "ENGN4210",
      pis: ["1I", "11D", "12D"],
    },
    {
      courseCode: "ENGN4330",
      pis: ["1I", "3D", "5D"],
    },
    {
      courseCode: "ENGN4440",
      pis: ["1I", "3D", "5D"],
    },
    {
      courseCode: "ENGN4710",
      pis: ["4A", "5A", "6A", "7A", "8A", "9A", "10A", "11A", "12A"],
    },
    {
      courseCode: "ENGN4850",
      pis: ["1I", "3D", "5D"],
    },
    {
      courseCode: "ENGN1220",
      pis: [
        "1I",
        "2I",
        "4I",
        "5I",
        "6I",
        "7I",
        "8I",
        "9I",
        "10I",
        "11I",
        "12I",
      ],
    },
    {
      courseCode: "ENGN1250",
      pis: ["1I", "2I", "5I"],
    },
    {
      courseCode: "ENGN1310",
      pis: ["1I", "5I", "9I"],
    },
    {
      courseCode: "ENGN1340",
      pis: ["1I", "2I", "5I"],
    },
    {
      courseCode: "ENGN2130",
      pis: ["1I", "2I", "5I"],
    },
    {
      courseCode: "ENGN2220",
      pis: [
        "2D",
        "3I",
        "4D",
        "5D",
        "6D",
        "7D",
        "8D",
        "9D",
        "10D",
        "11D",
        "12I",
      ],
    },
    {
      courseCode: "ENGN2360",
      pis: ["1D", "2D", "3I", "5D", "9D", "11D"],
    },
    {
      courseCode: "ENGN2620",
      pis: ["1I", "2D", "5I"],
    },
    {
      courseCode: "ENGN2830",
      pis: ["1I", "2D", "5I"],
    },
    {
      courseCode: "ENGN3270",
      pis: ["1I", "3D", "6D", "7D", "9D"],
    },
    {
      courseCode: "ENGN3370",
      pis: ["1I", "2D", "3D"],
    },
    {
      courseCode: "ENGN3430",
      pis: ["8D", "9D", "12D"],
    },
    {
      courseCode: "ENGN3490",
      pis: ["1I", "3D", "9I"],
    },
    {
      courseCode: "ENGN3720",
      pis: ["3A", "4A", "5A", "6A", "7A", "8A", "9A", "10A", "11A", "12D"],
    },
    {
      courseCode: "ENGN3820",
      pis: ["1I", "2D", "3I", "4I", "5D", "7D"],
    },
    {
      courseCode: "ENGN4470",
      pis: ["1I", "3D", "5D"],
    },
    {
      courseCode: "ENGN4550",
      pis: ["1I", "4D", "5D"],
    },
    {
      courseCode: "ENGN4720",
      pis: ["4A", "5A", "6A", "7A", "8A", "9A", "10A", "11A", "12A"],
    },
    {
      courseCode: "ENGN4840",
      pis: ["8D", "9D", "12D"],
    },
  ],
};

// Manually defined first and last names
const firstNames = [
  "Alex",
  "Chris",
  "Jordan",
  "Taylor",
  "Morgan",
  "Sam",
  "Casey",
  "Jamie",
  "Dakota",
  "Skyler",
  "Riley",
  "Avery",
  "Parker",
  "Cameron",
  "Devin",
  "Reese",
  "Quinn",
  "Blake",
  "Drew",
  "Hayden",
];

const lastNames = [
  "Smith",
  "Johnson",
  "Brown",
  "Taylor",
  "Anderson",
  "Thomas",
  "Jackson",
  "White",
  "Harris",
  "Martin",
  "Thompson",
  "Garcia",
  "Martinez",
  "Robinson",
  "Clark",
  "Rodriguez",
  "Lewis",
  "Lee",
  "Walker",
  "Hall",
];
