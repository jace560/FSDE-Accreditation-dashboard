import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  typescript: {
    ignoreBuildErrors: true, // ✅ Disables TypeScript errors during builds
  },
  eslint: {
    ignoreDuringBuilds: true, // ✅ Disables ESLint during builds
  },
};

export default nextConfig;
