import type { Config } from 'jest'
import nextJest from 'next/jest.js'

const createJestConfig = nextJest({
    // Provide the path to your Next.js app to load next.config.js and .env files in your test environment
    dir: './',
})

const config: Config =  {
    preset: 'ts-jest',
    testEnvironment: 'node',
    testPathIgnorePatterns: ['/node_modules/'],
    globals: { 'ts-jest': { diagnostics: false } },

    transform: {
        //transform_regex: ['ts-jest', { /* ts-jest config goes here in Jest */ }],
    },
    moduleNameMapper: {
        // ...
        '^@/(.*)$': '<rootDir>/$1',
    }
}

export default createJestConfig(config)