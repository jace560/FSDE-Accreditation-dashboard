import prisma from "@/lib/prisma";
import logger from "@/lib/logger";
import { GetCoursesQuery, CourseInformationSheet } from "@/types/index";
import { NextRequest, NextResponse } from "next/server";
import { SemesterType } from "@/types";
import { v4 as uuidv4 } from "uuid";
import { Prisma } from "@prisma/client";

const isValidSemester = (value: string): value is SemesterType =>
  ["Winter", "Spring", "Summer", "Fall"].includes(value);

export async function GET(req: NextRequest) {
  const { searchParams } = new URL(req.url);

  // Extract query parameters with type safety using GetCoursesQuery
  const query: GetCoursesQuery & { page?: string; limit?: string } = {
    programId: searchParams.get("programId") || undefined,
    campusId: searchParams.get("campusId") || undefined,
    year: searchParams.get("year") || undefined,
    semester: searchParams.get("semester") || undefined,
    page: searchParams.get("page") || "1",
    limit: searchParams.get("limit") || "10",
    courseNameQuery: searchParams.get("courseNameQuery") || undefined,
  };

  const offset =
    (parseInt(query.page as string, 10) - 1) *
    parseInt(query.limit as string, 10);

  logger.info("Fetching courses with query parameters", query);

  try {
    const courses = await prisma.course.findMany({
      where: {
        ...(query.programId && {
          Campus: { Programs: { some: { ProgramID: query.programId } } },
        }),
        ...(query.campusId && { CampusID: query.campusId }),
        ...(query.year && { Year: query.year as string }),
        ...(query.semester &&
          isValidSemester(query.semester) && {
            SemesterName: query.semester as SemesterType,
          }),
        OR: query.courseNameQuery
          ? [
              {
                CourseCode: {
                  contains: query.courseNameQuery,
                  mode: "insensitive",
                },
              },
              {
                CourseName: {
                  contains: query.courseNameQuery,
                  mode: "insensitive",
                },
              },
            ]
          : undefined,
      },
      select: {
        CourseID: true,
        CourseCode: true,
        CourseName: true,
        Year: true,
        SemesterName: true,
        SectionNumber: true,
        Campus: {
          select: {
            CampusName: true,
            CampusID: true,
          },
        },
      },
      orderBy: [
        { Year: "desc" },
        { CourseName: "asc" },
        { SemesterName: "asc" },
        { SectionNumber: "asc" },
      ],
      skip: offset,
      take: parseInt(query.limit as string, 10),
    });

    if (!query.programId && !query.campusId && !query.year && !query.semester) {
      logger.info(
        "No filters provided, fetching courses from latest year downwards"
      );
    }

    const totalCourses = await prisma.course.count({
      where: {
        ...(query.programId && {
          Campus: { Programs: { some: { ProgramID: query.programId } } },
        }),
        ...(query.campusId && { CampusID: query.campusId }),
        ...(query.year && { Year: query.year as string }),
        ...(query.semester &&
          isValidSemester(query.semester) && {
            SemesterName: query.semester as SemesterType,
          }),
      },
    });

    const totalPages = Math.ceil(
      totalCourses / parseInt(query.limit as string, 10)
    );

    return NextResponse.json({
      data: courses,
      meta: {
        total: totalCourses,
        page: parseInt(query.page as string, 10),
        totalPages,
        limit: parseInt(query.limit as string, 10),
      },
    });
  } catch (error) {
    logger.error(`Error fetching courses: ${error}`);
    return NextResponse.json(
      { error: "Failed to fetch courses" },
      { status: 500 }
    );
  } finally {
    logger.info("Disconnecting Prisma client");
    await prisma.$disconnect();
  }
}

export async function POST(req: NextRequest) {
  try {
    logger.info("Received bulk POST request for CourseInformationSheets");

    const reqJson = await req.json();

    const { courseInformationSheets } = reqJson as {
      courseInformationSheets: CourseInformationSheet[];
    };

    if (
      !Array.isArray(courseInformationSheets) ||
      courseInformationSheets.length === 0
    ) {
      return NextResponse.json(
        {
          error: "Invalid input. Expected an array of CourseInformationSheets.",
        },
        { status: 400 }
      );
    }

    // **Run validation first (Throws an error if validation fails)**
    validateCourseInformationSheets(courseInformationSheets);

    logger.info(
      `Processing ${courseInformationSheets.length} course information sheets.`
    );

    const results = await prisma.$transaction(
      async (tx) => {
        const processedResults = [];

        for (const sheet of courseInformationSheets) {
          const { Course, ProgramID, CampusID } = sheet;

          // **Check for duplicate (If found, throw an error to fail everything)**
          const existingCourse = await tx.course.findFirst({
            where: {
              CourseName: Course.CourseName,
              CourseCode: Course.CourseCode,
              Year: Course.Year,
              SectionNumber: Course.SectionNumber,
              SemesterName: Course.SemesterName,
              CampusID,
              Campus: {
                Programs: {
                  some: {
                    ProgramID: ProgramID,
                  },
                },
              },
            },
          });

          if (existingCourse) {
            logger.warn(`Duplicate detected for ${Course.CourseCode}`);
            throw new Error(`Duplicate course detected: ${Course.CourseCode}`);
          }
          const mappingVersion = uuidv4();
          // **Insert Course**
          const createdCourse = await tx.course.create({
            data: {
              CourseCode: Course.CourseCode,
              CourseName: Course.CourseName,
              CampusID,
              SemesterName: Course.SemesterName,
              SectionNumber: Course.SectionNumber,
              Year: Course.Year,
            },
          });

          // **Insert Learning Objectives**
          const createdLearningObjectives = await Promise.all(
            Course.LearningObjectives.map(async (objective) => {
              return tx.learningObjective.create({
                data: {
                  LOName: objective.LOName,
                  CourseID: createdCourse.CourseID,
                  MappingVersion: mappingVersion,
                  Description: objective?.LODescription || "",
                  PerformanceIndicatorMappings: {
                    create:
                      objective.LearningObjectivePerformanceIndicatorMappings.map(
                        (piMapping) => {
                          const numberPart = piMapping.PIName.match(/\d+/)?.[0];
                          const letterPart =
                            piMapping.PIName.match(/[A-Z]/)?.[0];
                          if (!numberPart || !letterPart) {
                            logger.warn(
                              `Invalid PIName format: ${piMapping.PIName}`
                            );
                            throw new Error(
                              `Invalid PIName format: ${piMapping.PIName}`
                            );
                          }
                          return {
                            PILevel: letterPart,
                            GraduateAttribute: {
                              connect: { GANumber: parseInt(numberPart, 10) },
                            },
                            Course: {
                              connect: { CourseID: createdCourse.CourseID },
                            },
                          };
                        }
                      ),
                  },
                },
              });
            })
          );

          // **Insert Assessment Tools**
          const createdAssessmentTools = await Promise.all(
            Course.AssessmentTools.map(async (tool) => {
              console.log(tool, "TOOLS");
              return tx.assessmentTool.create({
                data: {
                  ATName: tool.ATName,
                  Weight: tool.Weight,
                  Description: tool.Description,
                  CourseID: createdCourse.CourseID,
                  MappingVersion: mappingVersion,
                  LearningObjectiveMappings: {
                    create: tool.AssessmentToolLearningObjectiveMappings.map(
                      (mapping) => {
                        const linkedLearningObjective =
                          createdLearningObjectives.find(
                            (lo) => lo.LOName === mapping.LOName
                          );
                        if (!linkedLearningObjective) {
                          logger.warn(
                            `LearningObjective ${mapping.LOName} not found`
                          );
                          throw new Error(
                            `LearningObjective ${mapping.LOName} not found`
                          );
                        }
                        return {
                          Weight: mapping.Weight,
                          LOID: linkedLearningObjective.LOID,
                          CourseID: createdCourse.CourseID,
                        };
                      }
                    ),
                  },
                },
              });
            })
          );

          processedResults.push({
            CourseCode: Course.CourseCode,
            status: "Success",
            createdCourse,
            createdLearningObjectives: createdLearningObjectives.length,
            createdAssessmentTools: createdAssessmentTools,
          });

          logger.info(`Successfully inserted ${Course.CourseCode}`);
        }

        return processedResults;
      },
      {
        timeout: 30000,
        maxWait: 20000,
      }
    );

    return NextResponse.json({ results }, { status: 201 });
  } catch (error: unknown) {
    logger.error(`Error processing bulk course upload: ${error}`);

    if (error instanceof Prisma.PrismaClientKnownRequestError) {
      switch (error.code) {
        case "P2002": // Unique constraint failed
          return NextResponse.json(
            {
              error:
                "Duplicate entry detected. A course with this code already exists.",
              details: error.meta,
            },
            { status: 409 }
          );
        case "P2003": // Foreign key constraint failed
          return NextResponse.json(
            {
              error:
                "Foreign key constraint failed. Check ProgramID and CampusID.",
              details: error.meta,
            },
            { status: 422 }
          );
        default:
          return NextResponse.json(
            { error: "Database error occurred.", details: error.message },
            { status: 500 }
          );
      }
    }

    // Ensure error has a message property before accessing it
    if (error instanceof Error) {
      if (error.message.startsWith("Duplicate course detected")) {
        return NextResponse.json({ error: error.message }, { status: 409 });
      }

      return NextResponse.json({ error: error.message }, { status: 500 });
    }

    // If error is unknown and not an instance of Error
    return NextResponse.json(
      { error: "Unexpected error occurred." },
      { status: 500 }
    );
  } finally {
    logger.info("Disconnecting Prisma client after bulk insert operation");
    await prisma.$disconnect();
  }
}

function validateCourseInformationSheets(
  dataArray: CourseInformationSheet[]
): void {
  const allErrors: { courseIndex: number; errors: string[] }[] = [];
  const seenCourseCodes = new Set<string>(); // Track unique CourseCodes

  logger.info(
    `Starting validation for ${dataArray.length} CourseInformationSheets`
  );

  dataArray.forEach((data, index) => {
    const errors: string[] = [];

    logger.info(`Validating course at index ${index}`);

    // **Top-Level Validation**
    if (!data.ProgramID || data.ProgramID.trim() === "") {
      errors.push("Missing or empty ProgramID");
    }

    if (!data.CampusID || data.CampusID.trim() === "") {
      errors.push("Missing or empty CampusID");
    }

    const course = data.Course;

    if (!course) {
      errors.push("Missing Course data");
      allErrors.push({ courseIndex: index, errors });
      return; // Stop further validation for this entry
    }

    logger.info(`Validating fields for course at index ${index}`);

    // **Course Fields Validation**
    if (!course.CourseCode || course.CourseCode.trim() === "") {
      errors.push("Missing or empty CourseCode");
    } else {
      // **Duplicate CourseCode Check**
      if (seenCourseCodes.has(course.CourseCode.trim())) {
        errors.push(`Duplicate CourseCode detected: ${course.CourseCode}`);
      } else {
        seenCourseCodes.add(course.CourseCode.trim()); // Add to set
      }
    }

    if (!course.CourseName || course.CourseName.trim() === "") {
      errors.push("Missing or empty CourseName");
    }

    if (!course.SemesterName || course.SemesterName.trim() === "") {
      errors.push("Missing or empty SemesterName");
    }

    if (course.SectionNumber === undefined || course.SectionNumber === null) {
      errors.push("Missing SectionNumber");
    }

    if (!course.Year || course.Year.trim() === "") {
      errors.push("Missing or empty Year");
    }

    // **AssessmentTools Validation**
    logger.info(`Validating AssessmentTools for course at index ${index}`);
    if (
      !Array.isArray(course.AssessmentTools) ||
      course.AssessmentTools.length === 0
    ) {
      errors.push("Missing or empty AssessmentTools array");
    } else {
      course.AssessmentTools.forEach((tool, toolIndex) => {
        if (!tool.ATName || tool.ATName.trim() === "") {
          errors.push(
            `Missing or empty ATName in AssessmentTool at index ${toolIndex}`
          );
        }

        if (tool.Weight === undefined || tool.Weight === null) {
          errors.push(`Missing Weight in AssessmentTool at index ${toolIndex}`);
        }

        if (!tool.Description || tool.Description.trim() === "") {
          errors.push(
            `Missing or empty Description in AssessmentTool at index ${toolIndex}`
          );
        }

        if (
          !Array.isArray(tool.AssessmentToolLearningObjectiveMappings) ||
          tool.AssessmentToolLearningObjectiveMappings.length === 0
        ) {
          errors.push(
            `Missing or empty AssessmentToolLearningObjectiveMappings in AssessmentTool at index ${toolIndex}`
          );
        } else {
          tool.AssessmentToolLearningObjectiveMappings.forEach(
            (mapping, mappingIndex) => {
              if (!mapping.LOName || mapping.LOName.trim() === "") {
                errors.push(
                  `Missing or empty LOName in AssessmentToolLearningObjectiveMapping at index ${mappingIndex} in AssessmentTool at index ${toolIndex}`
                );
              }

              if (mapping.Weight === undefined || mapping.Weight === null) {
                errors.push(
                  `Missing Weight in AssessmentToolLearningObjectiveMapping at index ${mappingIndex} in AssessmentTool at index ${toolIndex}`
                );
              }
            }
          );
        }
      });
    }

    // **LearningObjectives Validation**
    logger.info(`Validating LearningObjectives for course at index ${index}`);
    if (
      !Array.isArray(course.LearningObjectives) ||
      course.LearningObjectives.length === 0
    ) {
      errors.push("Missing or empty LearningObjectives array");
    } else {
      course.LearningObjectives.forEach((objective, objectiveIndex) => {
        if (!objective.LOName || objective.LOName.trim() === "") {
          errors.push(
            `Missing or empty LOName in LearningObjective at index ${objectiveIndex}`
          );
        }

        if (
          !Array.isArray(
            objective.LearningObjectivePerformanceIndicatorMappings
          ) ||
          objective.LearningObjectivePerformanceIndicatorMappings.length === 0
        ) {
          errors.push(
            `Missing or empty LearningObjectivePerformanceIndicatorMappings in LearningObjective at index ${objectiveIndex}`
          );
        } else {
          objective.LearningObjectivePerformanceIndicatorMappings.forEach(
            (mapping, mappingIndex) => {
              if (!mapping.PIName || mapping.PIName.trim() === "") {
                errors.push(
                  `Missing or empty PIName in LearningObjectivePerformanceIndicatorMapping at index ${mappingIndex} in LearningObjective at index ${objectiveIndex}`
                );
              }
            }
          );
        }
      });
    }

    if (errors.length > 0) {
      allErrors.push({ courseIndex: index, errors });
    }
  });

  if (allErrors.length > 0) {
    logger.error(
      `Validation failed for ${allErrors.length} courses. Throwing error.`
    );
    throw new Error(
      JSON.stringify({
        error: "Validation failed for some courses.",
        details: allErrors,
      })
    );
  }

  logger.info(`Validation completed successfully. No errors found.`);
}

export async function DELETE(req: NextRequest) {
  try {
    logger.info("Received DELETE request to remove a course");

    // Parse course ID from query parameters
    const { searchParams } = new URL(req.url);
    const courseId = searchParams.get("courseId");

    if (!courseId) {
      logger.warn("Course ID is missing in the request");
      return NextResponse.json(
        { error: "Missing required parameter: courseId" },
        { status: 400 }
      );
    }

    logger.info(`Attempting to delete course with ID: ${courseId}`);

    // Check if the course exists
    const course = await prisma.course.findUnique({
      where: { CourseID: courseId },
      include: {
        AssessmentTools: true,
        LearningObjectives: true,
      },
    });

    if (!course) {
      logger.warn(`Course with ID ${courseId} does not exist`);
      return NextResponse.json(
        { error: `Course with ID ${courseId} not found` },
        { status: 404 }
      );
    }

    logger.info(
      `Course found with ID: ${courseId}, proceeding to delete associated data`
    );

    // Perform deletion within a transaction
    await prisma.$transaction(async (tx) => {
      logger.info(`Deleting Course with ID: ${courseId}`);
      await tx.course.delete({
        where: { CourseID: courseId },
      });

      logger.info(
        `Successfully deleted course and associated data for ID: ${courseId}`
      );
    });

    return NextResponse.json(
      {
        message: `Course with ID ${courseId} and all related data deleted successfully`,
      },
      { status: 200 }
    );
  } catch (error) {
    logger.error(`Error deleting course: ${error}`);

    // Handle unexpected errors
    if (error instanceof Error) {
      return NextResponse.json(
        { error: error.message || "Failed to delete course" },
        { status: 500 }
      );
    } else {
      return NextResponse.json(
        { error: "Unexpected error occurred" },
        { status: 500 }
      );
    }
    //.
  } finally {
    logger.info("Disconnecting Prisma client after DELETE operation");
    await prisma.$disconnect();
  }
}

export async function PUT(req: Request) {
  try {
    logger.info("Received PUT request for Student Grades");

    const body = await req.json();
    const { ProgramID, CourseID, Grades } = body;

    // Check if ProgramID is missing
    if (!ProgramID) {
      logger.error("Missing ProgramID");
      return NextResponse.json(
        { error: "ProgramID is required." },
        { status: 400 }
      );
    }

    // Check if CourseID is missing
    if (!CourseID) {
      logger.error("Missing CourseID");
      return NextResponse.json(
        { error: "CourseID is required." },
        { status: 400 }
      );
    }

    // Check if Grades is missing
    if (!Grades) {
      logger.error("Missing Grades");
      return NextResponse.json(
        { error: "Grades are required." },
        { status: 400 }
      );
    }

    // Check if Grades is not an array
    if (!Array.isArray(Grades)) {
      logger.error("Grades should be an array");
      return NextResponse.json(
        { error: "Grades must be an array." },
        { status: 400 }
      );
    }

    // Check if Grades array is empty
    if (Grades.length === 0) {
      logger.error("Grades array is empty");
      return NextResponse.json(
        { error: "Grades array cannot be empty." },
        { status: 400 }
      );
    }

    // Validate the lengths of ProgramID and CourseID
    if (ProgramID.length !== 36) {
      logger.error("Invalid ProgramID length", { ProgramID });
      return NextResponse.json(
        { error: "ProgramID must be 36 characters long." },
        { status: 400 }
      );
    }

    if (CourseID.length !== 36) {
      logger.error("Invalid CourseID length", { CourseID });
      return NextResponse.json(
        { error: "CourseID must be 36 characters long." },
        { status: 400 }
      );
    }
    // Validate each grade object in the Grades array
    for (const grade of Grades) {
      const { StudentIdentifier, ATID, GradePercentage } = grade;

      // Check if StudentIdentifier is missing
      if (!StudentIdentifier) {
        logger.error("Missing StudentIdentifier");
        return NextResponse.json(
          { error: "StudentIdentifier is required." },
          { status: 400 }
        );
      }

      // Check if ATID is missing
      if (!ATID) {
        logger.error("Missing ATID");
        return NextResponse.json(
          { error: "ATID is required." },
          { status: 400 }
        );
      }

      // Validate StudentIdentifier length
      if (StudentIdentifier.length !== 36) {
        logger.error("Invalid StudentIdentifier length", { StudentIdentifier });
        return NextResponse.json(
          {
            error: `StudentIdentifier must be 36 characters long: ${StudentIdentifier}`,
          },
          { status: 400 }
        );
      }

      // Validate ATID length
      if (ATID.length !== 36) {
        logger.error("Invalid ATID length", { ATID });
        return NextResponse.json(
          { error: `ATID must be 36 characters long: ${ATID}` },
          { status: 400 }
        );
      }

      // Check if GradePercentage is undefined
      if (GradePercentage === undefined) {
        logger.error("Missing GradePercentage");
        return NextResponse.json(
          { error: "GradePercentage is required." },
          { status: 400 }
        );
      }
    }
    return await prisma.$transaction(async (tx) => {
      logger.info(
        `Searching for course with ProgramID: ${ProgramID} and CourseID: ${CourseID}...`
      );

      // Check if ProgramID exists
      const programExists = await tx.program.findUnique({
        where: { ProgramID },
        select: { ProgramID: true },
      });

      if (!programExists) {
        logger.error(`Program not found: ProgramID ${ProgramID}`);
        return NextResponse.json(
          { error: "Program not found." },
          { status: 404 }
        );
      }

      // Check if CourseID exists
      const course = await tx.course.findFirst({
        where: {
          CourseID,
          Campus: {
            Programs: {
              some: { ProgramID },
            },
          },
        },
        select: { CourseID: true, CourseCode: true, CourseName: true },
      });

      if (!course) {
        logger.error(
          `Course not found for ProgramID: ${ProgramID} and CourseID: ${CourseID}`
        );
        return NextResponse.json(
          { error: "Course not found for the given ProgramID." },
          { status: 404 }
        );
      }

      logger.info(
        `Found course ${course.CourseCode} - ${course.CourseName}. Deleting existing grades for CourseID: ${CourseID}...`
      );

      // Extract all StudentIdentifiers from the request body
      const studentIdentifiers = Grades.map((grade) => grade.StudentIdentifier);

      // Check if all StudentIdentifiers exist in the database
      const existingStudents = await tx.grade.findMany({
        where: { StudentIdentifier: { in: studentIdentifiers } },
        select: { StudentIdentifier: true },
      });

      // Convert existing student identifiers to a Set for quick lookup
      const validStudentSet = new Set(
        existingStudents.map((student) => student.StudentIdentifier)
      );

      // Find any invalid StudentIdentifiers
      const invalidStudents = studentIdentifiers.filter(
        (id) => !validStudentSet.has(id)
      );

      if (invalidStudents.length > 0) {
        logger.error(
          `Invalid Student Identifiers found: ${invalidStudents.join(", ")}`
        );
        return NextResponse.json(
          {
            error: `Invalid Student Identifiers: ${invalidStudents.join(", ")}`,
          },
          { status: 400 }
        );
      }

      // Delete previous grades
      await tx.grade.deleteMany({
        where: { CourseID },
      });

      logger.info("Previous grades deleted. Inserting new grades...");

      // Check if ATIDs exist
      const uniqueATIDs = [...new Set(Grades.map((grade) => grade.ATID))];
      const existingATIDs = await tx.assessmentTool.findMany({
        where: { ATID: { in: uniqueATIDs } },
        select: { ATID: true, Weight: true }, // Fetching Weight for calculation
      });

      const existingATIDMap = new Map(
        existingATIDs.map((at) => [at.ATID, at.Weight])
      );
      const missingATIDs = uniqueATIDs.filter((at) => !existingATIDMap.has(at));

      if (missingATIDs.length > 0) {
        logger.error(
          `Assessment Tools not found for ATIDs: ${missingATIDs.join(", ")}`
        );
        return NextResponse.json(
          { error: "Some ATIDs were not found.", missingATIDs },
          { status: 404 }
        );
      }

      // Insert new grades with weight-based adjustment
      const newGrades = Grades.map(
        (grade: {
          StudentIdentifier: string;
          ATID: string;
          GradePercentage: number;
        }) => ({
          StudentIdentifier: grade.StudentIdentifier,
          ATID: grade.ATID,
          CourseID,
          GradePercentage: existingATIDMap.has(grade.ATID)
            ? (existingATIDMap.get(grade.ATID) as number) *
              (grade.GradePercentage / 100)
            : 0, // Default to 0 if ATID is not found (shouldn't happen due to previous validation)
        })
      );

      await tx.grade.createMany({ data: newGrades });

      logger.info("New grades successfully inserted.");

      return NextResponse.json(
        {
          message: "Grades updated successfully.",
          CourseID,
          TotalGrades: Grades.length,
        },
        { status: 200 }
      );
    });
  } catch (error) {
    const err = error as Error; // Explicit type assertion for proper logging

    logger.error("Error updating student grades", {
      message: err.message,
      stack: err.stack,
    });

    return NextResponse.json(
      { error: "Internal Server Error", details: err.message },
      { status: 500 }
    );
  }
}
