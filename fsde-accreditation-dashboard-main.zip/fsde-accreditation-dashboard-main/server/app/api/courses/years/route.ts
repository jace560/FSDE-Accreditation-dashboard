import { getUniqueYears } from "@/lib/api/generic";
import logger from "@/lib/logger";
import prisma from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";

export async function GET(req: NextRequest) {
  try {
    logger.error(`Fetching unique years...`);

    const uniqueYears = await prisma.course.groupBy({
      by: ["Year"],
      orderBy: {
        Year: "desc",
      },
    });

    const years = uniqueYears.map((course) => course.Year);

    return NextResponse.json({
      years,
    });
  } catch (error) {
    logger.error(`Error fetching unique years: ${error}`);
    return NextResponse.json(
      { error: "Failed to fetch years" },
      { status: 500 }
    );
  } finally {
    logger.info("Disconnecting Prisma client");
  }
}
