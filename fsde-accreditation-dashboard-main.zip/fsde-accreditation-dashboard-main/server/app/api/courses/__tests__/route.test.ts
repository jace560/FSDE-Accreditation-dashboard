import { NextRequest } from "next/server";
import { PUT } from "@/app/api/courses/route";
import { jest } from "@jest/globals";
import prisma from "@/lib/prisma";
import { Course } from "@prisma/client";

jest.mock("@/lib/prisma", () => ({
    course: {
        findFirst: jest.fn(),
    },
    grade: {
        deleteMany: jest.fn(),
        createMany: jest.fn(),
    },
}));

const mockedPrisma = prisma as unknown as {
    course: {
        findFirst: jest.MockedFunction<() => Promise<Course | null>>;
    };
    grade: {
        deleteMany: jest.MockedFunction<() => Promise<{ count: number }>>;
        createMany: jest.MockedFunction<() => Promise<{ count: number }>>;
    };
};

describe("PUT /api/courses/:courseID", () => {
    beforeEach(() => {
        jest.clearAllMocks();
        jest.restoreAllMocks();

        // Reset Prisma mocks
        mockedPrisma.course.findFirst = jest.fn();
        mockedPrisma.grade.deleteMany = jest.fn();
        mockedPrisma.grade.createMany = jest.fn();
    });

    const createTestRequest = (courseID: string, body: { CourseID: string; ProgramID: string }) =>
        new NextRequest(`http://localhost:3000/api/courses/${courseID}`, {
            method: "PUT",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(body),
        });

    it("should return 200 when grades are successfully updated", async () => {
        // Start with real data
        const requestBody = {
            ProgramID: "d4fb1c6c-4250-472f-a974-a3e3d27f47cd",
            CourseID: "cd37c703-8216-4305-b429-bf364b85882c",
            Grades: [
                {
                    StudentIdentifier: "6117ea56-f259-486d-8058-a17d2a822142",
                    ATID: "e5a4b547-02fd-46dc-a335-8d7e4dc7d4e0",
                    GradePercentage: 85,
                },
            ],
        };

        mockedPrisma.course.findFirst.mockResolvedValueOnce({ CourseID: requestBody.CourseID } as Course);
        mockedPrisma.grade.deleteMany.mockResolvedValueOnce({ count: 0 });
        mockedPrisma.grade.createMany.mockResolvedValueOnce({ count: 1 });

        const req = createTestRequest(requestBody.CourseID, requestBody);

        const response = await PUT(req);
        const json = await response.json();

        expect(response.status).toBe(200);
        expect(json).toEqual({
            message: "Grades updated successfully.",
            CourseID: requestBody.CourseID,
            TotalGrades: 1,
        });
    });

    describe("PUT /api/courses/:courseID", () => {
        it("should return 404 if the course is not found", async () => {
            // Start with real data and modify the CourseID to simulate "not found"
            const requestBody = {
                ProgramID: "d4fb1c6c-4250-472f-a974-a3e3d27f47cd",
                CourseID: "00000000-0000-0000-0000-000000000000", // Invalid ID
                Grades: [
                    {
                        StudentIdentifier: "d619e4ec-1e2f-40ca-b429-b063498c4b42",
                        ATID: "53c0e56d-e355-40e4-ac34-b23f4e12229e",
                        GradePercentage: 85,
                    },
                ],
            };

            mockedPrisma.course.findFirst.mockResolvedValueOnce(null);

            const req = createTestRequest(requestBody.CourseID, requestBody);

            const response = await PUT(req);
            const json = await response.json();

            expect(response.status).toBe(404);
            expect(json).toEqual({ error: "Course not found for the given ProgramID." });
        });

        it("should return 400 if required fields are missing", async () => {
            // Start with real data and remove the 'Grades' field
            const requestBody = {
                ProgramID: "d0a530f9-d323-4d7a-81b6-b1c94b6b13bd",
                CourseID: "8ac72f1a-951f-40bc-92fb-32630b5f704b",
                // Missing 'Grades' field
            };

            const req = createTestRequest(requestBody.CourseID, requestBody);

            const response = await PUT(req);
            const json = await response.json();

            expect(response.status).toBe(400);
            expect(json).toEqual({error : "Grades are required."});
        });


        // Test missing StudentIdentifier
        it("should return 400 if StudentIdentifier is missing in Grades", async () => {
            const requestBody = {
                ProgramID: "d0a530f9-d323-4d7a-81b6-b1c94b6b13bd",
                CourseID: "8ac72f1a-951f-40bc-92fb-32630b5f704b",
                Grades: [
                    {
                        ATID: "53c0e56d-e355-40e4-ac34-b23f4e12229e",
                        GradePercentage: 85, // Missing StudentIdentifier
                    },
                ],
            };

            const req = createTestRequest(requestBody.CourseID, requestBody);

            const response = await PUT(req);
            const json = await response.json();

            expect(response.status).toBe(400);
            expect(json).toEqual({
                error: "StudentIdentifier is required.",
            });
        });

        // Test missing ATID
        it("should return 400 if ATID is missing in Grades", async () => {
            const requestBody = {
                ProgramID: "d0a530f9-d323-4d7a-81b6-b1c94b6b13bd",
                CourseID: "8ac72f1a-951f-40bc-92fb-32630b5f704b",
                Grades: [
                    {
                        StudentIdentifier: "1b9e3d1c-7dcc-465f-a766-c9d3f7b28b79",
                        GradePercentage: 85, // Missing ATID
                    },
                ],
            };

            const req = createTestRequest(requestBody.CourseID, requestBody);

            const response = await PUT(req);
            const json = await response.json();

            expect(response.status).toBe(400);
            expect(json).toEqual({
                error: "ATID is required.",
            });
        });

        // Test missing GradePercentage
        it("should return 400 if GradePercentage is missing in Grades", async () => {
            const requestBody = {
                ProgramID: "d0a530f9-d323-4d7a-81b6-b1c94b6b13bd",
                CourseID: "8ac72f1a-951f-40bc-92fb-32630b5f704b",
                Grades: [
                    {
                        StudentIdentifier: "1b9e3d1c-7dcc-465f-a766-c9d3f7b28b79",
                        ATID: "53c0e56d-e355-40e4-ac34-b23f4e12229e", // Missing GradePercentage
                    },
                ],
            };

            const req = createTestRequest(requestBody.CourseID, requestBody);

            const response = await PUT(req);
            const json = await response.json();

            expect(response.status).toBe(400);
            expect(json).toEqual({
                error: "GradePercentage is required.",
            });
        });

        it("should return 400 if StudentIdentifier length is invalid", async () => {
            const requestBody = {
                ProgramID: "d0a530f9-d323-4d7a-81b6-b1c94b6b13bd",
                CourseID: "8ac72f1a-951f-40bc-92fb-32630b5f704b",
                Grades: [
                    {
                        StudentIdentifier: "1234", // Invalid StudentIdentifier length
                        ATID: "53c0e56d-e355-40e4-ac34-b23f4e12229e",
                        GradePercentage: 85,
                    },
                ],
            };

            const req = createTestRequest(requestBody.CourseID, requestBody);

            const response = await PUT(req);
            const json = await response.json();

            expect(response.status).toBe(400);
            expect(json).toEqual({
                error: "StudentIdentifier must be 36 characters long: 1234",
            });
        });

        it("should return 400 if ATID length is invalid", async () => {
            const requestBody = {
                ProgramID: "d0a530f9-d323-4d7a-81b6-b1c94b6b13bd",
                CourseID: "8ac72f1a-951f-40bc-92fb-32630b5f704b",
                Grades: [
                    {
                        StudentIdentifier: "1b9e3d1c-7dcc-465f-a766-c9d3f7b28b79",
                        ATID: "1234", // Invalid ATID length
                        GradePercentage: 85,
                    },
                ],
            };

            const req = createTestRequest(requestBody.CourseID, requestBody);

            const response = await PUT(req);
            const json = await response.json();

            expect(response.status).toBe(400);
            expect(json).toEqual({
                error: "ATID must be 36 characters long: 1234",
            });
        });

        // Test invalid ProgramID length
        it("should return 400 if ProgramID length is incorrect", async () => {
            const requestBody = {
                ProgramID: "1234", // Invalid ProgramID length
                CourseID: "8ac72f1a-951f-40bc-92fb-32630b5f704b",
                Grades: [
                    {
                        StudentIdentifier: "1b9e3d1c-7dcc-465f-a766-c9d3f7b28b79",
                        ATID: "53c0e56d-e355-40e4-ac34-b23f4e12229e",
                        GradePercentage: 85,
                    },
                ],
            };

            const req = createTestRequest(requestBody.CourseID, requestBody);

            const response = await PUT(req);
            const json = await response.json();

            expect(response.status).toBe(400);
            expect(json).toEqual({
                error: "ProgramID must be 36 characters long.",
            });
        });

        // Test invalid CourseID length
        it("should return 400 if CourseID length is incorrect", async () => {
            const requestBody = {
                ProgramID: "d0a530f9-d323-4d7a-81b6-b1c94b6b13bd",
                CourseID: "1234", // Invalid CourseID length
                Grades: [
                    {
                        StudentIdentifier: "1b9e3d1c-7dcc-465f-a766-c9d3f7b28b79",
                        ATID: "53c0e56d-e355-40e4-ac34-b23f4e12229e",
                        GradePercentage: 85,
                    },
                ],
            };

            const req = createTestRequest(requestBody.CourseID, requestBody);

            const response = await PUT(req);
            const json = await response.json();

            expect(response.status).toBe(400);
            expect(json).toEqual({
                error: "CourseID must be 36 characters long.",
            });
        });
    });
});

