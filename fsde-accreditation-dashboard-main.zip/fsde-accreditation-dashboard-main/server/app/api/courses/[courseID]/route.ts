import { NextResponse } from "next/server";
import logger from "@/lib/logger";
import prisma from "@/lib/prisma";
import { UUID_REGEX } from "@/utils";
import {
  AssessmentTools,
  CourseInformationSheet,
  LearningObjective,
} from "@/types";
import { v4 as uuidv4 } from "uuid";

export async function GET(
  req: Request,
  { params }: { params: { courseID: string } }
) {
  try {
    const url = new URL(req.url);
    const mappingVersion = url.searchParams.get("mappingVersion");
    const courseId = await params.courseID;

    // Validate UUID format for courseId and mappingVersion
    if (!mappingVersion || !UUID_REGEX.test(mappingVersion)) {
      logger.error(`Invalid mappingVersion: ${mappingVersion}`);
      return NextResponse.json(
        {
          error: {
            message: "Invalid mappingVersion format. Must be a UUID.",
            status: 400,
          },
        },
        { status: 400 }
      );
    }

    if (!courseId || !UUID_REGEX.test(courseId)) {
      logger.error(`Invalid courseId: ${courseId}`);
      return NextResponse.json(
        {
          error: {
            message: "Invalid courseId format. Must be a UUID.",
            status: 400,
          },
        },
        { status: 400 }
      );
    }

    logger.info(`Validating existence of course and mapping version...`);

    // Check if the course and mapping version exist
    const course = await prisma.course.findFirst({
      where: {
        CourseID: courseId,
        AssessmentTools: {
          some: { MappingVersion: mappingVersion },
        },
      },
      select: {
        CourseID: true,
        AssessmentTools: {
          select: { ATID: true },
        },
      },
    });

    if (!course) {
      logger.error(
        `Course with ID ${courseId} and MappingVersion ${mappingVersion} not found.`
      );
      return NextResponse.json(
        {
          error: {
            message:
              "Course with the specified ID and mapping version not found.",
            status: 404,
          },
        },
        { status: 404 }
      );
    }

    logger.info(
      `Fetching assessment tools for CourseID: ${courseId} and MappingVersion: ${mappingVersion}...`
    );

    const assessmentToolsRaw = await prisma.assessmentTool.findMany({
      where: {
        MappingVersion: mappingVersion,
        CourseID: courseId,
      },
      include: {
        LearningObjectiveMappings: {
          select: {
            Weight: true,
            LearningObjective: {
              select: {
                LOID: true,
                LOName: true,
                Description: true,
              },
            },
          },
        },
      },
    });

    logger.info(`Fetched ${assessmentToolsRaw.length} assessment tools`);

    const learningObjectivesRaw = await prisma.learningObjective.findMany({
      where: {
        MappingVersion: mappingVersion,
        CourseID: courseId,
      },
      include: {
        PerformanceIndicatorMappings: {
          select: {
            PILevel: true,
            GraduateAttribute: true,
          },
        },
      },
    });

    logger.info(`Fetched ${learningObjectivesRaw.length} learning objectives`);

    logger.info("Processing assessment tools transformation...");

    // Transform `assessmentToolsRaw` into the `AssessmentTools` type
    const assessmentTools: AssessmentTools[] = assessmentToolsRaw.map((at) => {
      logger.debug(`Processing assessment tool: ${at.ATName}`);
      return {
        ATID: at.ATID,
        ATName: at.ATName,
        Weight: at.Weight,
        Description: at.Description,
        AssessmentToolLearningObjectiveMappings:
          at.LearningObjectiveMappings.map((mapping) => {
            logger.debug(
              `  Mapping LO: ${mapping.LearningObjective.LOName} with weight: ${mapping.Weight}`
            );
            return {
              Weight: mapping.Weight,
              LOName: mapping.LearningObjective.LOName,
            };
          }),
      };
    });

    logger.info("Processing learning objectives transformation...");

    // Transform `learningObjectivesRaw` into the `LearningObjective` type
    const formattedLearningObjectiveMappings: LearningObjective[] =
      learningObjectivesRaw.map((lo) => {
        logger.debug(`Processing learning objective: ${lo.LOName}`);
        return {
          LOID: lo.LOID,
          LOName: lo.LOName,
          LODescription: lo.Description,
          LearningObjectivePerformanceIndicatorMappings:
            lo.PerformanceIndicatorMappings.map((pi) => {
              const piName = `${pi.GraduateAttribute.GANumber}${pi.PILevel}`;
              logger.debug(`  Mapping PI: ${piName}`);
              return { PIName: piName };
            }),
        };
      });

    logger.info("Returning formatted response...");

    return NextResponse.json({
      AssessmentTools: assessmentTools,
      LearningObjectives: formattedLearningObjectiveMappings,
    });
  } catch (error) {
    logger.error(`Error fetching data: ${error}`);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
export async function PUT(
  req: Request,
  { params }: { params: { courseID: string } }
) {
  try {
    logger.info("Received PUT request", { courseID: params.courseID });
    const courseId = params.courseID;
    const body: CourseInformationSheet = await req.json();
    const { Course, ProgramID, CampusID } = body;

    // Validate UUID format
    if (!courseId || !UUID_REGEX.test(courseId)) {
      logger.error(`Invalid courseId: ${courseId}`);
      return NextResponse.json(
        {
          error: {
            message: "Invalid courseId format. Must be a UUID.",
            status: 400,
          },
        },
        { status: 400 }
      );
    }

    return await prisma.$transaction(
      async (tx) => {
        const campusProgram = await tx.campusProgram.findFirst({
          where: { CampusID: CampusID, ProgramID: ProgramID },
          include: {
            Campus: {
              include: {
                Courses: {
                  select: {
                    CourseName: true,
                    CourseCode: true,
                    Year: true,
                    SemesterName: true,
                    CourseID: true,
                    LearningObjectives: true,
                    SectionNumber: true,
                  },
                },
              },
            },
          },
        });
        const course =
          campusProgram &&
          campusProgram.Campus.Courses.find(
            (course) =>
              course.CourseName == Course.CourseName &&
              course.CourseCode == Course.CourseCode &&
              course.Year == Course.Year &&
              course.SemesterName == Course.SemesterName &&
              course.SectionNumber == Course.SectionNumber
          );
        logger.info(`Validating course metadata for CourseID: ${courseId}...`);

        if (!course) {
          logger.error("Course not found.", { courseID: courseId });
          return NextResponse.json(
            { error: "Course not found." },
            { status: 404 }
          );
        }
        logger.info("Deleting Course Related Grades....");

        tx.grade.deleteMany({
          where: { CourseID: courseId },
        });

        logger.info("Deleted Course Related Grades!");

        logger.info("Course metadata retrieved", { course });

        logger.info("Generating new MappingVersion UUID...");
        const newMappingVersion = uuidv4();

        logger.info("Updating existing mappings...");
        await tx.assessmentTool.updateMany({
          where: { CourseID: courseId },
          data: { IsCurrent: false },
        });
        await tx.learningObjective.updateMany({
          where: { CourseID: courseId },
          data: { IsCurrent: false },
        });

        logger.info("Inserting new Learning Objectives...");
        const createdLearningObjectives = await Promise.all(
          Course.LearningObjectives.map(async (objective) => {
            return tx.learningObjective.create({
              data: {
                LOName: objective.LOName,
                IsCurrent: true,
                CourseID: course.CourseID,
                MappingVersion: newMappingVersion,
                Description: objective?.LODescription || "",
                PerformanceIndicatorMappings: {
                  create:
                    objective.LearningObjectivePerformanceIndicatorMappings.map(
                      (piMapping) => {
                        const numberPart = piMapping.PIName.match(/\d+/)?.[0];
                        const letterPart = piMapping.PIName.match(/[A-Z]/)?.[0];

                        if (!numberPart || !letterPart) {
                          logger.warn(
                            `Invalid PIName format: ${piMapping.PIName}`
                          );
                          throw new Error(
                            `Invalid PIName format: ${piMapping.PIName}`
                          );
                        }

                        return {
                          PILevel: letterPart,
                          GraduateAttribute: {
                            connect: { GANumber: parseInt(numberPart, 10) },
                          },
                          Course: {
                            connect: { CourseID: course.CourseID },
                          },
                        };
                      }
                    ),
                },
              },
            });
          })
        );

        logger.info("Inserting new Assessment Tools...");
        const createdAssessmentTools = await Promise.all(
          Course.AssessmentTools.map(async (tool) => {
            return tx.assessmentTool.create({
              data: {
                ATName: tool.ATName,
                Weight: tool.Weight,
                Description: tool.Description,
                CourseID: course.CourseID,
                MappingVersion: newMappingVersion,
                LearningObjectiveMappings: {
                  create: tool.AssessmentToolLearningObjectiveMappings.map(
                    (mapping) => {
                      const linkedLearningObjective =
                        createdLearningObjectives.find(
                          (lo) => lo.LOName === mapping.LOName
                        );
                      if (!linkedLearningObjective) {
                        logger.warn(
                          `LearningObjective ${mapping.LOName} not found`
                        );
                        throw new Error(
                          `LearningObjective ${mapping.LOName} not found`
                        );
                      }
                      return {
                        Weight: mapping.Weight,
                        LOID: linkedLearningObjective.LOID,
                        CourseID: course.CourseID,
                      };
                    }
                  ),
                },
              },
            });
          })
        );

        logger.info("Mappings successfully updated.", {
          MappingVersion: newMappingVersion,
        });
        return NextResponse.json(
          {
            message: "Mappings updated successfully.",
            MappingVersion: newMappingVersion,
            createdAssessmentTools,
          },
          { status: 200 }
        );
      },
      {
        timeout: 30000,
        maxWait: 20000,
      }
    );
  } catch (error) {
    const err = error as Error;
    logger.error("Error updating mappings", {
      error: err.message,
      stack: err.stack,
    });

    return NextResponse.json(
      {
        error: "Internal Server Error",
        details: err.message,
      },
      { status: 500 }
    );
  }
}
