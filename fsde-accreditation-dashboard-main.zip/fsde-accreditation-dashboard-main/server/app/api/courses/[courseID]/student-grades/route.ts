import { z } from "zod";
import logger from "@/lib/logger";
import prisma from "@/lib/prisma";
import { NextRequest, NextResponse } from "next/server";
import { GradeRequestSchema, UUID_REGEX } from "@/utils";
import { GradeRequestDto } from "@/types";

// Define the Zod schema for validation

export async function PUT(req: NextRequest) {
  try {
    logger.info("📩 Received PUT request for Student Grades");

    // ✅ Parse JSON body
    const body = await req.json();

    // ✅ Validate request body using Zod
    const parsedBody = GradeRequestSchema.safeParse(body);

    if (!parsedBody.success) {
      logger.error("❌ Invalid request body", parsedBody.error.flatten());
      return NextResponse.json(
        {
          error: "Invalid request format",
          details: parsedBody.error.flatten(),
        },
        { status: 400 }
      );
    }

    // ✅ Extract validated data
    const { programID, courseID, campusID, studentGradeSheet } =
      parsedBody.data;

    // ✅ Start Transaction
    return await prisma.$transaction(async (tx) => {
      logger.info(
        `🔍 Searching for Program: ${programID} and Course: ${courseID}...`
      );

      // Check if Program exists
      const programExists = await tx.program.findUnique({
        where: { ProgramID: programID },
        select: { ProgramID: true },
      });

      if (!programExists) {
        logger.error(`🚨 Program not found: ${programID}`);
        return NextResponse.json(
          { error: "Program not found." },
          { status: 404 }
        );
      }

      // Check if Course exists
      const course = await tx.course.findFirst({
        where: {
          CourseID: courseID,
          Campus: { Programs: { some: { ProgramID: programID } } },
        },
        select: { CourseID: true, CourseCode: true, CourseName: true },
      });

      if (!course) {
        logger.error(
          `🚨 Course not found for ProgramID: ${programID} and CourseID: ${courseID}`
        );
        return NextResponse.json(
          { error: "Course not found for the given ProgramID." },
          { status: 404 }
        );
      }

      logger.info(
        `✅ Found Course: ${course.CourseCode} - ${course.CourseName}. Validating Assessment Tools...`
      );

      // Extract unique ATNames from request
      const atNamesInRequest = [
        ...new Set(
          studentGradeSheet.flatMap((grade) =>
            grade.Grades.map((g) => g.ATName)
          )
        ),
      ];

      console.log(atNamesInRequest, "atNamesInRequest");

      // Fetch Assessment Tools for this Course
      const existingATs = await tx.assessmentTool.findMany({
        where: {
          CourseID: courseID,
          IsCurrent: true,
        },
        select: {
          ATID: true,
          ATName: true,
          Weight: true,
        },
      });

      console.log(existingATs, "existingATS");

      // Create a Set of existing AT Names for validation
      const validATNamesSet = new Set(existingATs.map((at) => at.ATName));

      // Find AT Names that do not exist in the course
      const invalidATNames = atNamesInRequest.filter(
        (atName) => !validATNamesSet.has(atName)
      );

      if (invalidATNames.length > 0) {
        logger.error(
          `🚨 Invalid Assessment Tools for Course: ${invalidATNames.join(", ")}`
        );
        return NextResponse.json(
          {
            error: "Some assessment tools do not belong to this course.",
            invalidATNames,
          },
          { status: 400 }
        );
      }

      logger.info(
        "✅ Assessment Tools validation passed. Deleting previous grades..."
      );

      // Delete previous grades
      await tx.grade.deleteMany({ where: { CourseID: courseID } });

      logger.info("✅ Previous grades deleted. Inserting new grades...");

      // Map ATNames to ATIDs
      const atMap = new Map(
        existingATs.map((at) => [
          at.ATName,
          { ATID: at.ATID, Weight: at.Weight },
        ])
      );

      // Insert new grades
      const newGrades = studentGradeSheet.flatMap((grade) =>
        grade.Grades.map((studentGrade) => ({
          StudentIdentifier: grade.StudentIdentifier,
          ATID: atMap.get(studentGrade.ATName)!.ATID,
          CourseID: courseID,
          GradePercentage:
            (atMap.get(studentGrade.ATName)!.Weight ?? 1) *
            (studentGrade.GradePercentage / 100),
        }))
      );

      await tx.grade.createMany({ data: newGrades });

      logger.info("✅ New grades successfully inserted.");

      return NextResponse.json(
        {
          message: "Grades updated successfully.",
          courseID,
          totalGrades: newGrades.length,
        },
        { status: 200 }
      );
    });
  } catch (error: unknown) {
    logger.error("❌ Error updating student grades", {
      message: (error as Error).message,
      stack: (error as Error).stack,
    });
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
