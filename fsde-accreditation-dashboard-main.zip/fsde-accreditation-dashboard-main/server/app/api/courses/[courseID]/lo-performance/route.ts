import {
  calculateLODistributionWithPercentages,
  calculateStudentGradesUnderLO,
} from "@/lib/api/generic";
import logger from "@/lib/logger";
import prisma from "@/lib/prisma";
import { ApiResponse, GetCourseDetailsParamsQuery } from "@/types";
import {
  AllLODistributionsWithPercentages,
  AllStudentLOGrades,
  ATLOContribution,
  ATLOWeightsByLO,
  NormalizedATLOWeightsByLO,
} from "@/types/weights";
import { NextRequest, NextResponse } from "next/server";

export async function GET(
  req: NextRequest,
  { params }: { params: { courseID: string } }
) {
  const { courseID } = params;
  const mappingVersion = req.nextUrl.searchParams.get("mappingVersion");

  logger.info(
    `Received request for CourseID: ${courseID} and MappingVersion: ${mappingVersion}`
  );

  // Validate inputs
  if (!courseID || !mappingVersion) {
    logger.error(
      "Missing required query parameters: courseID or mappingVersion."
    );
    return NextResponse.json<ApiResponse<null>>(
      {
        error: {
          message:
            "Missing required query parameters: courseID and mappingVersion.",
          status: 400,
        },
      },
      { status: 400 }
    );
  }

  try {
    // Step 1: Verify Course ID and Mapping Version
    logger.info("Verifying if the course and mapping version exist...");
    const course = await prisma.course.findFirst({
      where: {
        CourseID: courseID,
        AssessmentTools: {
          some: { MappingVersion: mappingVersion },
        },
      },
      select: {
        CourseID: true,
        AssessmentTools: {
          select: { ATID: true },
        },
      },
    });

    if (!course) {
      logger.error(
        `Course with ID ${courseID} and MappingVersion ${mappingVersion} not found.`
      );
      return NextResponse.json<ApiResponse<null>>(
        {
          error: {
            message:
              "Course with the specified ID and mapping version not found.",
            status: 404,
          },
        },
        { status: 404 }
      );
    }

    logger.info(
      `Course with ID ${courseID} found and MappingVersion is valid.`
    );

    // Step 2: Verify if grades exist for the course
    logger.info(`Checking if grades exist for CourseID: ${courseID}...`);
    const gradesCount = await prisma.grade.count({
      where: { CourseID: courseID },
    });

    if (gradesCount === 0) {
      logger.error(`No grades found for CourseID: ${courseID}.`);
      return NextResponse.json<ApiResponse<any>>(
        {
          data: [],
        },
        { status: 200 }
      );
    }

    logger.info(`Found ${gradesCount} grades for CourseID: ${courseID}.`);

    // Step 3: Calculate student grades under each LO
    logger.info(
      `Calculating student grades under each Learning Objective (LO) for CourseID: ${courseID}...`
    );
    const studentLOGrades = await calculateStudentGradesUnderLO(
      courseID,
      mappingVersion
    );

    if (!studentLOGrades || Object.keys(studentLOGrades).length === 0) {
      return NextResponse.json<ApiResponse<any>>(
        {
          data: [],
        },
        { status: 200 }
      );
    }
    logger.info(
      `Successfully calculated student grades under LOs for CourseID: ${courseID}.`
    );

    // Step 4: Calculate LO distribution with percentages
    logger.info(
      `Calculating LO distribution percentages for CourseID: ${courseID}...`
    );
    const loDistribution = await calculateLODistributionWithPercentages(
      studentLOGrades
    );
    logger.info(
      `Successfully calculated LO distribution percentages for CourseID: ${courseID}.`
    );

    const sorted = Object.entries(loDistribution).sort(([, a], [, b]) =>
      a.LOName.localeCompare(b.LOName)
    );
    logger.info(`Returning LO distribution for CourseID: ${courseID}.`);

    const sortedObj = Object.fromEntries(sorted);
    return NextResponse.json<ApiResponse<typeof sortedObj>>(
      { data: sortedObj },
      { status: 200 }
    );

    // Return the LO distribution
  } catch (error) {
    logger.error(
      `Failed to calculate LO distribution for CourseID: ${courseID}. Error: ${error}`
    );
    return NextResponse.json<ApiResponse<null>>(
      {
        error: {
          message: "Failed to calculate LO distribution.",
          status: 500,
        },
      },
      { status: 500 }
    );
  }
}
