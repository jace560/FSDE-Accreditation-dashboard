import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import { Program } from "@prisma/client";

export async function GET() {
  try {
    const programs = await prisma.program.findMany({
      include: {
        Campuses: {
          include: {
            Campus: {
              include: {
                Courses: true,
              },
            },
          },
        },
      },
    });

    return NextResponse.json(programs, { status: 200 });
  } catch (error: any) {
    return NextResponse.json({ error: error.message }, { status: 500 });
  }
}
