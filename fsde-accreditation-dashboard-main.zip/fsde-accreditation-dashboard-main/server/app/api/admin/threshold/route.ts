import { NextRequest, NextResponse } from 'next/server';
import prisma from '@/lib/prisma';
import { ThresholdUpdateRequest } from '@/types';


export async function POST(req: NextRequest) {
  try {
    const body: ThresholdUpdateRequest = await req.json();

    if (!body.thresholds || body.thresholds.length !== 4) {
      return NextResponse.json(
        { error: 'Exactly four thresholds must be provided.' },
        { status: 400 }
      );
    }
    // Convert to object for easy validation
    const thresholdMap = body.thresholds.reduce((acc, threshold) => {
      acc[threshold.thresholdName] = threshold.thresholdValue;
      return acc;
    }, {} as Record<string, number>);

    if (
      !(thresholdMap['Exceed'] > thresholdMap['Acceptable'] &&
        thresholdMap['Acceptable'] > thresholdMap['Marginal'] &&
        thresholdMap['Marginal'] >= thresholdMap['Fail'])
    ) {
      return NextResponse.json(
        { error: 'Threshold values must follow: Exceed > Acceptable > Marginal >= Fail.' },
        { status: 400 }
      );
    }

    // Proceed with upserting thresholds
    const operations = body.thresholds.map((threshold) =>
      prisma.threshold.upsert({
        where: { Threshold: threshold.thresholdName },
        update: { ThresholdValue: threshold.thresholdValue },
        create: {
          Threshold: threshold.thresholdName,
          ThresholdValue: threshold.thresholdValue,
          ThresholdSign: '>=',
        },
      })
    );

    await Promise.all(operations);

    return NextResponse.json(
      { message: 'Thresholds upserted successfully.' },
      { status: 200 }
    );
  } catch (error) {
    console.error('Error upserting thresholds:', error);
    return NextResponse.json(
      { error: 'Failed to upsert thresholds.' },
      { status: 500 }
    );
  }
}

export async function GET(req: NextRequest) {
  try {
    const thresholds = await prisma.threshold.findMany({
      select: {
        Threshold: true, // Prisma DB field name
        ThresholdValue: true, // Prisma DB field name
      },
    });

    // Transform DB result to match frontend expectations
    const formattedThresholds = thresholds.map(threshold => ({
      thresholdName: threshold.Threshold,  // Rename to match frontend
      thresholdValue: threshold.ThresholdValue, // Keep value unchanged
    }));

    return NextResponse.json(
      { thresholds: formattedThresholds }, // Ensure response matches frontend expectations
      { status: 200 }
    );
  } catch (error) {
    console.error('Error fetching thresholds:', error);
    return NextResponse.json(
      { error: 'Failed to fetch thresholds.' },
      { status: 500 }
    );
  }
}