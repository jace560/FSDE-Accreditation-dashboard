import { authOptions } from "@/app/api/auth/[...nextauth]/route";
import logger from "@/lib/logger";
import prisma from "@/lib/prisma";
import { updateUserRoleDto, USER_ROLE } from "@/types";
import { getServerSession } from "next-auth";
import { NextResponse } from "next/server";

export async function PUT(req: Request) {
  try {
    const body: updateUserRoleDto = await req.json();

    // Validate input
    if (!body.userID || !body.role) {
      return NextResponse.json(
        { error: "Missing required fields: userID and role" },
        { status: 400 }
      );
    }

    const session = await getServerSession(authOptions);

    if (!session || !session.user || !session.user?.UserID) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Validate input
    if (!body.userID || !body.role) {
      return NextResponse.json(
        { error: "Missing required fields: userID and role" },
        { status: 400 }
      );
    }
    const authenticatedUserID = session.user?.UserID;

    if (body.userID === authenticatedUserID) {
      return NextResponse.json(
        { error: "You cannot update your own role" },
        { status: 403 }
      );
    }

    // Validate role against enum
    if (!Object.values(USER_ROLE).includes(body.role as USER_ROLE)) {
      return NextResponse.json(
        { error: "Invalid role provided" },
        { status: 400 }
      );
    }

    // Check if user exists
    const userExists = await prisma.user.findUnique({
      where: { UserID: body.userID },
      select: { UserID: true },
    });

    if (!userExists) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // Update the user role
    const updatedUser = await prisma.user.update({
      where: { UserID: body.userID },
      data: { Role: body.role },
      select: {
        UserID: true,
        FirstName: true,
        LastName: true,
        Email: true,
        Role: true,
      },
    });

    logger.info(`User role updated successfully for ${updatedUser.Email}`);

    return NextResponse.json({
      message: "User role updated successfully",
      user: updatedUser,
    });
  } catch (error) {
    logger.error("Error updating user role:", error);
    return NextResponse.json(
      { error: "Internal Server Error", details: (error as Error).message },
      { status: 500 }
    );
  }
}
