import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import logger from "@/lib/logger"; // Optional logging
import { getServerSession } from "next-auth";
import { authOptions } from "@/app/api/auth/[...nextauth]/route";

export async function DELETE(
  req: Request,
  { params }: { params: { id: string } }
) {
  try {
    console.log(" Received DELETE request for ID:", params.id);

    if (!params?.id) {
      return NextResponse.json(
        { error: "User ID is required." },
        { status: 400 }
      );
    }

    // Validate UUID format
    const UUID_REGEX =
      /^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/;
    if (!UUID_REGEX.test(params.id)) {
      return NextResponse.json(
        { error: "Invalid User ID format." },
        { status: 400 }
      );
    }

    const session = await getServerSession(authOptions);

    if (!session || !session.user || !session.user?.UserID) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const authenticatedUserID = session.user?.UserID;

    if (params.id === authenticatedUserID) {
      return NextResponse.json(
        { error: "You cannot delete yourself" },
        { status: 403 }
      );
    }

    // Check if user exists
    const existingUser = await prisma.user.findUnique({
      where: { UserID: params.id },
    });
    if (!existingUser) {
      return NextResponse.json({ error: "User not found." }, { status: 404 });
    }

    // Delete the user
    await prisma.user.delete({ where: { UserID: params.id } });

    console.log(` User ${params.id} deleted successfully.`);
    return NextResponse.json(
      { message: "User deleted successfully." },
      { status: 200 }
    );
  } catch (error) {
    logger.error(" Error deleting user", { message: (error as Error).message });
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
