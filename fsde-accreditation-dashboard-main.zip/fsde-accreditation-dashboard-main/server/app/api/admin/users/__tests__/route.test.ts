import { NextRequest } from "next/server";
import { GET } from "@/app/api/admin/users/route";
import { jest } from "@jest/globals";
import prisma from "@/lib/prisma";

// Mock Prisma
jest.mock("@/lib/prisma", () => ({
    user: {
        findMany: jest.fn(),
        count: jest.fn(),
    },
}));

const mockedPrisma = prisma as unknown as {
    user: {
        findMany: jest.MockedFunction<() => Promise<{
            UserID: string;
            Username: string;
            FirstName: string;
            LastName: string;
            Email: string;
            Role: { RoleName: string };
        }[]>>;
        count: jest.MockedFunction<() => Promise<number>>;
    };
};


describe("GET /api/users", () => {
    beforeEach(() => {
        jest.clearAllMocks();
        jest.restoreAllMocks();
        mockedPrisma.user.findMany = jest.fn();
        mockedPrisma.user.count = jest.fn();
    });

    const createTestRequest = (page: number) =>
        new NextRequest(`http://localhost:3000/api/users?page=${page}`);

    it("should return paginated users with 200 status", async () => {
        const mockUsers = [
            {
                UserID: "12345",
                Username: "john_doe",
                FirstName: "John",
                LastName: "Doe",
                Email: "john@example.com",
                Role: { RoleName: "Admin" },
            },
            {
                UserID: "67890",
                Username: "jane_doe",
                FirstName: "Jane",
                LastName: "Doe",
                Email: "jane@example.com",
                Role: { RoleName: "User" },
            },
        ];

        mockedPrisma.user.findMany.mockResolvedValueOnce(mockUsers);
        mockedPrisma.user.count.mockResolvedValueOnce(50); // Assume 50 users exist

        const req = createTestRequest(1);
        const response = await GET(req);
        const json = await response.json();

        expect(response.status).toBe(200);
        expect(json).toEqual({
            data: mockUsers,
            pagination: {
                totalUsers: 50,
                totalPages: 5,
                currentPage: 1,
                limit: 10,
            },
        });
    });

    it("should return an empty list if no users are found", async () => {
        mockedPrisma.user.findMany.mockResolvedValueOnce([]);
        mockedPrisma.user.count.mockResolvedValueOnce(0);

        const req = createTestRequest(1);
        const response = await GET(req);
        const json = await response.json();

        expect(response.status).toBe(200);
        expect(json).toEqual({
            data: [],
            pagination: {
                totalUsers: 0,
                totalPages: 0,
                currentPage: 1,
                limit: 10,
            },
        });
    });
});
