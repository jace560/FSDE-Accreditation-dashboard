import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import logger from "@/lib/logger";
import {
  User,
  UsersReturnDto,
  GetUsersQuery,
  updateUserRoleDto,
  ROLE_TYPE,
  USER_ROLE,
} from "@/types"; // Adjust based on your setup

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const query: GetUsersQuery = {
      page: searchParams.get("page") || "1",
      limit: searchParams.get("limit") || "10",
      role: searchParams.get("role") || undefined,
      nameSearchQuery: searchParams.get("nameSearchQuery") || undefined,
    };

    const page = parseInt(query.page as string, 10);
    const limit = parseInt(query.limit as string, 10);
    const skip = (page - 1) * limit;

    // Fetch users with optional role or name search filtering
    const users = await prisma.user.findMany({
      where: {
        Role: query.role,
        OR: query.nameSearchQuery
          ? [
              {
                FirstName: {
                  contains: query.nameSearchQuery,
                  mode: "insensitive",
                },
              },
              {
                LastName: {
                  contains: query.nameSearchQuery,
                  mode: "insensitive",
                },
              },
              {
                Email: { contains: query.nameSearchQuery, mode: "insensitive" },
              },
            ]
          : undefined,
      },
      skip,
      take: limit,
      select: {
        UserID: true,
        FirstName: true,
        LastName: true,
        Email: true,
        Role: true,
        Status: true,
      },
    });

    // Get total count of users with applied filters
    const totalUsers = await prisma.user.count({
      where: {
        Role: query.role,
        OR: query.nameSearchQuery
          ? [
              {
                FirstName: {
                  contains: query.nameSearchQuery,
                  mode: "insensitive",
                },
              },
              {
                LastName: {
                  contains: query.nameSearchQuery,
                  mode: "insensitive",
                },
              },
              {
                Email: { contains: query.nameSearchQuery, mode: "insensitive" },
              },
            ]
          : undefined,
      },
    });

    const totalPages = Math.ceil(totalUsers / limit);

    const formattedUsers: User[] = users.map((user) => ({
      UserID: user.UserID,
      FirstName: user.FirstName,
      LastName: user.LastName,
      FullName: `${user.FirstName} ${user.LastName}`,
      Email: user.Email,
      Role: user.Role,
      Status: user.Status,
      Initials: `${user.FirstName.charAt(0)}${user.LastName.charAt(0)}`,
    }));

    const response: UsersReturnDto = {
      Users: formattedUsers,
      meta: {
        totalUsers,
        page,
        totalPages,
        limit,
      },
    };

    return NextResponse.json(response);
  } catch (error) {
    logger.error("Error fetching users:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
}
import {} from "@/types"; // Ensure correct import

export async function PUT(req: Request) {
  try {
    const body: updateUserRoleDto = await req.json();

    // Validate input
    if (!body.userID || !body.role) {
      return NextResponse.json(
        { error: "Missing required fields: userID and role" },
        { status: 400 }
      );
    }

    // Validate role against enum
    if (!Object.values(USER_ROLE).includes(body.role as USER_ROLE)) {
      return NextResponse.json(
        { error: "Invalid role provided" },
        { status: 400 }
      );
    }

    // Check if user exists
    const userExists = await prisma.user.findUnique({
      where: { UserID: body.userID },
      select: { UserID: true },
    });

    if (!userExists) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    // Update the user role
    const updatedUser = await prisma.user.update({
      where: { UserID: body.userID },
      data: { Role: body.role },
      select: {
        UserID: true,
        FirstName: true,
        LastName: true,
        Email: true,
        Role: true,
      },
    });

    logger.info(`User role updated successfully for ${updatedUser.Email}`);

    return NextResponse.json({
      message: "User role updated successfully",
      user: updatedUser,
    });
  } catch (error) {
    logger.error("Error updating user role:", error);
    return NextResponse.json(
      { error: "Internal Server Error", details: (error as Error).message },
      { status: 500 }
    );
  }
}
