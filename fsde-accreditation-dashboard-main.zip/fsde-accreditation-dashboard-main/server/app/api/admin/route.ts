import { NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import logger from "@/lib/logger";
import { v4 as uuidv4 } from "uuid";

export async function PUT(req: Request) {
    try {
        logger.info("Received PUT request for Thresholds");

        const body = await req.json();
        const { thresholdName, thresholdValue } = body;

        // Allowed threshold names
        const VALID_THRESHOLD_NAMES = ["Exceed", "Acceptable", "Marginal", "Fail"] as const;
        if (!VALID_THRESHOLD_NAMES.includes(thresholdName)) {
            return NextResponse.json(
                { error: `Invalid threshold name. Must be one of: ${VALID_THRESHOLD_NAMES.join(", ")}` },
                { status: 400 }
            );
        }

        if (typeof thresholdValue !== "number" || thresholdValue < 0 || thresholdValue > 100) {
            return NextResponse.json(
                { error: "Threshold value must be a number between 0 and 100." },
                { status: 400 }
            );
        }

        return await prisma.$transaction(async (tx) => {
            // 🔹 Step 1: Find existing threshold **using ThresholdID**
            const existingThreshold = await tx.threshold.findFirst({
                where: { Threshold: thresholdName },
            });

            if (existingThreshold) {
                logger.info(`Updating existing threshold: ${thresholdName}`);
                const updatedThreshold = await tx.threshold.update({
                    where: { ThresholdID: existingThreshold.ThresholdID },
                    data: { ThresholdValue: thresholdValue },
                });

                return NextResponse.json(
                    {
                        message: `Threshold '${thresholdName}' successfully updated.`,
                        threshold: updatedThreshold,
                    },
                    { status: 200 }
                );
            } else {
                logger.info(`Creating new threshold: ${thresholdName}`);
                const newThreshold = await tx.threshold.create({
                    data: {
                        ThresholdID: uuidv4(),
                        Threshold: thresholdName,
                        ThresholdValue: thresholdValue,
                        ThresholdSign: ">", // Default value
                    },
                });

                return NextResponse.json(
                    {
                        message: `Threshold '${thresholdName}' successfully created.`,
                        threshold: newThreshold,
                    },
                    { status: 201 }
                );
            }
        });
    } catch (error: unknown) {
        logger.error("Error updating/creating threshold", { message: (error as Error).message });

        return NextResponse.json(
            { error: "Internal Server Error", details: (error as Error).message },
            { status: 500 }
        );
    }

}

