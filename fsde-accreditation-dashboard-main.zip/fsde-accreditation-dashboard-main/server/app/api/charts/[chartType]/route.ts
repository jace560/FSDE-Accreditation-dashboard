import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import logger from "@/lib/logger";
import {
  ApiResponse,
  ChartQueryParams,
  ChartDataReturnDto,
  ChartType,
  Chart,
  GAChartData,
  CourseLOPerformance,
  PerformanceCategory,
  PerformanceColors,
  PILevelType,
  PerformanceDistribution,
  BY_GA_BY_COURSE_LEVEL,
  PerformanceLevels,
  BY_GA_BY_IDA_LEVEL,
} from "@/types";
import { CourseLevelColor, PILevelColor } from "@/utils";
import {
  calculateLODistributionWithPercentages,
  calculateStudentGradesUnderLO,
} from "@/lib/api/generic";
import { AllStudentLOGrades, StudentLOGrades } from "@/types/weights";
import { ApiError } from "@/utils/error-handler";
import { count } from "console";

export async function GET(
  req: NextRequest,
  context: { params: { chartType: ChartType } }
) {
  try {
    const { searchParams } = new URL(req.url);

    const programId = searchParams.get("programId");
    const campusId = searchParams.get("campusId");
    const year = searchParams.get("year") || undefined;
    const graduateAttribute =
      searchParams.get("graduateAttribute") || undefined;

    if (!programId || !campusId || !year) {
      logger.warn("Missing required query parameters", {
        programId,
        campusId,
        year,
      });
      return NextResponse.json<ApiResponse<null>>(
        {
          error: {
            message: "programID, campusID, and year are required",
            status: 400,
          },
        },
        { status: 400 }
      );
    }

    const chartType = context.params.chartType;
    logger.info(`Fetching chart data for type: ${chartType}`);

    const queryParams: ChartQueryParams = {
      programId,
      campusId,
      year,
      graduateAttribute,
    };

    let responseData: ChartDataReturnDto;

    switch (chartType) {
      case ChartType.GA_BY_IDA:
        logger.info("Fetching GA by IDA data...");
        responseData = await fetchGAByIDA(queryParams);
        break;

      case ChartType.GA_BY_COURSE_LEVEL:
        logger.info("Fetching GA by Course Level data...");
        responseData = await fetchGAByCourseLevel(queryParams);
        break;
      case ChartType.GA_BY_COURSE_AND_IDA:
        logger.info("Fetching GA by Course Level data...");
        responseData = await calculateLODistributionForGA(queryParams);
        break;
      case ChartType.COURSE_LEVEL_COMBINING_ALL_GA:
        logger.info("Fetching Course Level by GA...");
        responseData = await calculateCourseLevelCombiningAllGA(queryParams);
        break;
      case ChartType.IDA_LEVEL_COMBINING_ALL_GA:
        logger.info("Fetching IDA Level combining all GA...");
        responseData = await calculateIDALevelCombiningAllGA(queryParams);
        break;
      case ChartType.BY_GA_AND_BY_COURSE_LEVEL:
        logger.info("Fetching By GA and By Course Level...");
        responseData = await calculateLODistributionByGAAndCourseLevel(
          queryParams
        );
        break;
      case ChartType.BY_GA_AND_BY_IDA_LEVEL:
        logger.info("Fetching By GA and By IDA Level...");
        responseData = await calculateLODistributionByGAAndIDALevel(
          queryParams
        );
        break;
      default:
        logger.error("Invalid chartType requested", { chartType });
        return NextResponse.json<ApiResponse<null>>(
          {
            error: { message: "Invalid chartType", status: 400 },
          },
          { status: 400 }
        );
    }

    logger.info("Successfully fetched chart data", { chartType });
    return NextResponse.json<ApiResponse<ChartDataReturnDto>>({
      data: responseData,
    });
  } catch (error: any) {
    logger.error("API Error:", error);
    const statusCode = error instanceof ApiError ? error.statusCode : 500;

    return NextResponse.json<ApiResponse<null>>(
      {
        error: {
          message: error.message || "Internal Server Error",
          status: statusCode,
        },
      },
      { status: statusCode }
    );
  }
}

const calculateIDALevelCombiningAllGA = async (params: ChartQueryParams) => {
  const { programId, campusId, year } = params;

  if (!year) {
    logger.error("Year must be selected.");
    throw new ApiError("Year must be selected.", 400);
  }

  const valid = await validateQueryParams(programId, campusId, year);
  if (!valid) {
    throw new ApiError(
      "No records found matching the specified Program, Campus, and Year Entered.",
      404
    );
  }

  try {
    const campus = await prisma.campus.findFirst({
      where: {
        CampusID: campusId,
      },
      select: {
        CampusName: true,
      },
    });

    const graduateAttributes = await prisma.graduateAttribute.findMany({
      select: {
        GAID: true,
        GAName: true,
      },
    });

    if (!graduateAttributes.length) {
      logger.warn("No Graduate Attributes found.");
      throw new ApiError("No Graduate Attributes found.", 404);
    }

    logger.info(`Found ${graduateAttributes.length} Graduate Attributes.`);

    const IDALevelPerformance: Record<
      string,
      {
        Exceeds: number;
        Acceptable: number;
        Marginal: number;
        Fail: number;
        total: number;
      }
    > = {
      I: { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
      D: { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
      A: { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
    };

    const gaHasIDALevelPerformmance: Record<string, boolean> = {};

    for (const ga of graduateAttributes) {
      logger.info(`Processing GA: ${ga.GAName}`);

      // Get all courses contributing to this GA
      const courses =
        await prisma.learningObjectivePerformanceIndicatorMapping.findMany({
          where: {
            GraduateAttribute: { GAID: ga.GAID },
            Course: { CampusID: campusId, Year: year },
            LearningObjective: { IsCurrent: true },
          },
          select: {
            CourseID: true,
            PILevel: true,
            Course: {
              select: { CourseCode: true },
            },
            LearningObjective: {
              select: {
                MappingVersion: true,
              },
            },
          },
          distinct: ["CourseID"],
        });

      if (!courses.length) {
        logger.warn(`No courses found contributing to GA: ${ga.GAName}`);
        continue;
      }

      for (const { PILevel, CourseID, LearningObjective } of courses) {
        if (!PILevel) continue;
        const currentMappingVersion = LearningObjective.MappingVersion;

        const studentLOGrades = await calculateStudentGradesUnderLO(
          CourseID,
          currentMappingVersion
        );
        if (!Object.keys(studentLOGrades).length) {
          logger.warn(
            `No LO grades found for CourseID: ${CourseID}, skipping...`
          );
          continue;
        }

        const loMappings =
          await prisma.learningObjectivePerformanceIndicatorMapping.findMany({
            where: { CourseID, GAID: ga.GAID },
            select: { LOID: true },
          });

        const loIDs = loMappings.map((lo) => lo.LOID);
        const filteredStudentLOGrades: AllStudentLOGrades = {};

        Object.entries(studentLOGrades).forEach(([studentID, loGrades]) => {
          const filteredLOs = Object.fromEntries(
            Object.entries(loGrades).filter(([loID]) => loIDs.includes(loID))
          );

          if (Object.keys(filteredLOs).length > 0) {
            filteredStudentLOGrades[studentID] = filteredLOs;
          }
        });

        if (Object.keys(filteredStudentLOGrades).length === 0) {
          logger.warn(
            `No relevant LO grades found for GA ${ga?.GAName} in Course: ${CourseID}`
          );
          continue;
        }

        const loPerformanceCounts: Record<
          string,
          {
            Exceeds: number;
            Acceptable: number;
            Marginal: number;
            Fail: number;
          }
        > = {};

        Object.values(filteredStudentLOGrades).forEach((loGrades) => {
          Object.entries(loGrades).forEach(([loID, grade]) => {
            if (!loPerformanceCounts[loID]) {
              loPerformanceCounts[loID] = {
                Exceeds: 0,
                Acceptable: 0,
                Marginal: 0,
                Fail: 0,
              };
            }

            if (grade >= 80) {
              loPerformanceCounts[loID].Exceeds += 1;
            } else if (grade >= 65) {
              loPerformanceCounts[loID].Acceptable += 1;
            } else if (grade >= 50) {
              loPerformanceCounts[loID].Marginal += 1;
            } else {
              loPerformanceCounts[loID].Fail += 1;
            }
          });
        });

        // Aggregate performance counts
        const totalCounts = { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0 };
        let totalAcrossLOs = 0;

        Object.values(studentLOGrades).forEach((loGrades: StudentLOGrades) => {
          Object.values(loGrades).forEach((grade) => {
            if (grade >= 80) totalCounts.Exceeds += 1;
            else if (grade >= 65) totalCounts.Acceptable += 1;
            else if (grade >= 50) totalCounts.Marginal += 1;
            else totalCounts.Fail += 1;
          });
        });

        totalAcrossLOs =
          totalCounts.Exceeds +
          totalCounts.Acceptable +
          totalCounts.Marginal +
          totalCounts.Fail;

        // Accumulate results per course level across all GA
        IDALevelPerformance[PILevel].Exceeds += totalCounts.Exceeds;
        IDALevelPerformance[PILevel].Acceptable += totalCounts.Acceptable;
        IDALevelPerformance[PILevel].Marginal += totalCounts.Marginal;
        IDALevelPerformance[PILevel].Fail += totalCounts.Fail;
        IDALevelPerformance[PILevel].total += totalAcrossLOs;
      }

      gaHasIDALevelPerformmance[ga.GAID] = !Object.values(
        IDALevelPerformance
      ).every((performance) => performance.total === 0);
    }

    if (
      Object.values(gaHasIDALevelPerformmance).every((gaValues) => !gaValues)
    ) {
      throw new ApiError(
        "No matching records found! No student grades available for all the courses under the given criteria.",
        404
      );
    }
    logger.info(`Successfully processed IDA levels across all GA.`);

    const chartData = Object.entries(IDALevelPerformance).map(
      ([level, counts]) => ({
        IDALevel: level,
        Exceeds: (counts.Exceeds / counts.total) * 100 || 0,
        Acceptable: (counts.Acceptable / counts.total) * 100 || 0,
        Marginal: (counts.Marginal / counts.total) * 100 || 0,
        Fail: (counts.Fail / counts.total) * 100 || 0,
      })
    );
    return {
      type: ChartType.IDA_LEVEL_COMBINING_ALL_GA,
      labels: {
        xAxisLabel: "IDA Level",
        yAxisLabel: "Percentage of Students Grades",
        mainTitle: `IDA Level Performance Combining All GA - ${year} - ${campus?.CampusName}`,
      },
      data: chartData,
      color: PerformanceColors,
    };
  } catch (error: any) {
    logger.error(
      `Error calculating course level performance across GA:`,
      error
    );
    throw error;
  }
};

const calculateLODistributionByGAAndIDALevel = async (
  params: ChartQueryParams
): Promise<Chart> => {
  const { programId, campusId, year } = params;

  if (!year) {
    logger.error("Year must be selected.");
    throw new ApiError("Year must be selected.", 400);
  }

  const valid = await validateQueryParams(programId, campusId, year);

  try {
    const campus = await prisma.campus.findFirst({
      where: {
        CampusID: campusId,
      },
      select: {
        CampusName: true,
      },
    });
    const graduateAttributes = await prisma.graduateAttribute.findMany({
      select: {
        GAID: true,
        GAName: true,
        GANumber: true,
      },
    });

    type CoursePerformanceType = Record<
      string,
      Record<string, PerformanceLevels>
    >;

    if (!graduateAttributes.length) {
      logger.warn("No Graduate Attributes found.");
      throw new ApiError("No Graduate Attributes found.", 404);
    }
    logger.info(`Found ${graduateAttributes.length} Graduate Attributes.`);

    const gaIDALevelPerformance: CoursePerformanceType =
      graduateAttributes.reduce<CoursePerformanceType>((acc, attribute) => {
        acc[`${attribute.GANumber}-${attribute.GAName}`] = {
          I: { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
          D: { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
          A: { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
        };

        return acc;
      }, {} as CoursePerformanceType);

    let gaHasCourseLevelPerformmance = true;

    for (const ga of graduateAttributes) {
      logger.info(`Processing GA: ${ga.GAName}`);

      const courses =
        await prisma.learningObjectivePerformanceIndicatorMapping.findMany({
          where: {
            GraduateAttribute: { GAID: ga.GAID },
            Course: { CampusID: campusId, Year: year },
            LearningObjective: { IsCurrent: true },
          },
          select: {
            CourseID: true,
            PILevel: true,
            Course: {
              select: { CourseCode: true },
            },
            LearningObjective: {
              select: {
                MappingVersion: true,
              },
            },
          },
          distinct: ["CourseID"],
        });

      if (!courses.length) {
        logger.warn(`No courses found contributing to GA: ${ga.GAName}`);
        continue;
      }

      for (const { PILevel, Course, CourseID, LearningObjective } of courses) {
        if (!PILevel) continue;
        const currentMappingVersion = LearningObjective.MappingVersion;

        if (!currentMappingVersion) continue;

        // Get student LO grades for the course
        const studentLOGrades = await calculateStudentGradesUnderLO(
          CourseID,
          currentMappingVersion
        );

        if (!Object.keys(studentLOGrades).length) {
          logger.warn(
            `No LO grades found for CourseID: ${CourseID}, skipping...`
          );
          continue;
        }

        const loMappings =
          await prisma.learningObjectivePerformanceIndicatorMapping.findMany({
            where: { CourseID, GAID: ga.GAID },
            select: { LOID: true },
          });

        const loIDs = loMappings.map((lo) => lo.LOID);
        const filteredStudentLOGrades: AllStudentLOGrades = {};

        Object.entries(studentLOGrades).forEach(([studentID, loGrades]) => {
          const filteredLOs = Object.fromEntries(
            Object.entries(loGrades).filter(([loID]) => loIDs.includes(loID))
          );

          if (Object.keys(filteredLOs).length > 0) {
            filteredStudentLOGrades[studentID] = filteredLOs;
          }
        });

        if (Object.keys(filteredStudentLOGrades).length === 0) {
          logger.warn(
            `No relevant LO grades found for GA ${ga?.GAName} in Course: ${CourseID}`
          );
          continue;
        }

        const loPerformanceCounts: Record<
          string,
          {
            Exceeds: number;
            Acceptable: number;
            Marginal: number;
            Fail: number;
          }
        > = {};

        Object.values(filteredStudentLOGrades).forEach((loGrades) => {
          Object.entries(loGrades).forEach(([loID, grade]) => {
            if (!loPerformanceCounts[loID]) {
              loPerformanceCounts[loID] = {
                Exceeds: 0,
                Acceptable: 0,
                Marginal: 0,
                Fail: 0,
              };
            }

            if (grade >= 80) {
              loPerformanceCounts[loID].Exceeds += 1;
            } else if (grade >= 65) {
              loPerformanceCounts[loID].Acceptable += 1;
            } else if (grade >= 50) {
              loPerformanceCounts[loID].Marginal += 1;
            } else {
              loPerformanceCounts[loID].Fail += 1;
            }
          });
        });

        const totalCounts = { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0 };
        let totalAcrossLOs = 0;

        Object.values(studentLOGrades).forEach((loGrades: StudentLOGrades) => {
          Object.values(loGrades).forEach((grade) => {
            if (grade >= 80) totalCounts.Exceeds += 1;
            else if (grade >= 65) totalCounts.Acceptable += 1;
            else if (grade >= 50) totalCounts.Marginal += 1;
            else totalCounts.Fail += 1;
          });
        });

        totalAcrossLOs =
          totalCounts.Exceeds +
          totalCounts.Acceptable +
          totalCounts.Marginal +
          totalCounts.Fail;

        gaIDALevelPerformance[`${ga.GANumber}-${ga.GAName}`][PILevel].Exceeds +=
          totalCounts.Exceeds;
        gaIDALevelPerformance[`${ga.GANumber}-${ga.GAName}`][
          PILevel
        ].Acceptable += totalCounts.Acceptable;
        gaIDALevelPerformance[`${ga.GANumber}-${ga.GAName}`][
          PILevel
        ].Marginal += totalCounts.Marginal;
        gaIDALevelPerformance[`${ga.GANumber}-${ga.GAName}`][PILevel].Fail +=
          totalCounts.Fail;
        gaIDALevelPerformance[`${ga.GANumber}-${ga.GAName}`][PILevel].total +=
          totalAcrossLOs;
      }

      gaHasCourseLevelPerformmance = !Object.values(
        gaIDALevelPerformance
      ).every((ga) => Object.values(ga).every((level) => level.total == 0));
    }

    gaHasCourseLevelPerformmance = !Object.values(gaIDALevelPerformance).every(
      (ga) => Object.values(ga).every((level) => level.total == 0)
    );
    if (!gaHasCourseLevelPerformmance) {
      throw new ApiError(
        "No matching records found! No student grades available for all the courses under the given criteria.",
        404
      );
    }

    logger.info(`Successfully processed By GA and By IDA Level...`);

    const gaChartData: BY_GA_BY_IDA_LEVEL[] = Object.entries(
      gaIDALevelPerformance
    ).map(([gaName, IDALevels]) => ({
      gaName,
      IDALevelPerformance: Object.entries(IDALevels).map(([level, counts]) => ({
        IDALevel: level,
        Exceeds: (counts.Exceeds / counts.total) * 100 || 0,
        Acceptable: (counts.Acceptable / counts.total) * 100 || 0,
        Marginal: (counts.Marginal / counts.total) * 100 || 0,
        Fail: (counts.Fail / counts.total) * 100 || 0,
      })),
    }));

    return {
      type: ChartType.BY_GA_AND_BY_IDA_LEVEL,
      labels: {
        xAxisLabel: "Graduate Attributes",
        yAxisLabel: "Percentage of Students Grades",
        mainTitle: `By GA And By IDA Level - ${year} - ${campus?.CampusName}`,
      },
      data: gaChartData,
      color: PerformanceColors,
    };
  } catch (error: any) {
    logger.error(
      `Error calculating LO distribution By GA and By IDA Level`,
      error
    );
    throw error;
  }
};

const calculateLODistributionByGAAndCourseLevel = async (
  params: ChartQueryParams
): Promise<Chart> => {
  const { programId, campusId, year } = params;

  if (!year) {
    logger.error("Year must be selected.");
    throw new ApiError("Year must be selected.", 400);
  }

  const valid = await validateQueryParams(programId, campusId, year);
  if (!valid) {
    throw new ApiError(
      "No records found matching the specified Program, Campus, and Year Entered.",
      404
    );
  }

  try {
    const campus = await prisma.campus.findFirst({
      where: {
        CampusID: campusId,
      },
      select: {
        CampusName: true,
      },
    });
    const graduateAttributes = await prisma.graduateAttribute.findMany({
      select: {
        GAID: true,
        GAName: true,
        GANumber: true,
      },
    });

    type CoursePerformanceType = Record<
      string,
      Record<string, PerformanceLevels>
    >;

    if (!graduateAttributes.length) {
      logger.warn("No Graduate Attributes found.");
      throw new ApiError("No Graduate Attributes found.", 404);
    }
    logger.info(`Found ${graduateAttributes.length} Graduate Attributes.`);

    const gaCourseLevelPerformance: CoursePerformanceType =
      graduateAttributes.reduce<CoursePerformanceType>((acc, attribute) => {
        acc[`${attribute.GANumber}-${attribute.GAName}`] = {
          "1000": { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
          "2000": { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
          "3000": { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
          "4000": { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
        };

        return acc;
      }, {} as CoursePerformanceType);

    let gaHasCourseLevelPerformmance = true;

    for (const ga of graduateAttributes) {
      logger.info(`Processing GA: ${ga.GAName}`);

      const courses =
        await prisma.learningObjectivePerformanceIndicatorMapping.findMany({
          where: {
            GraduateAttribute: { GAID: ga.GAID },
            Course: { CampusID: campusId, Year: year },
            LearningObjective: { IsCurrent: true },
          },
          select: {
            CourseID: true,
            Course: {
              select: { CourseCode: true },
            },
            LearningObjective: {
              select: {
                MappingVersion: true,
              },
            },
          },
          distinct: ["CourseID"],
        });

      if (!courses.length) {
        logger.warn(`No courses found contributing to GA: ${ga.GAName}`);
        continue;
      }

      for (const { Course, CourseID, LearningObjective } of courses) {
        const courseLevel = getCourseLevel(Course.CourseCode);
        if (!courseLevel) continue;
        const currentMappingVersion = LearningObjective.MappingVersion;

        if (!currentMappingVersion) continue;

        // Get student LO grades for the course
        const studentLOGrades = await calculateStudentGradesUnderLO(
          CourseID,
          currentMappingVersion
        );

        if (!Object.keys(studentLOGrades).length) {
          logger.warn(
            `No LO grades found for CourseID: ${CourseID}, skipping...`
          );
          continue;
        }

        const loMappings =
          await prisma.learningObjectivePerformanceIndicatorMapping.findMany({
            where: { CourseID, GAID: ga.GAID },
            select: { LOID: true },
          });

        const loIDs = loMappings.map((lo) => lo.LOID);
        const filteredStudentLOGrades: AllStudentLOGrades = {};

        Object.entries(studentLOGrades).forEach(([studentID, loGrades]) => {
          const filteredLOs = Object.fromEntries(
            Object.entries(loGrades).filter(([loID]) => loIDs.includes(loID))
          );

          if (Object.keys(filteredLOs).length > 0) {
            filteredStudentLOGrades[studentID] = filteredLOs;
          }
        });

        if (Object.keys(filteredStudentLOGrades).length === 0) {
          logger.warn(
            `No relevant LO grades found for GA ${ga?.GAName} in Course: ${CourseID}`
          );
          continue;
        }

        const loPerformanceCounts: Record<
          string,
          {
            Exceeds: number;
            Acceptable: number;
            Marginal: number;
            Fail: number;
          }
        > = {};

        Object.values(filteredStudentLOGrades).forEach((loGrades) => {
          Object.entries(loGrades).forEach(([loID, grade]) => {
            if (!loPerformanceCounts[loID]) {
              loPerformanceCounts[loID] = {
                Exceeds: 0,
                Acceptable: 0,
                Marginal: 0,
                Fail: 0,
              };
            }

            if (grade >= 80) {
              loPerformanceCounts[loID].Exceeds += 1;
            } else if (grade >= 65) {
              loPerformanceCounts[loID].Acceptable += 1;
            } else if (grade >= 50) {
              loPerformanceCounts[loID].Marginal += 1;
            } else {
              loPerformanceCounts[loID].Fail += 1;
            }
          });
        });

        const totalCounts = { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0 };
        let totalAcrossLOs = 0;

        Object.values(studentLOGrades).forEach((loGrades: StudentLOGrades) => {
          Object.values(loGrades).forEach((grade) => {
            if (grade >= 80) totalCounts.Exceeds += 1;
            else if (grade >= 65) totalCounts.Acceptable += 1;
            else if (grade >= 50) totalCounts.Marginal += 1;
            else totalCounts.Fail += 1;
          });
        });

        totalAcrossLOs =
          totalCounts.Exceeds +
          totalCounts.Acceptable +
          totalCounts.Marginal +
          totalCounts.Fail;

        gaCourseLevelPerformance[`${ga.GANumber}-${ga.GAName}`][
          courseLevel
        ].Exceeds += totalCounts.Exceeds;
        gaCourseLevelPerformance[`${ga.GANumber}-${ga.GAName}`][
          courseLevel
        ].Acceptable += totalCounts.Acceptable;
        gaCourseLevelPerformance[`${ga.GANumber}-${ga.GAName}`][
          courseLevel
        ].Marginal += totalCounts.Marginal;
        gaCourseLevelPerformance[`${ga.GANumber}-${ga.GAName}`][
          courseLevel
        ].Fail += totalCounts.Fail;
        gaCourseLevelPerformance[`${ga.GANumber}-${ga.GAName}`][
          courseLevel
        ].total += totalAcrossLOs;
      }

      gaHasCourseLevelPerformmance = !Object.values(
        gaCourseLevelPerformance
      ).every((ga) => Object.values(ga).every((level) => level.total == 0));
    }

    if (!gaHasCourseLevelPerformmance) {
      throw new ApiError(
        "No matching records found! No student grades available for all the courses under the given criteria.",
        404
      );
    }

    logger.info(`Successfully processed By GA and By Course Level...`);

    const gaChartData: BY_GA_BY_COURSE_LEVEL[] = Object.entries(
      gaCourseLevelPerformance
    ).map(([gaName, courseLevels]) => ({
      gaName,
      courseLevelPerformance: Object.entries(courseLevels).map(
        ([level, counts]) => ({
          CourseLevel: level,
          Exceeds: (counts.Exceeds / counts.total) * 100 || 0,
          Acceptable: (counts.Acceptable / counts.total) * 100 || 0,
          Marginal: (counts.Marginal / counts.total) * 100 || 0,
          Fail: (counts.Fail / counts.total) * 100 || 0,
        })
      ),
    }));

    return {
      type: ChartType.BY_GA_AND_BY_COURSE_LEVEL,
      labels: {
        xAxisLabel: "Graduate Attributes",
        yAxisLabel: "Percentage of Students Grades",
        mainTitle: `By GA And By Course Level - ${year} - ${campus?.CampusName}`,
      },
      data: gaChartData,
      color: PerformanceColors,
    };
  } catch (error: any) {
    logger.error(
      `Error calculating LO distribution By GA and By Course Level`,
      error
    );
    throw error;
  }
};

const calculateCourseLevelCombiningAllGA = async (
  params: ChartQueryParams
): Promise<Chart> => {
  const { programId, campusId, year } = params;

  if (!year) {
    logger.error("Year must be selected.");
    throw new ApiError("Year must be selected.", 400);
  }

  const valid = await validateQueryParams(programId, campusId, year);
  if (!valid) {
    throw new ApiError(
      "No records found matching the specified Program, Campus, and Year Entered.",
      404
    );
  }

  try {
    // Fetch all Graduate Attributes (GA)
    const campus = await prisma.campus.findFirst({
      where: {
        CampusID: campusId,
      },
      select: {
        CampusName: true,
      },
    });
    const graduateAttributes = await prisma.graduateAttribute.findMany({
      select: {
        GAID: true,
        GAName: true,
        GANumber: true,
      },
    });

    if (!graduateAttributes.length) {
      logger.warn("No Graduate Attributes found.");
      throw new ApiError("No Graduate Attributes found.", 404);
    }

    logger.info(`Found ${graduateAttributes.length} Graduate Attributes.`);

    // Initialize data structure for performance aggregation by course level
    const courseLevelPerformance: Record<
      string,
      {
        Exceeds: number;
        Acceptable: number;
        Marginal: number;
        Fail: number;
        total: number;
      }
    > = {
      "1000": { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
      "2000": { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
      "3000": { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
      "4000": { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0, total: 0 },
    };

    const gaHasCourseLevelPerformmance: Record<string, boolean> = {};

    for (const ga of graduateAttributes) {
      logger.info(`Processing GA: ${ga.GAName}`);

      // Get all courses contributing to this GA
      const courses =
        await prisma.learningObjectivePerformanceIndicatorMapping.findMany({
          where: {
            GraduateAttribute: { GAID: ga.GAID },
            Course: { CampusID: campusId, Year: year },
            LearningObjective: { IsCurrent: true },
          },
          select: {
            CourseID: true,
            Course: {
              select: { CourseCode: true },
            },
            LearningObjective: {
              select: {
                MappingVersion: true,
              },
            },
          },
          distinct: ["CourseID"],
        });

      if (!courses.length) {
        logger.warn(`No courses found contributing to GA: ${ga.GAName}`);
        continue;
      }

      for (const { Course, CourseID, LearningObjective } of courses) {
        const courseLevel = getCourseLevel(Course.CourseCode);
        if (!courseLevel) continue;
        const currentMappingVersion = LearningObjective.MappingVersion;

        if (!currentMappingVersion) continue;

        // Get student LO grades for the course
        const studentLOGrades = await calculateStudentGradesUnderLO(
          CourseID,
          currentMappingVersion
        );
        if (!Object.keys(studentLOGrades).length) {
          logger.warn(
            `No LO grades found for CourseID: ${CourseID}, skipping...`
          );
          continue;
        }

        const loMappings =
          await prisma.learningObjectivePerformanceIndicatorMapping.findMany({
            where: { CourseID, GAID: ga.GAID },
            select: { LOID: true },
          });

        const loIDs = loMappings.map((lo) => lo.LOID);
        const filteredStudentLOGrades: AllStudentLOGrades = {};

        Object.entries(studentLOGrades).forEach(([studentID, loGrades]) => {
          const filteredLOs = Object.fromEntries(
            Object.entries(loGrades).filter(([loID]) => loIDs.includes(loID))
          );

          if (Object.keys(filteredLOs).length > 0) {
            filteredStudentLOGrades[studentID] = filteredLOs;
          }
        });

        if (Object.keys(filteredStudentLOGrades).length === 0) {
          logger.warn(
            `No relevant LO grades found for GA ${ga?.GAName} in Course: ${CourseID}`
          );
          continue;
        }

        const loPerformanceCounts: Record<
          string,
          {
            Exceeds: number;
            Acceptable: number;
            Marginal: number;
            Fail: number;
          }
        > = {};

        Object.values(filteredStudentLOGrades).forEach((loGrades) => {
          Object.entries(loGrades).forEach(([loID, grade]) => {
            if (!loPerformanceCounts[loID]) {
              loPerformanceCounts[loID] = {
                Exceeds: 0,
                Acceptable: 0,
                Marginal: 0,
                Fail: 0,
              };
            }

            if (grade >= 80) {
              loPerformanceCounts[loID].Exceeds += 1;
            } else if (grade >= 65) {
              loPerformanceCounts[loID].Acceptable += 1;
            } else if (grade >= 50) {
              loPerformanceCounts[loID].Marginal += 1;
            } else {
              loPerformanceCounts[loID].Fail += 1;
            }
          });
        });

        // Aggregate performance counts
        const totalCounts = { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0 };
        let totalAcrossLOs = 0;

        Object.values(studentLOGrades).forEach((loGrades: StudentLOGrades) => {
          Object.values(loGrades).forEach((grade) => {
            if (grade >= 80) totalCounts.Exceeds += 1;
            else if (grade >= 65) totalCounts.Acceptable += 1;
            else if (grade >= 50) totalCounts.Marginal += 1;
            else totalCounts.Fail += 1;
          });
        });

        totalAcrossLOs =
          totalCounts.Exceeds +
          totalCounts.Acceptable +
          totalCounts.Marginal +
          totalCounts.Fail;

        // Accumulate results per course level across all GA
        courseLevelPerformance[courseLevel].Exceeds += totalCounts.Exceeds;
        courseLevelPerformance[courseLevel].Acceptable +=
          totalCounts.Acceptable;
        courseLevelPerformance[courseLevel].Marginal += totalCounts.Marginal;
        courseLevelPerformance[courseLevel].Fail += totalCounts.Fail;
        courseLevelPerformance[courseLevel].total += totalAcrossLOs;
      }

      gaHasCourseLevelPerformmance[ga.GAID] = !Object.values(
        courseLevelPerformance
      ).every((performance) => performance.total === 0);
    }

    logger.info(`Successfully processed course levels across all GA.`);

    if (
      Object.values(gaHasCourseLevelPerformmance).every((gaValues) => !gaValues)
    ) {
      throw new ApiError(
        "No matching records found! No student grades available for all the courses under the given criteria.",
        404
      );
    }

    const chartData = Object.entries(courseLevelPerformance).map(
      ([level, counts]) => ({
        CourseLevel: level,
        Exceeds: (counts.Exceeds / counts.total) * 100 || 0,
        Acceptable: (counts.Acceptable / counts.total) * 100 || 0,
        Marginal: (counts.Marginal / counts.total) * 100 || 0,
        Fail: (counts.Fail / counts.total) * 100 || 0,
      })
    );

    return {
      type: ChartType.COURSE_LEVEL_COMBINING_ALL_GA,
      labels: {
        xAxisLabel: "Course Level",
        yAxisLabel: "Percentage of Students Grades",
        mainTitle: `Course Level Performance Combining All GA - ${year} - ${campus?.CampusName}`,
      },
      data: chartData,
      color: PerformanceColors,
    };
  } catch (error: any) {
    logger.error(
      `Error calculating course level performance across GA:`,
      error
    );
    throw error;
  }
};

const calculateLODistributionForGA = async (
  params: ChartQueryParams
): Promise<Chart> => {
  const { programId, campusId, year, graduateAttribute } = params;

  if (!graduateAttribute || !year) {
    logger.error("Graduate Attribute (GA) and Year must be selected.");
    throw new ApiError(
      "Graduate Attribute (GA) and Year must be selected.",
      400
    );
  }

  const valid = await validateQueryParams(programId, campusId, year);
  if (!valid) {
    throw new ApiError(
      "No matching records found for programId, campusId and year",
      404
    );
  }

  try {
    const dbGraduateAttribute = await prisma.graduateAttribute.findFirst({
      where: {
        GAID: graduateAttribute,
      },
      select: {
        GAID: true,
        GAName: true,
        GANumber: true,
      },
    });

    const courses =
      await prisma.learningObjectivePerformanceIndicatorMapping.findMany({
        where: {
          GraduateAttribute: { GAID: graduateAttribute },
          Course: { CampusID: campusId, Year: year },
        },
        select: {
          CourseID: true,
          Course: {
            select: {
              CourseName: true,
              CourseCode: true,
              Campus: {
                select: {
                  CampusName: true,
                },
              },
            },
          },
        },
        distinct: ["CourseID"],
      });

    if (!courses.length) {
      logger.warn(
        `No courses found contributing to GA: ${dbGraduateAttribute?.GAName} for Year: ${year}`
      );

      throw new ApiError(
        ` No courses found contributing to GA: ${dbGraduateAttribute?.GAName} for Year: ${year}`,
        404
      );
    }

    logger.info(`Found ${courses.length} contributing courses.`);

    const coursePerformances: CourseLOPerformance[] = [];

    logger.info(`processing GA Courses.`);

    let noOfcourseWithoutPerformanceData: number = 0;

    for (const { Course, CourseID } of courses) {
      const gradesCount = await prisma.grade.count({
        where: { CourseID },
      });

      if (gradesCount === 0) {
        logger.warn(`No grades found for CourseID: ${CourseID}, skipping...`);
        continue;
      }

      const currentMapping = await prisma.assessmentTool.findFirst({
        where: {
          CourseID,
          IsCurrent: true,
        },
        select: { MappingVersion: true, ATID: true },
      });

      if (!currentMapping) {
        logger.warn(
          `No current mapping version found for CourseID: ${CourseID}, skipping...`
        );
        continue;
      }

      const mappingVersion = currentMapping.MappingVersion;
      logger.info(
        `Using MappingVersion: ${mappingVersion} for Course: ${CourseID}`
      );

      const studentLOGrades = await calculateStudentGradesUnderLO(
        // pull for particular laerning objs that contributes to the LO
        CourseID,
        mappingVersion
      );

      const loMappings =
        await prisma.learningObjectivePerformanceIndicatorMapping.findMany({
          where: { CourseID, GAID: graduateAttribute },
          select: { LOID: true },
        });

      const coursePI =
        await prisma.learningObjectivePerformanceIndicatorMapping.findFirst({
          where: {
            LearningObjective: {
              IsCurrent: true,
            },
            CourseID: CourseID,
            GAID: graduateAttribute,
          },
          select: {
            PILevel: true,
          },
        });

      const loIDs = loMappings.map((lo) => lo.LOID);
      const filteredStudentLOGrades: AllStudentLOGrades = {};

      Object.entries(studentLOGrades).forEach(([studentID, loGrades]) => {
        const filteredLOs = Object.fromEntries(
          Object.entries(loGrades).filter(([loID]) => loIDs.includes(loID))
        );

        if (Object.keys(filteredLOs).length > 0) {
          filteredStudentLOGrades[studentID] = filteredLOs;
        }
      });

      if (Object.keys(filteredStudentLOGrades).length === 0) {
        logger.warn(
          `No relevant LO grades found for GA ${dbGraduateAttribute?.GAName} in Course: ${CourseID}`
        );
        continue;
      }

      const loPerformanceCounts: Record<
        string,
        { Exceeds: number; Acceptable: number; Marginal: number; Fail: number }
      > = {};

      Object.values(filteredStudentLOGrades).forEach((loGrades) => {
        Object.entries(loGrades).forEach(([loID, grade]) => {
          if (!loPerformanceCounts[loID]) {
            loPerformanceCounts[loID] = {
              Exceeds: 0,
              Acceptable: 0,
              Marginal: 0,
              Fail: 0,
            };
          }

          if (grade >= 80) {
            loPerformanceCounts[loID].Exceeds += 1;
          } else if (grade >= 65) {
            loPerformanceCounts[loID].Acceptable += 1;
          } else if (grade >= 50) {
            loPerformanceCounts[loID].Marginal += 1;
          } else {
            loPerformanceCounts[loID].Fail += 1;
          }
        });
      });

      const totalCounts = { Exceeds: 0, Acceptable: 0, Marginal: 0, Fail: 0 };
      let totalAcrossLOs = 0;

      Object.values(loPerformanceCounts).forEach((counts) => {
        totalCounts.Exceeds += counts.Exceeds;
        totalCounts.Acceptable += counts.Acceptable;
        totalCounts.Marginal += counts.Marginal;
        totalCounts.Fail += counts.Fail;
      });

      totalAcrossLOs =
        totalCounts.Exceeds +
        totalCounts.Acceptable +
        totalCounts.Marginal +
        totalCounts.Fail;

      const performance: PerformanceCategory[] = [
        {
          category: "Exceeds",
          percentage: (totalCounts.Exceeds / totalAcrossLOs) * 100 || 0,
        },
        {
          category: "Acceptable",
          percentage: (totalCounts.Acceptable / totalAcrossLOs) * 100 || 0,
        },
        {
          category: "Marginal",
          percentage: (totalCounts.Marginal / totalAcrossLOs) * 100 || 0,
        },
        {
          category: "Fail",
          percentage: (totalCounts.Fail / totalAcrossLOs) * 100 || 0,
        },
      ];

      let isDataAvailable = !(
        performance[0].percentage === 0 &&
        performance[1].percentage === 0 &&
        performance[2].percentage === 0 &&
        performance[3].percentage === 0
      );

      if (!isDataAvailable) {
        noOfcourseWithoutPerformanceData += 1;
      }

      coursePerformances.push({
        courseID: CourseID,
        courseCode: `${Course.CourseCode} (${coursePI?.PILevel})`,
        performance,
        coursePILevel: coursePI?.PILevel as PILevelType,
      });

      logger.info(`Processed course ${CourseID} (${Course.CourseName})`);
    }

    if (coursePerformances.length === noOfcourseWithoutPerformanceData) {
      throw new ApiError(
        "No student grades available for all the courses under the given criteria.",
        404
      );
    }

    logger.info(
      `Successfully processed GA ${dbGraduateAttribute?.GAName} for Year ${year}. Returning data.`
    );

    // Define sorting order for PI Levels
    const piLevelOrder: Record<PILevelType, number> = { I: 1, D: 2, A: 3 };

    coursePerformances.sort((a, b) => {
      const piA = (a.coursePILevel as PILevelType) || "A"; // Default missing values to 'A'
      const piB = (b.coursePILevel as PILevelType) || "A";

      // First, sort by PI Level based on predefined order
      const levelComparison =
        (piLevelOrder[piA] || 99) - (piLevelOrder[piB] || 99);
      if (levelComparison !== 0) return levelComparison;

      // Extract the numeric part of CourseCode, handling both "ENGN-1220" and "ENGN1220 (I)"
      const numA = parseInt(
        a.courseCode.replace(/\D/g, "").slice(0, 4) || "9999",
        10
      );
      const numB = parseInt(
        b.courseCode.replace(/\D/g, "").slice(0, 4) || "9999",
        10
      );

      // Then, sort by the numeric course code in ascending order
      return numA - numB;
    });

    // Return structured data following `Chart` type
    return {
      type: ChartType.GA_BY_COURSE_AND_IDA,
      labels: {
        xAxisLabel: "Courses",
        yAxisLabel: "Percentage of Students Grades",
        mainTitle: `Graduate Attribute: ${dbGraduateAttribute?.GAName} - ${year} - ${courses[0]?.Course.Campus.CampusName}`,
      },
      data: {
        graduateAttribute:
          `${dbGraduateAttribute?.GANumber}-${dbGraduateAttribute?.GAName}` as string,
        GAID: graduateAttribute,
        colors: PerformanceColors,
        courses: coursePerformances,
      },
    };
  } catch (error: any) {
    logger.error(
      `Error calculating LO distribution for GA ${graduateAttribute}:`,
      error
    );
    throw error;
  }
};

async function fetchGAByIDA(params: ChartQueryParams): Promise<Chart> {
  const { programId, campusId, year } = params;

  if (!year) {
    throw new ApiError("Year must be selected.", 400);
  }

  const valid = await validateQueryParams(programId, campusId, year);
  if (!valid) {
    throw new ApiError(
      "No records found matching the specified Program, Campus, and Year Entered.",
      404
    );
  }

  const data = await prisma.graduateAttribute.findMany({
    where: { ProgramID: programId },
    select: {
      GAName: true,
      GANumber: true,
      GAID: true,
      PerformanceIndicatorMappings: {
        where: {
          Course: { CampusID: campusId, Year: year },
          LearningObjective: { IsCurrent: true },
        },
        select: {
          PILevel: true,
          CourseID: true,
        },
      },
    },
  });

  const chartData: GAChartData[] = data.map((ga) => {
    const uniqueCoursesByPI = {
      I: new Set(),
      D: new Set(),
      A: new Set(),
    };

    ga.PerformanceIndicatorMappings.forEach((pi) => {
      if (pi.PILevel === "I") uniqueCoursesByPI.I.add(pi.CourseID);
      if (pi.PILevel === "D") uniqueCoursesByPI.D.add(pi.CourseID);
      if (pi.PILevel === "A") uniqueCoursesByPI.A.add(pi.CourseID);
    });

    return {
      graduateAttribute: `${ga.GANumber}-${ga.GAName}`,
      GAID: ga.GAID,
      values: [
        { label: "I", count: uniqueCoursesByPI.I.size, color: PILevelColor.I },
        { label: "D", count: uniqueCoursesByPI.D.size, color: PILevelColor.D },
        { label: "A", count: uniqueCoursesByPI.A.size, color: PILevelColor.A },
      ],
    };
  });

  console.log(chartData, "chartData");

  const hasCoursesByPI = !Object.values(chartData).every((data) =>
    data.values.every((d) => d.count == 0)
  );

  if (!hasCoursesByPI) {
    throw new ApiError(
      "No matching records found! No course PI  under the given criteria.",
      404
    );
  }

  return {
    type: ChartType.GA_BY_IDA,
    labels: {
      xAxisLabel: "Graduate Attribute",
      yAxisLabel: "Number of Courses",
      mainTitle: "Number of Courses Used for GA Assessment (by I, D, A Level)",
    },
    data: chartData,
  };
}

export function getCourseLevel(courseCode: string): number | null {
  const match = courseCode.match(/\d/);
  if (match) {
    return parseInt(match[0]) * 1000;
  }
  return null;
}

async function fetchGAByCourseLevel(params: ChartQueryParams): Promise<Chart> {
  const { programId, campusId, year } = params;

  if (!year) {
    throw new ApiError("Year must be selected.", 400);
  }

  const valid = await validateQueryParams(programId, campusId, year);
  if (!valid) {
    throw new ApiError(
      "No records found matching the specified Program, Campus, and Year Entered.",
      404
    );
  }

  const data = await prisma.graduateAttribute.findMany({
    where: { ProgramID: programId },
    select: {
      GAName: true,
      GANumber: true,
      GAID: true,
      PerformanceIndicatorMappings: {
        where: {
          Course: { CampusID: campusId, Year: year },
          LearningObjective: { IsCurrent: true },
        },
        select: {
          CourseID: true,
          Course: { select: { CourseCode: true } },
        },
      },
    },
  });

  const chartData: GAChartData[] = data.map((ga) => {
    const uniqueCoursesByLevel = {
      LEVEL_1000: new Set(),
      LEVEL_2000: new Set(),
      LEVEL_3000: new Set(),
      LEVEL_4000: new Set(),
    };

    ga.PerformanceIndicatorMappings.forEach((mapping) => {
      const courseCode = mapping.Course?.CourseCode || "";
      const courseLevel = getCourseLevel(courseCode);

      if (courseLevel === 1000)
        uniqueCoursesByLevel.LEVEL_1000.add(mapping.CourseID);
      if (courseLevel === 2000)
        uniqueCoursesByLevel.LEVEL_2000.add(mapping.CourseID);
      if (courseLevel === 3000)
        uniqueCoursesByLevel.LEVEL_3000.add(mapping.CourseID);
      if (courseLevel === 4000)
        uniqueCoursesByLevel.LEVEL_4000.add(mapping.CourseID);
    });

    return {
      graduateAttribute: `${ga.GANumber}-${ga.GAName}`,
      GAID: ga.GAID,
      values: [
        {
          label: "1000",
          count: uniqueCoursesByLevel.LEVEL_1000.size,
          color: CourseLevelColor.LEVEL_1000,
        },
        {
          label: "2000",
          count: uniqueCoursesByLevel.LEVEL_2000.size,
          color: CourseLevelColor.LEVEL_2000,
        },
        {
          label: "3000",
          count: uniqueCoursesByLevel.LEVEL_3000.size,
          color: CourseLevelColor.LEVEL_3000,
        },
        {
          label: "4000",
          count: uniqueCoursesByLevel.LEVEL_4000.size,
          color: CourseLevelColor.LEVEL_4000,
        },
      ],
    };
  });
  const hasGAByCourses = !Object.values(chartData).every((data) =>
    data.values.every((d) => d.count == 0)
  );

  if (!hasGAByCourses) {
    throw new ApiError(
      "No matching records found! No course PI  under the given criteria.",
      404
    );
  }
  return {
    type: ChartType.GA_BY_COURSE_LEVEL,
    labels: {
      xAxisLabel: "Graduate Attribute",
      yAxisLabel: "Number of Courses",
      mainTitle: "Number of Courses Used for GA Assessment (by Course Level)",
    },
    data: chartData,
  };
}

export async function validateQueryParams(
  programID: string,
  campusID: string,
  year: string
): Promise<boolean> {
  const exists = await prisma.course.findFirst({
    where: {
      CampusID: campusID,
      Year: year,
      Campus: {
        Programs: {
          some: { ProgramID: programID },
        },
      },
    },
  });

  return !!exists;
}
