import { NextRequest, NextResponse } from "next/server";
import prisma from "@/lib/prisma";
import logger from "@/lib/logger";
import {
  ApiResponse,
  ChartQueryParams,
  ChartDataReturnDto,
  ChartType,
} from "@/types";
import { getCourseLevel, validateQueryParams } from "../route";
import ExcelJS from "exceljs";
import path from "path";
import fs from "fs";

export async function GET(
  req: NextRequest,
  context: { params: { chartType: ChartType } }
) {
  try {
    const { searchParams } = new URL(req.url);

    const programId = searchParams.get("programId");
    const campusId = searchParams.get("campusId");
    const year = searchParams.get("year") || undefined;
    const graduateAttribute =
      searchParams.get("graduateAttribute") || undefined;

    if (!programId || !campusId || !year) {
      logger.warn("Missing required query parameters", {
        programId,
        campusId,
        year,
      });
      return NextResponse.json<ApiResponse<null>>(
        {
          error: {
            message: "programID, campusID, and year are required",
            status: 400,
          },
        },
        { status: 400 }
      );
    }

    const chartType = context.params.chartType;
    logger.info(`Fetching chart data for type: ${chartType}`);

    const queryParams: ChartQueryParams = {
      programId,
      campusId,
      year,
      graduateAttribute,
    };

    switch (chartType) {
      case ChartType.GA_COURSE_PI_MAPPING:
        logger.info("Fetching GA Course PI Mapping...");
        return await generateGACoursePIMappingExcel(queryParams);
      default:
        logger.error("Invalid chartType requested", { chartType });
        return NextResponse.json<ApiResponse<null>>(
          {
            error: { message: "Invalid chartType", status: 400 },
          },
          { status: 400 }
        );
    }
  } catch (error: any) {
    logger.error("API Error:", error);
    return NextResponse.json<ApiResponse<null>>(
      {
        error: { message: "Internal Server Error", status: 500 },
      },
      { status: 500 }
    );
  }
}

const generateGACoursePIMappingExcel = async (params: ChartQueryParams) => {
  const { programId, campusId, year } = params;

  if (!year) {
    logger.error("Year must be selected.");
    throw new Error("Year must be selected.");
  }

  const valid = await validateQueryParams(programId, campusId, year);
  if (!valid) {
    throw new Error("No matching records found.", { cause: 404 });
  }
  try {
    // Fetch courses with GA-PI mappings
    const courses = await prisma.course.findMany({
      where: {
        CampusID: campusId,
        Year: year,
        Campus: {
          Programs: {
            some: { ProgramID: programId },
          },
        },
      },
      include: {
        PerformanceIndicatorMappings: {
          include: { GraduateAttribute: true },
        },
      },
      orderBy: {
        CourseCode: "asc",
      },
    });

    if (!courses.length) {
      return NextResponse.json(
        { error: "No matching records found." },
        { status: 404 }
      );
    }

    // Fetch Graduate Attributes
    const graduateAttributes = await prisma.graduateAttribute.findMany({
      where: { ProgramID: programId },
      orderBy: { GANumber: "asc" },
    });

    logger.info("Data fetched successfully. Creating Excel file...");

    // Create an Excel workbook
    const workbook = new ExcelJS.Workbook();
    const worksheet = workbook.addWorksheet("Graduate Attribute Mapping");

    // Define styles
    const headerStyle = {
      font: { bold: true, color: { argb: "FFFFFF" } },
      alignment: { horizontal: "center", vertical: "middle" },
      fill: { type: "pattern", pattern: "solid", fgColor: { argb: "4F81BD" } }, // Blue Header
      border: {
        top: { style: "thin" },
        bottom: { style: "thin" },
        left: { style: "thin" },
        right: { style: "thin" },
      },
    };
    const courseStyle = {
      font: { bold: true, color: { argb: "000000" } },
      fill: { type: "pattern", pattern: "solid", fgColor: { argb: "FFC000" } }, // Yellow Course Code
      alignment: { horizontal: "center" },
    };
    const piStyles = {
      I: {
        fill: {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "B7DEE8" },
        },
        alignment: { horizontal: "center" },
      }, // Light Blue
      D: {
        fill: {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "E6EFC2" },
        },
        alignment: { horizontal: "center" },
      }, // Light Green
      A: {
        fill: {
          type: "pattern",
          pattern: "solid",
          fgColor: { argb: "FDE9D9" },
        },
        alignment: { horizontal: "center" },
      }, // Light Orange
    };
    const borderStyle = {
      border: {
        top: { style: "thick" },
        bottom: { style: "thick" },
        left: { style: "thick" },
        right: { style: "thick" },
      },
    };

    // Construct Headers with GA Sub-columns (I, D, A)
    const headers = ["Course Code", "Course Number"];
    const gaHeaderRow: any[] = ["", ""]; // Empty for first row
    const piHeaderRow: any[] = ["Course Code", "Course Number"];

    graduateAttributes.forEach((ga) => {
      gaHeaderRow.push(`${ga.GANumber} - ${ga.GAName}`, "", "");
      piHeaderRow.push("I", "D", "A");
    });

    // Add headers to the worksheet
    worksheet.addRow(gaHeaderRow);
    worksheet.addRow(piHeaderRow);

    // Merge GA Name cells across its three sub-columns
    let columnIndex = 3; // Start at column 3 (after Course Code, Course Number)
    graduateAttributes.forEach(() => {
      worksheet.mergeCells(1, columnIndex, 1, columnIndex + 2);
      columnIndex += 3;
    });

    // Apply styles to headers
    worksheet.getRow(1).eachCell((cell) => Object.assign(cell, headerStyle));
    worksheet.getRow(2).eachCell((cell) => Object.assign(cell, headerStyle));

    // Populate course data under the correct GA-PI level
    courses.forEach((course) => {
      const courseLevel = getCourseLevel(course.CourseCode);
      const row: any[] = [course.CourseCode, courseLevel];

      // Initialize GA mappings
      const gaMap: Record<string, string> = {};
      graduateAttributes.forEach((ga) => {
        gaMap[`${ga.GANumber} - I`] = "";
        gaMap[`${ga.GANumber} - D`] = "";
        gaMap[`${ga.GANumber} - A`] = "";
      });

      // Assign PI levels under the correct GA-PI column
      course.PerformanceIndicatorMappings.forEach((mapping) => {
        if (mapping.GraduateAttribute) {
          const gaKey = `${mapping.GraduateAttribute.GANumber} - ${mapping.PILevel}`;
          gaMap[gaKey] = mapping.PILevel; // Instead of "X", place "I", "D", or "A"
        }
      });

      // Append row data
      const newRow = worksheet.addRow([...row, ...Object.values(gaMap)]);

      // Apply styles to Course Code & Number
      //@ts-ignore
      newRow.getCell(1).style = courseStyle;
      //@ts-ignore
      newRow.getCell(2).style = courseStyle;

      // Apply colors and center alignment for PI values
      let cellIndex = 3;
      Object.values(gaMap).forEach((piValue) => {
        if (piValue) {
          //@ts-ignore
          newRow.getCell(cellIndex).style = { ...piStyles[piValue] };
        }
        cellIndex++;
      });
    });

    // Apply thick border for each GA section
    columnIndex = 3;
    graduateAttributes.forEach(() => {
      worksheet
        .getColumn(columnIndex)
        .eachCell((cell) => Object.assign(cell, borderStyle));
      worksheet
        .getColumn(columnIndex + 1)
        .eachCell((cell) => Object.assign(cell, borderStyle));
      worksheet
        .getColumn(columnIndex + 2)
        .eachCell((cell) => Object.assign(cell, borderStyle));
      columnIndex += 3;
    });

    // Generate file path
    const fileName = `GA_Course_PI_Mapping_${year}.xlsx`;
    const filePath = path.join("/tmp", fileName);

    // Save Excel file
    await workbook.xlsx.writeFile(filePath);
    logger.info(`Excel file saved at ${filePath}`);

    // Read and return file as response
    const fileBuffer = fs.readFileSync(filePath);
    return new NextResponse(fileBuffer, {
      headers: {
        "Content-Type":
          "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        "Content-Disposition": `attachment; filename=${fileName}`,
      },
    });
  } catch (error: any) {
    logger.error("Error generating Excel:", error);
    return NextResponse.json(
      { error: "Internal Server Error" },
      { status: 500 }
    );
  }
};
