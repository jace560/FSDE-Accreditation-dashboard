import { NextRequest, NextResponse } from "next/server";
import jwt, { JwtPayload } from "jsonwebtoken";
import { serialize } from "cookie";

export async function GET(req: NextRequest) {
  try {
    // Get refresh token from cookies
    const refreshToken = req.cookies.get("refresh_token")?.value;

    if (!refreshToken) {
      return NextResponse.json({ error: "No refresh token" }, { status: 401 });
    }

    // Verify Refresh Token and explicitly type `decoded`
    const decoded = jwt.verify(
      refreshToken,
      process.env.NEXTAUTH_SECRET!
    ) as JwtPayload;

    if (!decoded || !decoded.UserID || !decoded.Email || !decoded.Role) {
      return NextResponse.json(
        { error: "Invalid refresh token" },
        { status: 403 }
      );
    }

    // Generate new access token
    const newAccessToken = jwt.sign(
      {
        UserID: decoded.UserID,
        Email: decoded.Email,
        Role: decoded.Role,
      },
      process.env.NEXTAUTH_SECRET!,
      { expiresIn: "15m" }
    );

    // Set new access token cookie
    const accessCookie = serialize("access_token", newAccessToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      path: "/",
    });

    const res = NextResponse.json({ message: "Token refreshed" });
    res.headers.set("Set-Cookie", accessCookie);
    return res;
  } catch (error) {
    return NextResponse.json(
      { error: "Invalid refresh token" },
      { status: 403 }
    );
  }
}
