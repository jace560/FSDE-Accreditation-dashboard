import NextAuth, { AuthOptions } from "next-auth";
import CredentialsProvider from "next-auth/providers/credentials";
import bcrypt from "bcryptjs";
import prisma from "@/lib/prisma";
import { User, USER_STATUS } from "@/types";
import { Token } from "@/types/next-auth";
import { serialize } from "cookie";
import jwt, { Secret, SignOptions } from "jsonwebtoken";
import { loginSchema } from "@/utils";

export const authOptions: AuthOptions = {
  providers: [
    CredentialsProvider({
      name: "Credentials",
      credentials: {
        email: { label: "Email", type: "text" },
        password: { label: "Password", type: "password" },
      },
      // @ts-ignore
      async authorize(credentials): Promise<User | null> {
        const parsed = loginSchema.safeParse(credentials);
        if (!parsed.success) throw new NextAuthError("Invalid input data");

        const { Email, Password } = parsed.data;
        const user = await prisma.user.findUnique({ where: { Email } });

        if (!user) throw new NextAuthError("No user found");

        if (user.Status === USER_STATUS.BLOCKED) {
          throw new NextAuthError(
            "Your account has been blocked. Please contact support."
          );
        }

        if (user.Status === USER_STATUS.UNAUTHENTICATED) {
          throw new NextAuthError(
            "Your account is unauthenticated blocked. Please contact support."
          );
        }

        const passwordMatch = await bcrypt.compare(Password, user.Password);
        if (!passwordMatch)
          throw new NextAuthError("Invalid Email or Password!");

        return {
          UserID: user.UserID,
          FirstName: user.FirstName,
          LastName: user.LastName,
          FullName: `${user.FirstName} ${user.LastName}`,
          Email: user.Email,
          Role: user.Role,
          Initials: `${user.FirstName[0]}${user.LastName[0]}`.toUpperCase(),
          Status: user.Status,
        } as User;
      },
    }),
  ],
  callbacks: {
    async jwt({ token, user }) {
      if (user) {
        const typeUser = user as unknown as User;
        token = {
          UserID: typeUser.UserID,
          FirstName: typeUser.FirstName,
          LastName: typeUser.LastName,
          FullName: typeUser.FullName,
          Email: typeUser.Email,
          Role: typeUser.Role,
          Initials: typeUser.Initials,
          Status: typeUser.Status,
        } as Token;
      }
      return token;
    },

    async session({ session, token }) {
      if (token) {
        const typedToken = token as Token;
        session.user = {
          UserID: typedToken?.UserID,
          FirstName: typedToken?.FirstName,
          LastName: typedToken?.LastName,
          FullName: typedToken?.FullName,
          Email: typedToken?.Email,
          Role: typedToken?.Role,
          Initials: typedToken?.Initials,
          Status: typedToken?.Status,
        };
      }
      return session;
    },
  },
  pages: {
    signIn: "/",
  },
  secret: process.env.NEXTAUTH_SECRET,
  session: {
    strategy: "jwt",
    maxAge: 86400,
  },
};

const handler = NextAuth(authOptions);
export { handler as GET, handler as POST };

export class NextAuthError extends Error {
  constructor(message: string) {
    super(message);
    this.name = "NextAuthError";
  }
}

type dbUserType = {
  UserID: string;
  FirstName: string;
  LastName: string;
  FullName: string;
  Email: string;
  Role: string;
  Status: string;
};

function generateJWT(
  user: {
    UserID: string;
    Email: string;
    Role: string;
  },
  expiresIn: string = "15m"
): string {
  const secret: Secret | undefined = process.env.NEXTAUTH_SECRET;

  if (!secret) {
    throw new Error("NEXTAUTH_SECRET is not defined in environment variables.");
  }

  const token = jwt.sign(
    {
      UserID: user.UserID,
      Email: user.Email,
      Role: user.Role,
    },
    secret,
    { expiresIn } as SignOptions
  );

  return token;
}
