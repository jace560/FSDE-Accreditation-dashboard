import { NextRequest, NextResponse } from "next/server";
import bcrypt from "bcryptjs";
import prisma from "@/lib/prisma";
import { USER_ROLE, USER_STATUS } from "@/types";
import { signUpSchema } from "@/utils";
import logger from "@/lib/logger";
import jwt from "jsonwebtoken";
import { Resend } from "resend";

const JWT_SECRET = process.env.NEXT_JWT_SECRET || "your-very-secure-secret";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    logger.info("📩 Incoming Registration Request", body);

    console.log(body, "BODY");
    if (!body || Object.keys(body).length === 0) {
      logger.warn("⚠️ Empty request body in registration");
      return NextResponse.json(
        { error: "Request body is missing or empty" },
        { status: 400 }
      );
    }

    const parsedData = signUpSchema.safeParse(body);
    if (!parsedData.success) {
      logger.warn("⚠️ Validation failed", { errors: parsedData.error.errors });
      return NextResponse.json(
        { error: parsedData.error.errors },
        { status: 400 }
      );
    }

    const { FirstName, LastName, Email, Password } = parsedData.data;

    // ✅ Start a Prisma transaction
    const result = await prisma.$transaction(async (prisma) => {
      // ✅ Check if user already exists
      const existingUser = await prisma.user.findUnique({ where: { Email } });
      if (existingUser) {
        logger.warn("⚠️ User already exists", { Email });
        throw new Error("User already exists"); // ❌ This will rollback the transaction
      }

      // ✅ Hash password
      const hashedPassword = await bcrypt.hash(Password, 10);
      logger.info("🔑 Password hashed successfully");

      // ✅ Create new user
      const user = await prisma.user.create({
        data: {
          FirstName,
          LastName,
          Email,
          Password: hashedPassword,
          Role: USER_ROLE.USER,
          Status: USER_STATUS.UNAUTHENTICATED,
        },
      });

      logger.info("✅ User created successfully", {
        UserID: user.UserID,
        Email,
      });

      const verificationToken = jwt.sign({ email: user.Email }, JWT_SECRET, {
        expiresIn: "1h",
      });

      const verificationLink = `${process.env.NEXT_PUBLIC_BASE_URL}?token=${verificationToken}&view=verify`;
      await sendVerificationEmail(user.Email, verificationLink);

      return user;
    });

    return NextResponse.json(
      {
        message:
          "User created successfully. Check your email for verification.",
      },
      { status: 201 }
    );
  } catch (error: unknown) {
    if (error instanceof Error) {
      logger.error("❌ Server error in registration", {
        message: error.message,
        stack: error.stack,
      });

      if (error.message === "User already exists") {
        return NextResponse.json({ error: error.message }, { status: 400 });
      }
    } else {
      logger.error("❌ Unknown error in registration", { error });
    }

    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}

const NEXT_RESEND_API_KEY = process.env.NEXT_RESEND_API_KEY;
console.log("API Key from .env:", NEXT_RESEND_API_KEY);

const resend = new Resend(NEXT_RESEND_API_KEY);

export async function sendVerificationEmail(
  email: string,
  verificationLink: string
) {
  try {
    await resend.emails.send({
      from: "onramp@resend.dev",
      to: email,
      subject: "Verify Your Email - Welcome to Our Platform!",
      html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; background: #f9f9f9; border-radius: 8px; text-align: center;">
        <h2 style="color: #333;">Welcome to Our Platform! 🎉</h2>
        <p style="color: #555; font-size: 16px;">
          You're almost there! Click the button below to verify your email and activate your account.
        </p>
        <a href="${verificationLink}" 
          style="display: inline-block; background-color: #007bff; color: #ffffff; text-decoration: none; padding: 12px 20px; font-size: 16px; border-radius: 5px; margin: 20px 0; font-weight: bold;">
          Verify My Email
        </a>
        <p style="color: #777; font-size: 14px;">
          If you didn’t request this, you can safely ignore this email.
        </p>
        <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
        <p style="color: #999; font-size: 12px;">
          Need help? Contact our support team at 
          <a href="mailto:support@yourdomain.com" style="color: #007bff;">support@yourdomain.com</a>.
        </p>
      </div>
      `,
    });
  } catch (error) {
    console.error("❌ Error sending verification email:", error);
  }
}
