import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import { Resend } from "resend";
import { z } from "zod";

const resend = new Resend(process.env.NEXT_RESEND_API_KEY);
const JWT_SECRET = process.env.NEXT_JWT_SECRET || "your-secret-key";

// ✅ Zod schema to validate email input
const forgotPasswordSchema = z.object({
  Email: z.string().email("Invalid email format"),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // ✅ Validate email input
    const parsedData = forgotPasswordSchema.safeParse(body);
    if (!parsedData.success) {
      return NextResponse.json(
        { error: parsedData.error.errors },
        { status: 400 }
      );
    }

    const { Email } = parsedData.data;

    // ✅ Generate JWT token valid for 1 hour
    const resetToken = jwt.sign({ Email }, JWT_SECRET, { expiresIn: "1h" });

    // ✅ Construct reset password link
    const resetLink = `${process.env.NEXT_PUBLIC_BASE_URL}?token=${resetToken}&view=reset`;

    // ✅ Send reset email using Resend (testing mode)
    const emailResponse = await resend.emails.send({
      from: "onramp@resend.dev", // Resend testing domain
      to: Email,
      subject: "Reset Your Password",
      html: `
        <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; background: #f9f9f9; border-radius: 8px; text-align: center;">
          <h2 style="color: #333;">Reset Your Password 🔒</h2>
          <p style="color: #555; font-size: 16px;">
            Click the button below to reset your password. This link will expire in 1 hour.
          </p>
          <a href="${resetLink}" 
            style="display: inline-block; background-color: #d9534f; color: #ffffff; text-decoration: none; padding: 12px 20px; font-size: 16px; border-radius: 5px; margin: 20px 0; font-weight: bold;">
            Reset My Password
          </a>
          <p style="color: #777; font-size: 14px;">
            If you didn’t request this, you can safely ignore this email.
          </p>
        </div>
      `,
    });

    console.log("✅ Email sent successfully:", emailResponse);

    return NextResponse.json(
      { message: "Password reset email sent. Check your inbox." },
      { status: 200 }
    );
  } catch (error) {
    console.error("❌ Forgot password error:", error);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
