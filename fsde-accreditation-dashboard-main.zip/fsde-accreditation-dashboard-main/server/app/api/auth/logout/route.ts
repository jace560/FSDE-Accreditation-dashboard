import { NextResponse } from "next/server";
import { serialize } from "cookie";

export async function GET() {
  const res = NextResponse.json({ message: "Logged out" });

  res.headers.set(
    "Set-Cookie",
    [
      serialize("access_token", "", { maxAge: 0, path: "/" }),
      serialize("refresh_token", "", { maxAge: 0, path: "/" }),
    ].join("; ") // ✅ Fix: Ensure cookies are properly joined
  );

  return res;
}
