import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import bcrypt from "bcryptjs";
import { z } from "zod";
import prisma from "@/lib/prisma"; // Adjust path based on your setup
import { USER_STATUS } from "@/types";
import { NextAuthError } from "../[...nextauth]/route";
import { resetPasswordSchema } from "@/utils";

const JWT_SECRET = process.env.NEXT_JWT_SECRET || "your-secret-key";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();

    // ✅ Validate request body using Zod
    const parsedData = resetPasswordSchema.safeParse(body);
    if (!parsedData.success) {
      return NextResponse.json(
        { error: parsedData.error.errors },
        { status: 400 }
      );
    }

    const { Password, Email } = parsedData.data;

    // ✅ Find the user in the database
    const user = await prisma.user.findUnique({ where: { Email: Email } });
    if (!user) {
      return NextResponse.json({ error: "User not found" }, { status: 404 });
    }

    if (user.Status === USER_STATUS.BLOCKED) {
      throw new NextAuthError(
        "Your account has been blocked. Please contact support."
      );
    }

    if (user.Status === USER_STATUS.UNAUTHENTICATED) {
      throw new NextAuthError(
        "Your account is unauthenticated blocked. Please contact support."
      );
    }

    // ✅ Hash the new password
    const hashedPassword = await bcrypt.hash(Password, 10);

    // ✅ Update the user's password in the database
    await prisma.user.update({
      where: { Email: Email },
      data: { Password: hashedPassword },
    });

    return NextResponse.json(
      { message: "Password reset successfully. You can now log in." },
      { status: 200 }
    );
  } catch (error) {
    console.error("❌ Reset password error:", error);
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
