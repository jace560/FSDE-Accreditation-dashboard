import { NextRequest, NextResponse } from "next/server";
import jwt from "jsonwebtoken";
import prisma from "@/lib/prisma";
import logger from "@/lib/logger";
import { USER_ROLE, USER_STATUS } from "@/types";

const JWT_SECRET = process.env.NEXT_JWT_SECRET || "your-very-secure-secret";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const token = searchParams.get("token");

    if (!token) {
      return NextResponse.json({ error: "Missing token" }, { status: 400 });
    }

    // ✅ Verify the JWT token
    let decoded;
    try {
      decoded = jwt.verify(token, JWT_SECRET);
    } catch (error) {
      return NextResponse.json(
        { error: "Invalid or expired token" },
        { status: 400 }
      );
    }
    //@ts-ignore
    const email = decoded.email;

    // ✅ Mark user as verified in the database
    await prisma.user.update({
      where: { Email: email },
      data: { Status: USER_STATUS.ACTIVE },
    });

    logger.info("✅ Email verified successfully", { Email: email });

    return NextResponse.json(
      { message: "Email verified successfully" },
      { status: 200 }
    );
  } catch (error: unknown) {
    logger.error("❌ Error verifying email", { message: error });
    return NextResponse.json({ error: "Server error" }, { status: 500 });
  }
}
