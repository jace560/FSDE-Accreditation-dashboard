import prisma from "@/lib/prisma";
import { GraduateAttribute } from "@prisma/client";
import { errorResponse, successResponse } from "@/lib/utils";
import { NextResponse } from "next/server";
import { ApiResponse } from "@/types";

export async function GET() {
  try {
    const programs: GraduateAttribute[] =
      await prisma.graduateAttribute.findMany();

    return NextResponse.json<ApiResponse<any>>({
      data: programs,
    });
  } catch (error: any) {
    return NextResponse.json<ApiResponse<null>>(
      {
        error: { message: "Invalid Data", status: 400 },
      },
      { status: 400 }
    );
  }
}
