// ✅ app/metadata.ts (Server Component)
import type { Metadata } from "next";

// export const metadata: Metadata = {
//   title: {
//     template: "%s | Curriculum Accreditation Dashboard",
//     default: "Curriculum Accreditation Dashboard",
//   },
// };
