export const metadata: Metadata = {
  title: "Admin Panel | Curriculum Accreditation",
  description: "Manage users, and accreditation settings.",
};
import React from "react";
import { Metadata } from "next";
import Admin from "./components/admin";
import logger from "@/lib/logger";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/app/components/ui/card";
import { USER_ROLE, USER_STATUS, type UsersReturnDto } from "@/types/index";

const page = async () => {
  try {
    logger.info("Fetching initial users data.");
    logger.info("Successfully fetched users data.");

    return <Admin />;
  } catch (error: any) {
    logger.error(`Error loading admin page: ${error.message}`);
    return (
      <Card className="mx-auto max-w-md mt-8">
        <CardHeader>
          <CardTitle className="text-red-500 text-center">
            Something Went Wrong
          </CardTitle>
        </CardHeader>
        <CardContent>
          <p className="text-center text-gray-600">
            We encountered an error while loading the admin dashboard. Please
            try again later.
          </p>
        </CardContent>
      </Card>
    );
  }
};

export default page;
