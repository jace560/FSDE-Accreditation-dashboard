"use client";

import React, { useEffect, useState } from "react";
import { Card } from "@/app/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/app/components/ui/table";
import { Pencil, Trash2, ChevronLeft, ChevronRight } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/app/components/ui/dropdown-menu";
import { useCustomToast } from "@/hooks/custom/use-custom-toast";
import { Button } from "@/app/components/ui/button";
import Loader from "@/app/components/loader";
import { EditDialog } from "./admin-user-table-edit";
import {
  USER_ROLE,
  USER_STATUS,
  USER_STATUS_OPTIONS,
  type User,
  type UsersReturnDto,
} from "@/types/index";
import {
  useDeleteUserMutation,
  useUpdateUserRoleMutation,
  useUpdateUserStatusMutation,
} from "@/redux/api/admin";
import { useAuth } from "@/hooks/custom/use-auth";

export const USER_ROLE_OPTIONS = [
  { value: "USER", label: "User" },
  { value: "ADMIN", label: "Admin" },
  { value: "SUPER_ADMIN", label: "Super Admin" },
];

interface UserTableProps {
  users: UsersReturnDto;
  isLoading: boolean;
  handleRowsPerPageChange: (rows: number) => void;
  handlePageChange: (page: number) => void;
}

const UserTable = ({
  users,
  isLoading,
  handlePageChange,
  handleRowsPerPageChange,
}: UserTableProps) => {
  // ✅ Ensure hooks are called at the top level
  const [updateUserRole] = useUpdateUserRoleMutation();
  const [updateUserStatus] = useUpdateUserStatusMutation();

  const [deleteUser] = useDeleteUserMutation();
  const { showConfirmationToast, showSuccessToast, showErrorToast } =
    useCustomToast();

  const { isSuperAdmin } = useAuth();

  const [currentPage, setCurrentPage] = useState(
    Number(users?.meta?.page) || 1
  );
  const [rowsPerPage, setRowsPerPage] = useState(
    Number(users?.meta?.limit) || 10
  );

  useEffect(() => {
    setCurrentPage(Number(users?.meta?.page) || 1);
    setRowsPerPage(Number(users?.meta?.limit) || 10);
  }, [users?.meta]);

  const totalPages = Math.ceil(users?.meta?.totalUsers / rowsPerPage);

  const extractErrorMessage = (error: any) => {
    return error?.data?.error || "An error occurred.";
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      handlePageChange(nextPage);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      const prevPage = currentPage - 1;
      setCurrentPage(prevPage);
      handlePageChange(prevPage);
    }
  };

  const handleRowsChange = (rows: number) => {
    setRowsPerPage(rows);
    setCurrentPage(1);
    handleRowsPerPageChange(rows);
  };

  const handleDelete = (userId: string, userName: string) => {
    showConfirmationToast(
      `Are you sure you want to delete ${userName}?`,
      "Delete",
      async () => {
        try {
          await deleteUser({ userID: userId }).unwrap();
          showSuccessToast(`User ${userName} deleted successfully.`);
        } catch (error) {
          console.log(error, "ERROR");
          showErrorToast(extractErrorMessage(error));
        }
      }
    );
  };

  const handleRoleChange = (userId: string, newRole: USER_ROLE) => {
    showConfirmationToast(
      "Are you sure you want to update the user role?",
      "Update",
      async () => {
        try {
          await updateUserRole({ userID: userId, role: newRole }).unwrap();
          showSuccessToast("User role updated successfully.");
        } catch (error) {
          showErrorToast(extractErrorMessage(error));
        }
      }
    );
  };

  const handleStatusChange = (userId: string, newStatus: USER_STATUS) => {
    showConfirmationToast(
      "Are you sure you want to update the user status?",
      "Update",
      async () => {
        try {
          await updateUserStatus({
            userID: userId,
            status: newStatus,
          }).unwrap();
          showSuccessToast("User role updated successfully.");
        } catch (error) {
          showErrorToast(extractErrorMessage(error));
        }
      }
    );
  };

  if (isLoading) {
    return <Loader message="Loading users..." />;
  }

  if (!users.Users || users.Users.length === 0) {
    return (
      <div className="text-gray-700 text-center mt-4">No users available.</div>
    );
  }

  return (
    <div className="mt-6 text-sm">
      <Card className="shadow-sm rounded-sm">
        <div className="overflow-x-auto">
          <Table className="min-w-full bg-white rounded-lg">
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead className="px-6 py-4 text-sm font-medium text-gray-600">
                  Name
                </TableHead>
                <TableHead className="px-6 py-4 text-sm font-medium text-gray-600">
                  Email
                </TableHead>
                <TableHead className="px-6 py-4 text-sm font-medium text-gray-600">
                  Status
                </TableHead>
                <TableHead className="px-6 py-4 text-sm font-medium text-gray-600">
                  Role
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {users.Users.map((user) => (
                <TableRow key={user.UserID}>
                  <TableCell className="px-6 py-4">{user.FullName}</TableCell>
                  <TableCell className="px-6 py-4">{user.Email}</TableCell>
                  <TableCell className="px-6 py-4">
                    <Select
                      onValueChange={(value) =>
                        handleRoleChange(
                          user.UserID as string,
                          value as USER_ROLE
                        )
                      }
                      defaultValue={user.Role}
                    >
                      <SelectTrigger
                        disabled={!isSuperAdmin}
                        className="w-32 text-sm"
                      >
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent>
                        {USER_ROLE_OPTIONS.map((role) => (
                          <SelectItem key={role.value} value={role.value}>
                            {role.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="px-6 py-4">
                    <Select
                      onValueChange={(value) =>
                        handleStatusChange(
                          user.UserID as string,
                          value as USER_STATUS
                        )
                      }
                      defaultValue={user.Status}
                    >
                      <SelectTrigger
                        disabled={!isSuperAdmin}
                        className="w-32 text-sm"
                      >
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        {USER_STATUS_OPTIONS.map((status) => (
                          <SelectItem key={status.value} value={status.value}>
                            {status.label}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </TableCell>
                  <TableCell className="text-center px-6 py-4">
                    {isSuperAdmin && (
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon">
                            <span className="text-gray-500">⋮</span>
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent>
                          <DropdownMenuItem
                            className="text-sm cursor-pointer"
                            onClick={() =>
                              handleDelete(user.UserID as string, user.FullName)
                            }
                          >
                            <div className="flex items-center">
                              <Trash2 className="mr-2 h-4 w-4 text-red-500" />
                              <span>Delete</span>
                            </div>
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        {users.meta?.totalUsers > 0 && (
          <div className="px-6 py-4 flex justify-between items-center">
            <div className="flex items-center">
              <span className="text-sm mr-2">Rows per page:</span>
              <Select
                onValueChange={(value) => handleRowsChange(Number(value))}
                defaultValue={rowsPerPage.toString()}
              >
                <SelectTrigger className="w-20 text-sm">
                  <SelectValue placeholder={rowsPerPage.toString()} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="20">20</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={handlePreviousPage}
                disabled={currentPage === 1}
                className="text-gray-500 disabled:text-gray-300"
                aria-label="Previous page"
              >
                <ChevronLeft />
              </button>
              <span className="text-sm">
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={handleNextPage}
                disabled={currentPage === totalPages}
                className="text-gray-500 disabled:text-gray-300"
                aria-label="Next page"
              >
                <ChevronRight />
              </button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
};

export default UserTable;
