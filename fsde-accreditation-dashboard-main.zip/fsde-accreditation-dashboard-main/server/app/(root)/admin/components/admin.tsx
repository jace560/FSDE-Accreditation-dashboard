"use client";

import React, { useEffect, useState } from "react";
import { ThresholdDialog } from "./admin-threshold-form";
import {
  USER_ROLE,
  type UsersReturnDto,
  type GetUsersQuery,
  type ROLE_TYPE,
  User,
} from "@/types/index";
import AdminDashboardFilter from "./admin-filter";
import { useCustomToast } from "@/hooks/custom/use-custom-toast";
import UserTable from "./admin-user-table";
import {
  useFetchThresholdsQuery,
  useGetUsersQuery,
  useUpdateThresholdsMutation,
} from "@/redux/api/admin";

const Admin = () => {
  const { showSuccessToast, showErrorToast } = useCustomToast();
  const { data: thresholdsData } = useFetchThresholdsQuery();
  const [updateThresholds] = useUpdateThresholdsMutation();

  const [filters, setFilters] = useState<GetUsersQuery>({
    nameSearchQuery: "",
    role: "",
    page: "",
    limit: "",
  });

  const [tempFilters, setTempFilters] = useState({
    nameSearchQuery: "",
    role: "",
    page: "",
    limit: "",
  });

  const resetFilters = () => {
    const resetState = {
      nameSearchQuery: "",
      role: "",
      page: "",
      limit: "",
    };
    setFilters(resetState);
    setTempFilters(resetState);
  };

  const { data: usersData, isLoading: isLoadingUsers } =
    useGetUsersQuery(filters);

  const [thresholds, setThresholds] = useState({
    exceed: 0,
    acceptable: 0,
    marginal: 0,
    fail: 0,
  });

  useEffect(() => {
    if (thresholdsData && thresholdsData.thresholds) {
      const formattedThresholds = thresholdsData.thresholds.reduce(
        (acc, { thresholdName, thresholdValue }) => {
          acc[thresholdName.toLowerCase() as keyof typeof acc] = thresholdValue;
          return acc;
        },
        { exceed: 0, acceptable: 0, marginal: 0, fail: 0 }
      );

      setThresholds(formattedThresholds);
    }
  }, [thresholdsData]);

  const applyFilters = () => {
    setFilters({ ...tempFilters });
    console.log("Applied Filters:", tempFilters);
  };

  const handleRowsPerPageChange = (rows: number) => {
    setFilters((prev) => ({ ...prev, limit: rows.toString(), page: "1" }));
  };

  const handlePageChange = (page: number) => {
    setFilters((prev) => ({ ...prev, page: page.toString() }));
  };

  const handleFilterChange = (name: string, value: string) => {
    setFilters((prevFilters) => ({
      ...prevFilters,
      [name]: value,
    }));
  };

  const handleEditUser = async (userId: string, updatedData: Partial<User>) => {
    showSuccessToast("User updated successfully");
  };

  const handleDeleteUser = async (userId: string, userName: string) => {
    showSuccessToast(`${userName} has been deleted`);
  };

  return (
    <div className="space-y-6 w-full">
      <div className="w-full sm:w-auto flex justify-start"></div>

      <div className="w-full sm:w-auto flex justify-end">
        <ThresholdDialog
          initialValues={thresholds}
          onSubmit={(thresholdRequest) => {
            updateThresholds(thresholdRequest);
            showSuccessToast("Thresholds updated successfully");
          }}
        />
      </div>

      <AdminDashboardFilter
        handleFilterChange={handleFilterChange}
        resetFilters={resetFilters}
        filters={filters}
        applyFilters={applyFilters}
      />

      <UserTable
        users={usersData as UsersReturnDto}
        isLoading={isLoadingUsers}
        handleRowsPerPageChange={handleRowsPerPageChange}
        handlePageChange={handlePageChange}
      />
    </div>
  );
};

export default Admin;
