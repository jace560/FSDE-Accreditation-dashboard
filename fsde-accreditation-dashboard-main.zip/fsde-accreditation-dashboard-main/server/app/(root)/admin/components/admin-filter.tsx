"use client";

import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import { Card, CardContent, CardHeader } from "@/app/components/ui/card";
import { Button } from "@/app/components/ui/button";
import { Filter } from "lucide-react";
import { Input } from "@/app/components/ui/input";
import {
  USER_ROLE,
  GetUsersQuery,
  ROLE_TYPE,
  USER_ROLE_OPTIONS,
} from "@/types";

interface AdminDashboardFilterProps {
  filters: GetUsersQuery;
  handleFilterChange: (name: string, value: ROLE_TYPE | string) => void;
  resetFilters: () => void;
  applyFilters: () => void;
}

const AdminDashboardFilter = ({
  filters,
  handleFilterChange,
  resetFilters,
  applyFilters,
}: AdminDashboardFilterProps) => {
  const isApplyEnabled =
    (filters.nameSearchQuery?.trim() !== "" &&
      filters.nameSearchQuery !== undefined) ||
    filters.role !== USER_ROLE.USER;

  return (
    <Card className="mb-6 border-gray-200 shadow-sm border rounded-sm">
      <CardHeader className="bg-gray-50 p-4 flex items-center justify-between rounded-t-lg">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-800">
          <Filter className="h-4 w-4 text-blue-600" />
          Filter Users
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          {/* Name Search Filter */}
          <div className="flex flex-col gap-2">
            <Input
              id="nameSearch"
              placeholder="Search by name or email..."
              value={filters.nameSearchQuery || ""}
              onChange={(e) =>
                handleFilterChange("nameSearchQuery", e.target.value)
              }
              className="w-full"
            />
          </div>

          {/* Role Filter */}
          <div className="flex flex-col gap-2">
            <Select
              value={filters.role}
              onValueChange={(value) =>
                handleFilterChange("role", value as ROLE_TYPE)
              }
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Filter by role" />
              </SelectTrigger>
              <SelectContent>
                {USER_ROLE_OPTIONS.map((role) => (
                  <SelectItem key={role.value} value={role.value}>
                    {role.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Reset and Apply Buttons */}
        <div className="flex justify-end gap-4 mt-6">
          <Button variant="outline" onClick={resetFilters}>
            Reset
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default AdminDashboardFilter;
