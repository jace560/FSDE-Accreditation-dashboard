"use client";

import { Button } from "@/app/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/app/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import { useState } from "react";
import type { User } from "@/types/index";
import { USER_ROLE } from "@/types/index";

interface EditDialogProps {
  isOpen: boolean;
  onClose: () => void;
  user: User | null;
  onSave: (userId: string, updatedData: Partial<User>) => void;
}

export function EditDialog({ isOpen, onClose, user, onSave }: EditDialogProps) {
  const [formData, setFormData] = useState<Partial<User>>({
    Role: user?.Role || "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (user?.UserID) {
      onSave(user.UserID, formData);
      onClose();
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Change User Role</DialogTitle>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-4 items-center gap-4">
              <label htmlFor="role" className="text-right font-medium">
                Role
              </label>
              <Select
                value={formData.Role}
                onValueChange={(value) => setFormData({ Role: value })}
              >
                <SelectTrigger className="col-span-3">
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value={USER_ROLE.USER}>User</SelectItem>
                  <SelectItem value={USER_ROLE.ADMIN}>Admin</SelectItem>
                  <SelectItem value={USER_ROLE.SUPER_ADMIN}>
                    Super Admin
                  </SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button type="submit">Save changes</Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
