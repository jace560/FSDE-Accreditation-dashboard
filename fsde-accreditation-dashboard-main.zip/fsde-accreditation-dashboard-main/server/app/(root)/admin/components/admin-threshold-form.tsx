"use client";

import * as React from "react";
import { Plus } from "lucide-react";

// Radix UI components
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
  DialogClose,
} from "../../../components/ui/dialog";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Label } from "../../../components/ui/label";
import {
  useFetchThresholdsQuery,
  useUpdateThresholdsMutation,
} from "@/redux/api/admin";
import { useAuth } from "@/hooks/custom/use-auth";
import { useCustomToast } from "@/hooks/custom/use-custom-toast";

export type ThresholdNameType = "Exceed" | "Acceptable" | "Marginal" | "Fail";

export type Threshold = {
  thresholdName: ThresholdNameType;
  thresholdValue: number;
};

export type ThresholdUpdateRequest = {
  thresholds: Threshold[];
};

interface ThresholdValues {
  exceed: number;
  acceptable: number;
  marginal: number;
  fail: number;
}

interface ThresholdDialogProps {
  dialogTitle?: string;
  dialogDescription?: string;
  initialValues?: ThresholdValues;
  onSubmit?: (data: ThresholdUpdateRequest) => void;
}

export function ThresholdDialog({
  dialogTitle = "Set Thresholds",
  dialogDescription = "Set values for each threshold level.",
  initialValues = {
    exceed: 0,
    acceptable: 0,
    marginal: 0,
    fail: 0,
  },
  onSubmit,
}: ThresholdDialogProps) {
  const { data: thresholds, isLoading } = useFetchThresholdsQuery();
  const [updateThresholds, { isLoading: isUpdating }] =
    useUpdateThresholdsMutation();

  const { showSuccessToast, showErrorToast } = useCustomToast();
  const [open, setOpen] = React.useState(false);
  const [values, setValues] = React.useState<ThresholdValues>({
    exceed: 0,
    acceptable: 0,
    marginal: 0,
    fail: 0,
  });

  React.useEffect(() => {
    if (thresholds) {
      const newValues: any = {};
      thresholds.thresholds.forEach(({ thresholdName, thresholdValue }) => {
        newValues[thresholdName.toLowerCase()] = thresholdValue;
      });
      setValues(newValues);
    }
  }, [thresholds]);

  const handleValueChange = (type: keyof ThresholdValues, newValue: string) => {
    setValues((prev) => ({
      ...prev,
      [type]: Number(newValue),
    }));
  };

  // Validate that thresholds are in correct order
  const isValidThresholds = () => {
    return (
      values.exceed > values.acceptable &&
      values.acceptable > values.marginal &&
      values.marginal >= values.fail
    );
  };

  function handleSubmit(e: React.FormEvent) {
    e.preventDefault();
    if (!isValidThresholds()) {
      alert(
        "Threshold values must be in descending order: Exceed > Acceptable > Marginal >= Fail"
      );
      return;
    }
    updateThresholds({
      thresholds: [
        { thresholdName: "Exceed", thresholdValue: values.exceed },
        { thresholdName: "Acceptable", thresholdValue: values.acceptable },
        { thresholdName: "Marginal", thresholdValue: values.marginal },
        { thresholdName: "Fail", thresholdValue: values.fail },
      ],
    }).then(() => {
      showSuccessToast("Thresholds have been saved successfully.");
      setOpen(false);
    })
    .catch(() => {
      showErrorToast("Something went wrong. Please try again.");
    });
  }

  const { isAdmin } = useAuth();
  if (!isAdmin) {
    return <></>;
  }

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          variant="default"
          className="flex  justify-end bg-blue-600 hover:bg-blue-700  px-6 py-6 font-bold text-white cursor-pointer"
        >
          <Plus className="mr-2 h-4 w-4" />
          Set Thresholds
        </Button>
      </DialogTrigger>

      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="text-xl">{dialogTitle}</DialogTitle>
          <DialogDescription className="text-sm text-gray-500">
            {dialogDescription}
          </DialogDescription>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-6 py-4">
          <div className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="exceed" className="">
                Exceed Threshold
              </Label>
              <Input
                id="exceed"
                type="number"
                value={values.exceed}
                onChange={(e) => handleValueChange("exceed", e.target.value)}
                placeholder=""
                className="w-full"
                min={values.acceptable ? values.acceptable + 1 : 0}
                max={100}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="acceptable" className="">
                Acceptable Threshold
              </Label>
              <Input
                id="acceptable"
                type="number"
                value={values.acceptable}
                onChange={(e) =>
                  handleValueChange("acceptable", e.target.value)
                }
                placeholder=""
                className="w-full"
                min={values.marginal ? values.marginal + 1 : 0}
                max={values.exceed ? values.exceed - 1 : 99}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="marginal" className="">
                Marginal Threshold
              </Label>
              <Input
                id="marginal"
                type="number"
                value={values.marginal}
                onChange={(e) => handleValueChange("marginal", e.target.value)}
                placeholder=""
                className="w-full"
                min={values.fail ?? 0}
                max={values.acceptable ? values.acceptable - 1 : 99}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="fail" className="">
                Fail Threshold
              </Label>
              <Input
                id="fail"
                type="number"
                value={values.fail}
                onChange={(e) => handleValueChange("fail", e.target.value)}
                placeholder=""
                className="w-full"
                min={0}
                max={values.marginal ?? 99}
              />
            </div>
          </div>
          <DialogFooter className="gap-2">
            <Button
              variant="default"
              type="submit"
              className="bg-blue-600 hover:bg-blue-700 text-white"
              disabled={!isValidThresholds()}
            >
              Save Thresholds
            </Button>
            <DialogClose asChild>
              <Button variant="outline">Cancel</Button>
            </DialogClose>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
export default ThresholdDialog;
