import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import { SidebarProvider, SidebarTrigger } from "../components/ui/sidebar";
import { AppSidebar } from "../components/app-sidebar";
import { Header } from "../components/app-header";
import ReduxProvider from "../components/redux-provider";
import { Toaster } from "../components/ui/toaster";
import { Suspense } from "react";
import Loader from "../components/loader";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

// export const metadata: Metadata = {
//   title: {
//     template: "%s | Curriculum Accreditation Dashboard",
//     default: "Curriculum Accreditation Dashboard",
//   },
// };

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <ReduxProvider>
      <SidebarProvider>
        <Suspense
          fallback={
            <div className="flex items-center justify-center h-screen w-full">
              <Loader message="Loading App ..." />
            </div>
          }
        >
          <div className="flex h-screen w-full overflow-hidden">
            <AppSidebar />
            <div className="flex-1 flex flex-col overflow-hidden">
              <Header />
              <main className="flex-1 overflow-y-auto p-8">{children}</main>
              <Toaster />
            </div>
          </div>
        </Suspense>
      </SidebarProvider>
    </ReduxProvider>
  );
}
