"use client";
import {
  Select,
  SelectItem,
  SelectTrigger,
  SelectContent,
  SelectGroup,
  SelectValue,
} from "../../../components/ui/select";
import { Card, CardContent, CardHeader } from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import { Filter } from "lucide-react";
import { useEffect } from "react";
import { ChartType, SelectType } from "@/types";

const DashboardFilter = ({
  graduateAttributes,
  programs,
  campuses,
  years,
  filters,
  handleFilterChange,
  resetFilters,
  applyFilters,
  chartTypes,
}: {
  graduateAttributes: SelectType[];
  programs: { ProgramID: string; ProgramName: string }[];
  campuses: { CampusID: string; CampusName: string }[];
  years: string[];
  chartTypes: { value: string; label: string }[];
  filters: {
    chartType: string;
    graduateAttribute: string;
    programId: string;
    campusId: string;
    year: string;
  };
  handleFilterChange: (name: string, value: string) => void;
  resetFilters: () => void;
  applyFilters: () => void;
}) => {
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  const isChartTypeSelected = !!filters.chartType;
  const isGAByCourseAndIda = filters.chartType === "GA_BY_COURSE_AND_IDA";
  const isGraduateAttributeSelected = !!filters.graduateAttribute;
  const isProgramSelected = !!filters.programId;
  const isCampusSelected = !!filters.campusId;
  const isYearSelected = !!filters.year;
  const isApplyEnabled =
    isProgramSelected && isCampusSelected && isYearSelected;

  return (
    <Card className="mb-6 border-gray-200 shadow-sm border rounded-sm">
      <CardHeader className="bg-gray-50 p-4 flex items-center justify-between rounded-t-lg">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-800">
          <Filter className="h-4 w-4 text-blue-600" />
          Filter Dashboard
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Chart Type Filter (Always Enabled) */}
          <Select
            value={filters.chartType}
            onValueChange={(value) => handleFilterChange("chartType", value)}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Chart Type" />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                {chartTypes.map((chart) => (
                  <SelectItem key={chart.value} value={chart.value}>
                    {chart.label}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>

          {/* Graduate Attribute Filter (Appears if chartType is GA_BY_COURSE_AND_IDA) */}
          {isGAByCourseAndIda && (
            <Select
              value={filters.graduateAttribute}
              onValueChange={(value) =>
                handleFilterChange("graduateAttribute", value)
              }
              disabled={!isChartTypeSelected}
            >
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Graduate Attribute" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {graduateAttributes.map((attr) => (
                    <SelectItem key={attr.value} value={attr.value}>
                      {attr.label}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          )}

          {/* Program Filter (Disabled until Chart Type is selected) */}
          <Select
            value={filters.programId}
            onValueChange={(value) => handleFilterChange("programId", value)}
            disabled={
              !isChartTypeSelected ||
              (isGAByCourseAndIda && !isGraduateAttributeSelected)
            }
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Program" />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                {programs.map((program) => (
                  <SelectItem key={program.ProgramID} value={program.ProgramID}>
                    {program.ProgramName}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>

          {/* Campus Filter (Disabled until Program is selected) */}
          <Select
            value={filters.campusId}
            onValueChange={(value) => handleFilterChange("campusId", value)}
            disabled={!isProgramSelected}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Campus" />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                {campuses.map((campus) => (
                  <SelectItem key={campus.CampusID} value={campus.CampusID}>
                    {campus.CampusName}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>

          {/* Year Filter (Disabled until Campus is selected) */}
          <Select
            value={filters.year}
            onValueChange={(value) => handleFilterChange("year", value)}
            disabled={!isCampusSelected}
          >
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Year" />
            </SelectTrigger>
            <SelectContent>
              <SelectGroup>
                {years.map((year) => (
                  <SelectItem key={year} value={year}>
                    {year}
                  </SelectItem>
                ))}
              </SelectGroup>
            </SelectContent>
          </Select>
        </div>

        {/* Reset and Apply Buttons */}
        <div className="flex justify-end gap-4 mt-6">
          <Button variant="outline" onClick={resetFilters}>
            Reset
          </Button>
          <Button
            className="bg-blue-600 text-white"
            onClick={applyFilters}
            disabled={
              !isApplyEnabled || filters.chartType === ChartType.EXCEL_SHEET
            }
          >
            Apply
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default DashboardFilter;
