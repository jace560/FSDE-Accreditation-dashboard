import React, { useRef, useState } from "react";
import {
  BarChart,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  Bar,
  ResponsiveContainer,
  LabelList,
  TooltipProps,
} from "recharts";
import {
  BY_GA_BY_COURSE_LEVEL,
  BY_GA_BY_IDA_LEVEL,
  Chart,
  ChartDataReturnDto,
  ChartDataType,
  ChartType,
  COURSE_LEVEL_BY_GA_LO_DISTRIBUTION,
  GA_LO_Distribution,
  GAChartData,
  IDA_LEVEL_COMBINING_ALL_GA,
} from "@/types";
import Loader from "@/app/components/loader";
import { Card, CardHeader } from "@/app/components/ui/card";
import { Info } from "lucide-react";
import { AlertDescription, AlertTitle } from "@/app/components/ui/alert";
import { Button } from "@/app/components/ui/button";
import * as htmlToImage from "html-to-image";
import { count } from "console";
import { colors } from "@/utils";

interface DashboardChartProps {
  data: ChartDataReturnDto | undefined;
  isLoading: boolean;
}

const transformChartData = (data: ChartDataType, chartType: ChartType) => {
  switch (chartType) {
    case ChartType.GA_BY_COURSE_LEVEL:
      return (data as GAChartData[]).map((ga) => ({
        GA: ga.graduateAttribute,
        ...Object.fromEntries(ga.values.map((v) => [v.label, v.count])),
      }));

    case ChartType.GA_BY_IDA:
      return (data as GAChartData[]).map((ga) => ({
        GA: ga.graduateAttribute,
        I: ga.values.find((v) => v.label === "I")?.count || 0,
        D: ga.values.find((v) => v.label === "D")?.count || 0,
        A: ga.values.find((v) => v.label === "A")?.count || 0,
      }));
    case ChartType.GA_BY_COURSE_AND_IDA:
      return (data as GA_LO_Distribution).courses.map((course) => {
        const performance = course.performance;
        const total = performance.reduce((sum, p) => sum + p.percentage, 0);
        let roundedPerformance = performance.map((p) => ({
          category: p.category,
          value: Math.round((p.percentage / total) * 100),
        }));
        let roundedTotal = roundedPerformance.reduce(
          (sum, p) => sum + p.value,
          0
        );
        let difference = 100 - roundedTotal;

        if (difference !== 0) {
          roundedPerformance.sort((a, b) => b.value - a.value);
          roundedPerformance[0].value += difference;
        }
        return {
          Course: course.courseCode,
          ...Object.fromEntries(
            roundedPerformance.map((p) => [p.category, p.value])
          ),
        };
      });

    case ChartType.IDA_LEVEL_COMBINING_ALL_GA:
      return (data as IDA_LEVEL_COMBINING_ALL_GA[]).map(
        ({ IDALevel, Exceeds, Marginal, Acceptable, Fail }) => {
          const total = Exceeds + Acceptable + Marginal + Fail;

          // Compute proportional percentages
          let exceedsPct = Math.round((Exceeds / total) * 100);
          let acceptablePct = Math.round((Acceptable / total) * 100);
          let marginalPct = Math.round((Marginal / total) * 100);
          let failPct = Math.round((Fail / total) * 100);

          // Adjust to ensure total is exactly 100%
          let roundedTotal = exceedsPct + acceptablePct + marginalPct + failPct;
          let difference = 100 - roundedTotal;

          let adjustments = [
            { key: "Exceeds", value: exceedsPct },
            { key: "Acceptable", value: acceptablePct },
            { key: "Marginal", value: marginalPct },
            { key: "Fail", value: failPct },
          ];
          adjustments.sort((a, b) => b.value - a.value);
          adjustments[0].value += difference;
          console.log(
            "📊 Transformed Data for IDA_LEVEL_COMBINING_ALL_GA:",
            data
          );

          console.log(IDALevel, "IDALevel");
          const IDALabels = ["I", "D", "A"];
          return {
            IDA_Level: IDALabels[Number(IDALevel)] ?? IDALevel,
            Exceeds: adjustments.find((x) => x.key === "Exceeds")!.value || 0,
            Acceptable:
              adjustments.find((x) => x.key === "Acceptable")!.value || 0,
            Marginal: adjustments.find((x) => x.key === "Marginal")!.value || 0,
            Fail: adjustments.find((x) => x.key === "Fail")!.value || 0,
          };
        }
      );

    case ChartType.COURSE_LEVEL_COMBINING_ALL_GA:
      return (data as COURSE_LEVEL_BY_GA_LO_DISTRIBUTION[]).map(
        ({ CourseLevel, Exceeds, Marginal, Acceptable, Fail }) => {
          const total = Exceeds + Acceptable + Marginal + Fail;
          let roundedExceeds = Math.round((Exceeds / total) * 100);
          let roundedAcceptable = Math.round((Acceptable / total) * 100);
          let roundedMarginal = Math.round((Marginal / total) * 100);
          let roundedFail = Math.round((Fail / total) * 100);
          let roundedTotal =
            roundedExceeds + roundedAcceptable + roundedMarginal + roundedFail;
          let difference = 100 - roundedTotal;
          let adjustments = [
            { key: "Exceeds", value: roundedExceeds },
            { key: "Acceptable", value: roundedAcceptable },
            { key: "Marginal", value: roundedMarginal },
            { key: "Fail", value: roundedFail },
          ];

          adjustments.sort((a, b) => b.value - a.value);
          adjustments[0].value += difference;

          return {
            "Course Level": CourseLevel,
            Exceeds: adjustments.find((x) => x.key === "Exceeds")!.value || 0,
            Acceptable:
              adjustments.find((x) => x.key === "Acceptable")!.value || 0,
            Marginal: adjustments.find((x) => x.key === "Marginal")!.value || 0,
            Fail: adjustments.find((x) => x.key === "Fail")!.value || 0,
          };
        }
      );
    case ChartType.IDA_LEVEL_COMBINING_ALL_GA:
      return (data as IDA_LEVEL_COMBINING_ALL_GA[]).map(
        ({ IDALevel, Exceeds, Marginal, Acceptable, Fail }) => {
          const total = Exceeds + Acceptable + Marginal + Fail;

          let exceedsPct = Math.round((Exceeds / total) * 100);
          let acceptablePct = Math.round((Acceptable / total) * 100);
          let marginalPct = Math.round((Marginal / total) * 100);
          let failPct = Math.round((Fail / total) * 100);

          let roundedTotal = exceedsPct + acceptablePct + marginalPct + failPct;
          let difference = 100 - roundedTotal;

          let adjustments = [
            { key: "Exceeds", value: exceedsPct },
            { key: "Acceptable", value: acceptablePct },
            { key: "Marginal", value: marginalPct },
            { key: "Fail", value: failPct },
          ];
          adjustments.sort((a, b) => b.value - a.value);
          adjustments[0].value += difference;

          return {
            IDA_Level: IDALevel,
            Exceeds: adjustments.find((x) => x.key === "Exceeds")!.value || 0,
            Acceptable:
              adjustments.find((x) => x.key === "Acceptable")!.value || 0,
            Marginal: adjustments.find((x) => x.key === "Marginal")!.value || 0,
            Fail: adjustments.find((x) => x.key === "Fail")!.value || 0,
          };
        }
      );
    case ChartType.BY_GA_AND_BY_COURSE_LEVEL:
      return (data as BY_GA_BY_COURSE_LEVEL[]).flatMap(
        ({ gaName, courseLevelPerformance }) => {
          return {
            gaName,
            ...courseLevelPerformance.reduce((acc, level) => {
              const rawValues = {
                Exceeds: level.Exceeds,
                Fail: level.Fail,
                Marginal: level.Marginal,
                Acceptable: level.Acceptable,
              };

              const rawTotal =
                rawValues.Exceeds +
                rawValues.Fail +
                rawValues.Marginal +
                rawValues.Acceptable;

              let roundedValues: {
                Exceeds: number;
                Fail: number;
                Marginal: number;
                Acceptable: number;
              };

              if (rawTotal === 0) {
                roundedValues = {
                  Exceeds: 0,
                  Fail: 0,
                  Marginal: 0,
                  Acceptable: 0,
                };
              } else {
                roundedValues = {
                  Exceeds: Math.round(rawValues.Exceeds),
                  Fail: Math.round(rawValues.Fail),
                  Marginal: Math.round(rawValues.Marginal),
                  Acceptable: Math.round(rawValues.Acceptable),
                };

                let total =
                  roundedValues.Exceeds +
                  roundedValues.Fail +
                  roundedValues.Marginal +
                  roundedValues.Acceptable;

                const difference = 100 - total;
                if (difference !== 0) {
                  const sortedKeys = Object.keys(roundedValues).sort(
                    (a, b) =>
                      (rawValues[b as keyof typeof rawValues] % 1) -
                      (rawValues[a as keyof typeof rawValues] % 1)
                  );

                  roundedValues[sortedKeys[0] as keyof typeof roundedValues] +=
                    difference;
                }
              }

              acc[level.CourseLevel] = roundedValues;
              return acc;
            }, {} as Record<string, { Exceeds: number; Fail: number; Marginal: number; Acceptable: number }>),
          };
        }
      );

    case ChartType.BY_GA_AND_BY_IDA_LEVEL:
      return (data as BY_GA_BY_IDA_LEVEL[]).flatMap(
        ({ gaName, IDALevelPerformance }) => {
          return {
            gaName,
            ...IDALevelPerformance.reduce((acc, level) => {
              const rawValues = {
                Exceeds: level.Exceeds,
                Fail: level.Fail,
                Marginal: level.Marginal,
                Acceptable: level.Acceptable,
              };

              const rawTotal =
                rawValues.Exceeds +
                rawValues.Fail +
                rawValues.Marginal +
                rawValues.Acceptable;

              let roundedValues: {
                Exceeds: number;
                Fail: number;
                Marginal: number;
                Acceptable: number;
              };

              if (rawTotal === 0) {
                roundedValues = {
                  Exceeds: 0,
                  Fail: 0,
                  Marginal: 0,
                  Acceptable: 0,
                };
              } else {
                roundedValues = {
                  Exceeds: Math.round(rawValues.Exceeds),
                  Fail: Math.round(rawValues.Fail),
                  Marginal: Math.round(rawValues.Marginal),
                  Acceptable: Math.round(rawValues.Acceptable),
                };

                let total =
                  roundedValues.Exceeds +
                  roundedValues.Fail +
                  roundedValues.Marginal +
                  roundedValues.Acceptable;

                const difference = 100 - total;
                if (difference !== 0) {
                  const sortedKeys = Object.keys(roundedValues).sort(
                    (a, b) =>
                      (rawValues[b as keyof typeof rawValues] % 1) -
                      (rawValues[a as keyof typeof rawValues] % 1)
                  );

                  roundedValues[sortedKeys[0] as keyof typeof roundedValues] +=
                    difference;
                }
              }

              acc[level.IDALevel] = roundedValues;
              return acc;
            }, {} as Record<string, { Exceeds: number; Fail: number; Marginal: number; Acceptable: number }>),
          };
        }
      );

    default:
      return [];
  }
};

const DashboardChart: React.FC<DashboardChartProps> = ({ data, isLoading }) => {
  const chartRef = useRef<HTMLDivElement>(null);
  const [hideExportButton, setHideExportButton] = useState(false);

  if (isLoading) {
    return <Loader message="Loading Chart Data...." />;
  }

  if (!data) {
    return (
      <Card className="border border-yellow-400 rounded-xl shadow-md mb-6 p-6 bg-yellow-50 animate-fade-in">
        <div className="flex flex-col sm:flex-row items-center gap-4">
          <Info className="h-6 w-6 text-yellow-600 flex-shrink-0" />
          <div className="flex-1">
            <h3 className="text-yellow-800 font-semibold text-lg">
              Warning: No Data Available
            </h3>
            <p className="text-yellow-700 text-sm">
              Try adjusting the filters to view data.
            </p>
          </div>
        </div>
      </Card>
    );
  }

  
  const chartData = transformChartData(data?.data, data?.type);

  const handleExport = async () => {
    setHideExportButton(true); // 👈 hide button before capture
  
    setTimeout(async () => {
      if (chartRef.current) {
        try {
          const dataUrl = await htmlToImage.toPng(chartRef.current);
          const link = document.createElement("a");
          link.href = dataUrl;
          link.download = `${data.labels.mainTitle}.png`;
          link.click();
        } catch (error) {
          console.error("Failed to export the chart as an image:", error);
        } finally {
          setHideExportButton(false); // 👈 show button again
        }
      }
    }, 100); // small delay to ensure button is hidden
  };  

  let labelsWithColors: { label: string; color: string }[] = [];

  if (
    data.type === ChartType.GA_BY_COURSE_LEVEL ||
    data.type === ChartType.GA_BY_IDA
  ) {
    const gaChartData = data.data as GAChartData[];
    labelsWithColors =
      gaChartData[0]?.values.map(({ label, color }) => ({ label, color })) ||
      [];
  } else if (data.type === ChartType.GA_BY_COURSE_AND_IDA) {
    const gaLoData = data.data as GA_LO_Distribution;
    labelsWithColors = Object.entries(gaLoData.colors).map(
      ([label, color]) => ({
        label,
        color,
      })
    );
  } else {
    const chartColor = data?.color;
    labelsWithColors = Object.entries(chartColor ?? {}).map(
      ([label, color]) => ({
        label,
        color,
      })
    );
  }

  return (
    <div ref={chartRef}>
      <Card className="border border-gray-200 rounded-md shadow-sm mb-6">
        <CardHeader className="bg-gray-50 p-4 flex items-center justify-between rounded-t-lg">
          <h3 className="text-sm font-bold text-gray-800">
            {data.labels.mainTitle}
          </h3>
        </CardHeader>
        <div ref={chartRef} className="bg-white">
          {data.type === ChartType.BY_GA_AND_BY_IDA_LEVEL ||
          data.type == ChartType.BY_GA_AND_BY_COURSE_LEVEL ? (
            <CourseGaCourseLevelChart
              chartData={chartData}
              colors={colors}
              data={data}
              type={data.type}
            />
          ) : (
            <DefaultChart
              chartData={chartData}
              labelsWithColors={labelsWithColors}
              data={data}
            />
          )}
        </div>

        {!hideExportButton && (
          <div className="flex justify-end m-4">
            <Button
              onClick={handleExport}
              className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2"
            >
              Export as PNG
            </Button>
          </div>
        )}
      </Card>
    </div>
  );
};

export default DashboardChart;

const CustomTooltip: React.FC<TooltipProps<number, string>> = ({
  active,
  payload,
  label,
}) => {
  if (!active || !payload || payload.length === 0) return null;

  const groupedData: Record<string, Record<string, number>> = {};

  payload.forEach((entry) => {
    const [level, category] = (entry.name as string).split(" - ");
    if (!groupedData[level]) groupedData[level] = {};
    groupedData[level][category] = entry.value as number;
  });

  return (
    <div className="bg-white shadow-sm rounded-md p-4 border border-gray-300 text-black text-sm">
      <h3 className="font-bold text-xs border-gray-200 mb-2">{label}</h3>
      {Object.keys(groupedData).map((level) => (
        <div key={level} className="mt-2">
          <h4 className="font-semibold text-xs text-gray-800">{level}</h4>
          <ul className="space-y-1">
            {["Fail", "Marginal", "Acceptable", "Exceeds"].map((category) =>
              groupedData[level][category] !== undefined ? (
                <li
                  key={`${level}-${category}`}
                  className="text-gray-700 text-xs"
                >
                  <span className="text-xs">{category}:</span>{" "}
                  {groupedData[level][category]}
                </li>
              ) : null
            )}
          </ul>
        </div>
      ))}
    </div>
  );
};

interface DefaultChartProps {
  chartData: any[];
  labelsWithColors: { label: string; color: string }[];
  data: {
    type: string;
    labels: {
      xAxisLabel: string;
      yAxisLabel: string;
    };
  };
}

const DefaultChart: React.FC<DefaultChartProps> = ({
  chartData,
  labelsWithColors,
  data,
}) => {
  return (
    <ResponsiveContainer width="100%" height={500}>
      <BarChart
        data={chartData}
        margin={{ top: 50, right: 30, left: 20, bottom: 60 }}
      >
        <XAxis
          dataKey={
            data.type === "GA_BY_COURSE_AND_IDA"
              ? "Course"
              : data.type === "GA_BY_IDA" ||
                data.type === "GA_BY_COURSE_LEVEL" ||
                data.type === "BY_GA_AND_BY_IDA_LEVEL"
              ? "GA"
              : data.type === "COURSE_LEVEL_COMBINING_ALL_GA"
              ? "Course Level"
              : data.type === "IDA_LEVEL_COMBINING_ALL_GA"
              ? "IDA_Level"
              : ""
          }
          label={{
            value: data.labels.xAxisLabel,
            position: "insideBottom",
            dy: 20,
          }}
          tick={{ fontSize: 12 }}
        />
        <YAxis
          label={{
            value: data.labels.yAxisLabel,
            angle: -90,
            position: "insideLeft",
            dx: -10,
          }}
          tick={{ fontSize: 12 }}
        />
        <Tooltip
          content={({ payload, label }) => {
            if (!payload || payload.length === 0) return null;
            return (
              <div className="bg-white p-2 border rounded shadow">
                <p className="mb-1">{label}</p>
                {[...payload].reverse().map((entry, index) => (
                  <p
                    key={index}
                    className="mb-1"
                    style={{ color: entry.color }}
                  >
                    {entry.name}: {entry.value}
                  </p>
                ))}
              </div>
            );
          }}
        />
        <Legend
          height={36}
          verticalAlign="top"
          align="center"
          wrapperStyle={{ marginBottom: 20 }}
        />
        {[...labelsWithColors].map(({ label, color }) => (
          <Bar key={label} dataKey={label} stackId="a" fill={color}>
            {[
              "Exceeds",
              "Acceptable",
              "1000",
              "2000",
              "3000",
              "4000",
              "I",
              "D",
              "A",
            ].includes(label) && (
              <LabelList
                dataKey={label}
                position="middle"
                fill="black"
                fontSize={14}
                fontWeight="bold"
              />
            )}
          </Bar>
        ))}
      </BarChart>
    </ResponsiveContainer>
  );
};

interface CourseGaCourseLevelChartProps {
  chartData: any[];
  colors: Record<string, string>;
  type: ChartType.BY_GA_AND_BY_COURSE_LEVEL | ChartType.BY_GA_AND_BY_IDA_LEVEL;
  data: {
    labels: {
      xAxisLabel: string;
      yAxisLabel: string;
    };
  };
}

const CourseGaCourseLevelChart: React.FC<CourseGaCourseLevelChartProps> = ({
  chartData,
  colors,
  data,
  type,
}) => {
  return (
    <ResponsiveContainer width="100%" height={500}>
      <BarChart
        data={chartData}
        margin={{ top: 50, right: 30, left: 20, bottom: 60 }}
      >
        <XAxis
          dataKey="gaName"
          label={{
            value: data.labels.xAxisLabel,
            position: "insideBottom",
            dy: 50,
          }}
          tick={{ fontSize: 12 }}
        />
        <YAxis
          label={{
            value: data.labels.yAxisLabel,
            angle: -90,
            position: "insideLeft",
            dx: -10,
          }}
          tick={{ fontSize: 12 }}
          domain={[100, 0]}
        />
        <Tooltip content={<CustomTooltip />} />
        <Legend
          payload={Object.keys(colors).map((key) => ({
            id: key,
            value: key,
            type: "rect",
            color: colors[key],
          }))}
        />
        {(type == ChartType.BY_GA_AND_BY_COURSE_LEVEL
          ? ["1000", "2000", "3000", "4000"]
          : ChartType.BY_GA_AND_BY_IDA_LEVEL
          ? ["I", "D", "A"]
          : []
        ).map((level) =>
          ["Exceeds", "Acceptable", "Marginal", "Fail"].map((category) => (
            <Bar
              key={`${level}_${category}`}
              dataKey={`${level}.${category}`}
              stackId={level}
              fill={colors[category]}
              name={`${level} - ${category}`}
            >
              {["Exceeds", "Acceptable"].includes(category) && (
                <LabelList
                  dataKey={`${level}.${category}`}
                  position="middle"
                  fill="black"
                  fontSize={14}
                  fontWeight="bold"
                />
              )}
              {category === "Exceeds" && (
                <LabelList
                  dataKey={`${level}.${category}`}
                  position="top"
                  fill="black"
                  fontSize={10}
                  dy={-20}
                  angle={type == ChartType.BY_GA_AND_BY_COURSE_LEVEL ? -90 : 0}
                  formatter={() => level}
                />
              )}
            </Bar>
          ))
        )}
      </BarChart>
    </ResponsiveContainer>
  );
};
