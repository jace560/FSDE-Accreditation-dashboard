"use client";

import React, { useEffect, useState } from "react";
import DashboardFilter from "./dashboard-filter";
import { useGetChartDataQuery } from "@/redux/api/charts";
import { ChartQueryParams, ChartTypesLabel, Chart, SelectType } from "@/types";
import DashboardChart from "./dashboard-chart";
import DashboardChartExcelOptions from "./dashboard-chart-excel-options";
import { useCustomToast } from "@/hooks/custom/use-custom-toast";
import { usePathname, useRouter, useSearchParams } from "next/navigation";
import { useAuth } from "@/hooks/custom/use-auth";
import { useGetCourseYearsQuery } from "@/redux/api/courses";
import Loader from "@/app/components/loader";

interface Campus {
  CampusID: string;
  CampusName: string;
}

interface Program {
  ProgramID: string;
  ProgramName: string;
  Campuses: { Campus: Campus }[];
}

interface DashboardProps {
  programs: Program[];
  uniqueYears: string[];
  graduateAttributes: SelectType[];
}

const Dashboard: React.FC<DashboardProps> = ({
  programs,
  uniqueYears,
  graduateAttributes,
}) => {
  const [filters, setFilters] = useState<ChartQueryParams>({
    programId: "",
    campusId: "",
    year: "",
    chartType: "",
    graduateAttribute: "",
  });

  const [tempFilters, setTempFilters] = useState({
    programId: "",
    campusId: "",
    year: "",
    chartType: "",
    graduateAttribute: "",
  });

  const {
    data: chartData,
    isLoading,
    isFetching,
    isSuccess,
    isError,
    error,
  } = useGetChartDataQuery(filters, {
    skip: !filters.programId || !filters.campusId,
  });
  const [chartDataJson, setChartData] = useState<Chart | undefined>(
    chartData?.data as Chart
  );
  const { showSuccessToast, showErrorToast } = useCustomToast();
  const { session } = useAuth();

  useEffect(() => {
    if (isError) {
      showWarningToast(
        // @ts-ignore
        error?.data.error.message || "Failed to fetch data. Please try again."
      );
      setChartData(undefined);
    }
  }, [isSuccess, isError, error]);

  const campuses = programs.flatMap((program) =>
    program.Campuses.map((data) => ({
      CampusID: data.Campus.CampusID,
      CampusName: data.Campus.CampusName,
    }))
  );

  const handleFilterChange = (name: string, value: string) => {
    setTempFilters((prev) => ({ ...prev, [name]: value }));
    console.log(`Filter changed: ${name} = ${value}`);
  };

  const applyFilters = () => {
    setFilters({ ...tempFilters });
    console.log("Applied Filters:", tempFilters);
  };
  const { showWarningToast } = useCustomToast();
  const [message, setMessage] = useState<string | null>(null);
  const pathname = usePathname();
  const router = useRouter();
  const searchParams = useSearchParams();
  const {
    data: years,
    isLoading: isFetchYearsLoading,
    isFetching: isFetchingYears,
    isSuccess: isFetchingYearsSuccesssful,
  } = useGetCourseYearsQuery();
  const [uniqueCourseYears, setUniqueYears] = useState<string[]>(uniqueYears);

  useEffect(() => {
    if (chartData) {
      setChartData(chartData?.data as Chart);
    }
  }, [chartData]);

  const resetFilters = () => {
    const resetState = {
      programId: "",
      campusId: "",
      year: "",
      chartType: "",
      graduateAttribute: "",
    };
    setFilters(resetState);
    setTempFilters(resetState);
    setChartData(undefined);
    console.log("Filters Reset");
  };

  console.log(years, "YEARS");

  useEffect(() => {
    // ✅ Read the message from the URL (works even on manual typing)
    const urlParams = new URLSearchParams(window.location.search);
    const messageParam = urlParams.get("message");

    if (messageParam) {
      setMessage(messageParam);
    }
  }, [searchParams]);

  useEffect(() => {
    if (!message) return;

    if (message === "unauthorized") {
      showWarningToast("You are not authorized to access this page.");
    }

    const newUrl = pathname;
    // @ts-ignore
    router.replace(newUrl, undefined, { scroll: false });

    setMessage(null); // Prevent future re-renders
  }, [message, pathname, router, showWarningToast]);

  useEffect(() => {
    if (years?.years) {
      setUniqueYears(years.years);
    }
  }, [isFetchingYears, years, isFetchYearsLoading, isFetchingYearsSuccesssful]);

  return (
    <div className="space-y-6 w-full">
      <DashboardChartExcelOptions filters={tempFilters} />
      <DashboardFilter
        programs={programs}
        campuses={campuses}
        years={uniqueCourseYears}
        filters={tempFilters}
        handleFilterChange={handleFilterChange}
        resetFilters={resetFilters}
        applyFilters={applyFilters}
        chartTypes={ChartTypesLabel}
        graduateAttributes={graduateAttributes}
      />
      <DashboardChart
        isLoading={isLoading || isFetching}
        data={chartDataJson}
      />
    </div>
  );
};

export default Dashboard;
