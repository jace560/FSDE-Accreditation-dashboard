import React, { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/app/components/ui/dropdown-menu";
import { MoreVertical } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import { cn } from "@/lib/utils";
import { ChartType } from "@/types";

const CHART_OPTIONS = [
  { label: "GA Course PI Mapping", value: "GA_COURSE_PI_MAPPING" },
];

const DashboardChartExcelOptions = ({
  filters,
}: {
  filters: {
    chartType: string;
    programId: string;
    campusId: string;
    year: string;
  };
}) => {
  const [selectedChart, setSelectedChart] = useState<string | null>(null);

  const handleSelectChart = async (chartType: string) => {
    setSelectedChart(chartType);

    if (!filters.programId || !filters.campusId || !filters.year) {
      console.error("Missing required filters.");
      return;
    }

    const downloadUrl = `/api/charts/${chartType}/excel?programId=${filters.programId}&campusId=${filters.campusId}&year=${filters.year}`;
    window.location.href = downloadUrl;
  };

  if (
    !filters.campusId ||
    !filters.programId ||
    !filters.year ||
    filters.chartType !== ChartType.EXCEL_SHEET
  ) {
    return <></>;
  }

  return (
    <div className="flex justify-end">
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button className="flex bg-blue-600 hover:bg-blue-700  px-6 py-6 font-bold text-white cursor-pointer">
            <MoreVertical className="h-5 w-5" /> Download Excel Sheets
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-56">
          {CHART_OPTIONS.map((option) => (
            <DropdownMenuItem
              key={option.value}
              onClick={() => handleSelectChart(option.value)}
              className={cn(
                "cursor-pointer",
                selectedChart === option.value ? "bg-gray-200" : ""
              )}
            >
              {option.label}
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
};

export default DashboardChartExcelOptions;
