import { SelectType } from "@/types";
import Dashboard from "./components/dashboard";
import {
  fetchGraduateAttributes,
  fetchPrograms,
  getUniqueYears,
} from "@/lib/api/generic"; // ✅ Import API functions
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Dashboard | Curriculum Accreditation",
  description: "Overview of your curriculum accreditation data.",
};

const page = async () => {
  try {
    const [programs, uniqueYears, graduateAttributes] = await Promise.all([
      fetchPrograms(),
      getUniqueYears(),
      fetchGraduateAttributes(),
    ]);

    return (
      <Dashboard
        programs={programs}
        uniqueYears={uniqueYears}
        graduateAttributes={graduateAttributes as SelectType[]}
      />
    );
  } catch (error) {
    console.error("❌ Error fetching data:", error);
    return <p>Error loading dashboard. Please try again later.</p>;
  }
};

export default page;
