"use client";

import React, { useRef, useState } from "react";
import { Button } from "../../../components/ui/button";
import { Input } from "../../../components/ui/input";
import { Upload } from "lucide-react";
import { useCustomToast } from "@/hooks/custom/use-custom-toast";
import { usePostCourseInformationMutation } from "@/redux/api/courses";
import { parseExcelToCourseInformationSheetType } from "../../../../utils/uploading-logic";
import { CourseInformationSheet } from "@/types";

type CourseFileUploadProps = {
  canUploadFile: boolean;
  programId: string;
  campusId: string;
  closeDialog: () => void;
};

const CourseFileUpload = ({
  canUploadFile,
  programId,
  campusId,
  closeDialog,
}: CourseFileUploadProps) => {
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState<number>(0);
  const fileInputRef = useRef<HTMLInputElement>(null); // Reference to the file input
  const { showSuccessToast, showErrorToast } = useCustomToast();
  const [postCourseInformationSheet, { isLoading: isCreatingCourseLoading }] =
    usePostCourseInformationMutation();

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0] || null;
    validateFile(file);
  };

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0] || null;
    validateFile(file);
  };

  const handleBoxClick = () => {
    // Trigger file input click programmatically
    if (fileInputRef.current) {
      fileInputRef.current.click();
    }
  };

  const validateFile = (file: File | null) => {
    if (!file) {
      setError("No file selected.");
      setSelectedFile(null);
      return;
    }

    // Validate Excel file
    if (
      file.type ===
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
      file.type === "application/vnd.ms-excel"
    ) {
      setSelectedFile(file);
      setError(null);
    } else {
      setError(
        "Invalid file type. Please upload an Excel file (.xlsx or .xls)."
      );
      setSelectedFile(null);
    }
  };

  const handleUploadAndCreateCourse = async () => {
    if (!selectedFile) {
      setError("No file selected.");
      return;
    }

    setProgress(0);
    console.log("Uploading file:", selectedFile);
    console.log("File name:", selectedFile.name);
    console.log("File size:", selectedFile.size);

    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setError(null);
          return 100;
        }
        return prev + 10;
      });
    }, 500);

    const reader = new FileReader();
    reader.onload = async (e) => {
      try {
        const fileContent = e.target?.result;

        if (fileContent) {
          // Use the content directly in readXLSXFile function
          const courseInformationSheet: CourseInformationSheet[] =
            parseExcelToCourseInformationSheetType(
              fileContent as ArrayBuffer,
              programId,
              campusId
            );

          console.log(courseInformationSheet, "courseInformationSheet");

          // Call the API to post the Course Information Sheet
          const response = await postCourseInformationSheet(
            courseInformationSheet
          ).unwrap();

          closeDialog();

          showSuccessToast("Course Information Sheet created successfully.");
        }
      } catch (error: any) {
        console.log(error);
        const errorMessage =
          error?.data?.error ||
          "An unexpected error occurred. Please try again.";
        showErrorToast(errorMessage);
      } finally {
        setProgress(100);
      }
    };
    reader.readAsArrayBuffer(selectedFile);
  };

  return (
    <div className="flex flex-col items-center gap-4 p-4  rounded-md  max-w-md mx-auto">
      <h2 className="text-xl font-bold text-gray-700">Upload Course Data</h2>

      {/* Drag-and-Drop Area */}
      <div
        className="w-full border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center gap-2 cursor-pointer bg-gray-50 relative"
        onDragOver={(e) => e.preventDefault()}
        onDrop={handleDrop}
        onClick={handleBoxClick} // Trigger file input on box click
      >
        <Upload className="h-10 w-10 text-gray-400" />
        <p className="text-gray-500 text-sm">
          Drag and drop Excel files here, or click to select files
        </p>

        <Input
          ref={fileInputRef} // Reference the input element
          type="file"
          accept=".xlsx, .xls"
          onChange={handleFileChange}
          className="hidden" // Keep the input hidden
        />
      </div>

      {/* Error Message */}
      {error && <p className="text-red-500 text-sm">{error}</p>}

      {/* Selected File Name */}
      {selectedFile && (
        <p className="text-green-500 text-sm">
          Selected File: {selectedFile.name}
        </p>
      )}

      {/* Upload Button */}
      <Button
        onClick={handleUploadAndCreateCourse}
        disabled={!selectedFile}
        className={`self-end px-4 py-2 text-white rounded shadow 
          ${
            selectedFile
              ? "bg-blue-600 hover:bg-blue-700"
              : "bg-gray-500 hover:bg-gray-600 disabled:bg-gray-300 disabled:cursor-not-allowed"
          }`}
      >
        Upload
      </Button>

      {progress > 0 && (
        <div className="w-full bg-gray-200 rounded-full h-4">
          <div
            className="bg-blue-600 h-4 rounded-full"
            style={{ width: `${progress}%` }}
          ></div>
        </div>
      )}
    </div>
  );
};

export default CourseFileUpload;
