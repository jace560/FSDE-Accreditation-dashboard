import {
  Select,
  SelectItem,
  SelectTrigger,
  SelectContent,
  SelectGroup,
  SelectValue,
  SelectLabel,
} from "../../../components/ui/select";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "../../../components/ui/card";
import { Button } from "../../../components/ui/button";
import { Label } from "../../../components/ui/label";
import { Input } from "@/app/components/ui/input";
import { GetCoursesQuery, Semester } from "@/types";
import { Filter } from "lucide-react";
import { Campus, Program } from "@prisma/client";
import { useState } from "react";
const SEMESTERS = Semester ? Object.values(Semester) : [];

const CoursesFilter = ({
  programs,
  campuses,
  years,
  filters,
  handleFilterChange,
  resetFilters,
  applyFilters,
}: {
  programs: Program[];
  campuses: Campus[];
  years: string[];
  filters: GetCoursesQuery;
  handleFilterChange: (name: string, value: string) => void;
  resetFilters: () => void;
  applyFilters: () => void;
}) => {
  console.log(years, "YEARS");
  return (
    <Card className="mb-6 border-gray-200 shadow-sm border rounded-sm">
      <CardHeader className="bg-gray-50 p-4 flex items-center justify-between rounded-t-lg">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-800">
          <Filter className="h-4 w-4 text-blue-600" /> {/* Icon */}
          Filter Courses
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
          {/* Program Filter */}
          <div className="flex-1">
            <Select
              value={filters.programId || ""}
              onValueChange={(value) => handleFilterChange("programId", value)}
            >
              <SelectTrigger className="w-full rounded-md  focus:ring-2 focus:ring-blue-400">
                <SelectValue placeholder="Program" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {programs.map((program) => (
                    <SelectItem
                      key={program.ProgramID}
                      value={program.ProgramID}
                      className="hover:bg-gray-100"
                    >
                      {program.ProgramName}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>

          {/* Campus Filter */}
          <div className="flex-1">
            <Select
              value={filters.campusId || ""}
              onValueChange={(value) => handleFilterChange("campusId", value)}
            >
              <SelectTrigger className="w-full  rounded-md  focus:ring-2 focus:ring-blue-400">
                <SelectValue placeholder="Campus" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {campuses.map((campus) => (
                    <SelectItem
                      key={campus.CampusID}
                      value={campus.CampusID}
                      className="hover:bg-gray-100"
                    >
                      {campus.CampusName}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>

          {/* Year Filter */}
          <div className="flex-1">
            <Select
              value={filters.year || ""}
              onValueChange={(value) => handleFilterChange("year", value)}
            >
              <SelectTrigger className="w-full rounded-md  focus:ring-2 focus:ring-blue-400">
                <SelectValue placeholder="Year" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {years &&
                    years?.map((year) => (
                      <SelectItem
                        key={year}
                        value={year}
                        className="hover:bg-gray-100"
                      >
                        {year}
                      </SelectItem>
                    ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>

          {/* Semester Filter */}
          <div className="flex-1">
            <Select
              value={filters.semester || ""}
              onValueChange={(value) => handleFilterChange("semester", value)}
            >
              <SelectTrigger className="w-full rounded-md  focus:ring-2 focus:ring-blue-400">
                <SelectValue placeholder="Semester" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {SEMESTERS.map((semester) => (
                    <SelectItem
                      key={semester}
                      value={semester}
                      className="hover:bg-gray-100"
                    >
                      {semester}
                    </SelectItem>
                  ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>

          <div className="flex-1">
            <Input
              id="courseNameQuery"
              placeholder="Search by course name..."
              value={filters.courseNameQuery || ""}
              onChange={(e) =>
                handleFilterChange("courseNameQuery", e.target.value)
              }
              className="w-full text-sm"
            />
          </div>
        </div>

        {/* Reset and Apply Buttons */}
        <div className="flex justify-end gap-4 mt-6">
          <Button
            variant="outline"
            className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-md shadow-sm px-4 py-2"
            onClick={resetFilters}
          >
            Reset
          </Button>
          <Button
            className="bg-blue-600 hover:bg-blue-700 text-white rounded-md shadow-md px-4 py-2"
            onClick={applyFilters}
          >
            Apply
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default CoursesFilter;