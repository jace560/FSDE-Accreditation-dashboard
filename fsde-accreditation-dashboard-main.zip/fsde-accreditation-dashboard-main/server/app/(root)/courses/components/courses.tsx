"use client";
import { useCustomToast } from "@/hooks/custom/use-custom-toast";
import CourseFileUpload from "./course-file-upload";
import React, { useEffect, useMemo, useState } from "react";
import { CoursesPageProps, GetCoursesQuery } from "@/types";
import Loader from "@/app/components/loader";
import {
  Dialog,
  DialogTrigger,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogClose,
} from "../../../components/ui/dialog";
import CoursesFilter from "./courses-filter";
import { Button } from "@/app/components/ui/button";
import {
  useGetCoursesQuery,
  useGetCourseYearsQuery,
  usePostCourseInformationMutation,
} from "@/redux/api/courses";
import CourseTable from "./course-table";
import { Plus } from "lucide-react";
import { useAuth } from "@/hooks/custom/use-auth";
import { parseExcelToCourseInformationSheetType } from "@/utils/uploading-logic";
import AppExcelFileUploader from "@/app/components/app-file-upload";
import { error } from "console";
import { usePathname, useRouter, useSearchParams } from "next/navigation";

const Courses = ({
  programs,
  initialCourses,
  uniqueYears,
}: CoursesPageProps) => {
  const [filters, setFilters] = useState<GetCoursesQuery>({
    programId: undefined,
    campusId: undefined,
    year: undefined,
    semester: undefined,
    courseNameQuery: undefined,
    page: "1",
    limit: "10",
  });
  const { showSuccessToast, showErrorToast } = useCustomToast();
  const [canUploadFile, setCanUploadFile] = useState(false);

  const [tempFilters, setTempFilters] = useState<GetCoursesQuery>({
    programId: undefined,
    campusId: undefined,
    year: undefined,
    semester: undefined,
    courseNameQuery: undefined,
  });
  const { isAdmin, session, status } = useAuth();
  const isAuthenticated = status === "authenticated";
  const [isCourseInfoDialogOpen, setIsCourseInfoDialog] = useState(false);

  const {
    data: courses = initialCourses,
    isLoading,
    isSuccess,
    isError,
    refetch,
    error,
  } = useGetCoursesQuery(filters);
  const {
    data: years,
    isLoading: isFetchYearsLoading,
    isFetching: isFetchingYears,
    isSuccess: isFetchingYearsSuccesssful,
  } = useGetCourseYearsQuery();
  const { showWarningToast } = useCustomToast();
  const [message, setMessage] = useState<string | null>(null);
  const pathname = usePathname();
  const router = useRouter();
  const searchParams = useSearchParams();
  const [uniqueCourseYears, setUniqueYears] = useState<string[]>(uniqueYears);

  useEffect(() => {
    if (isError) {
      showErrorToast("Failed to fetch courses. Please try again.");
    }
  }, [isSuccess, isError, courses]);

  useEffect(() => {
    if (isFetchingYearsSuccesssful) {
      setUniqueYears(years.years);
    }
  }, [isFetchingYears, years, isFetchYearsLoading, isFetchingYearsSuccesssful]);

  //Filter Handler

  const handleTempFilterChange = (name: string, value: string) => {
    setTempFilters((prev: GetCoursesQuery) => ({ ...prev, [name]: value }));
  };

  const applyFilters = () => {
    setFilters((prev: GetCoursesQuery) => ({ ...tempFilters, page: "1" }));
  };

  useEffect(() => {
    setCanUploadFile(Boolean(tempFilters.programId && tempFilters.campusId));
  }, [tempFilters]);

  const resetFilters = () => {
    setFilters({
      programId: undefined,
      campusId: undefined,
      year: undefined,
      semester: undefined,
      page: "1",
      limit: "10",
      courseNameQuery: undefined,
    });
    setTempFilters({
      programId: undefined,
      campusId: undefined,
      year: undefined,
      semester: undefined,
      courseNameQuery: undefined,
    });
  };
  const [postCourseInformationSheet, { isLoading: isCreatingCourseLoading }] =
    usePostCourseInformationMutation();

  useEffect(() => {
    // ✅ Read the message from the URL (works even on manual typing)
    const urlParams = new URLSearchParams(window.location.search);
    const messageParam = urlParams.get("message");

    if (messageParam) {
      setMessage(messageParam);
    }
  }, [searchParams]);

  useEffect(() => {
    if (!message) return;

    if (message === "unauthorized") {
      showWarningToast("You are not authorized to access this page.");
    }

    const newUrl = pathname;
    // @ts-ignore
    router.replace(newUrl, undefined, { scroll: false });

    setMessage(null); // Prevent future re-renders
  }, [message, pathname, router, showWarningToast]);

  const [isDialogOpen, setIsDialogOpen] = useState(false);

  return (
    <div className="space-y-6 w-full">
      {/* 2) Upload Button*/}
      <div className="w-full flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div className="w-full sm:w-auto flex justify-start"></div>
        <div className="w-full sm:w-auto flex justify-end">
          {canUploadFile && (
            <AppExcelFileUploader
              entityId={"course"}
              programId={tempFilters.programId as string}
              campusId={tempFilters.campusId as string}
              dialogTitle={"Upload Course Information"}
              dialogTriggerText={"Upload Course Information"}
              isDialogOpen={isCourseInfoDialogOpen}
              setIsDialogOpen={setIsCourseInfoDialog}
              excelSheetParser={parseExcelToCourseInformationSheetType}
              informationSheetType={"courseInformationSheets"}
              uploadInformationSheet={postCourseInformationSheet}
              requestDto={{}}
              reload={false}
            />
          )}
        </div>
      </div>

      {/*  Filters at the top */}
      <CoursesFilter
        programs={programs}
        campuses={programs.flatMap((program) =>
          program.Campuses.map((data) => ({
            CampusID: data.Campus.CampusID,
            CampusName: data.Campus.CampusName,
          }))
        )}
        years={uniqueCourseYears || []}
        filters={tempFilters}
        handleFilterChange={handleTempFilterChange}
        resetFilters={resetFilters}
        applyFilters={applyFilters}
      />
      <div className="my-4">
        <CourseTable
          courses={courses}
          isLoading={isLoading}
          handleRowsPerPageChange={(rows: number) =>
            setFilters((prev) => ({ ...prev, limit: rows.toString() }))
          }
          handlePageChange={(page: number) =>
            setFilters((prev) => ({ ...prev, page: page.toString() }))
          }
        />
      </div>
    </div>
  );
};

export default Courses;