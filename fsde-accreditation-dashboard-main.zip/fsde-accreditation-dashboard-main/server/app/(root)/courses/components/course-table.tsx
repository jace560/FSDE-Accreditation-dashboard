"use client";

import React, { useEffect, useState } from "react";
import { Card } from "@/app/components/ui/card";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/app/components/ui/select";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/app/components/ui/table";
import { Eye, Trash2, ChevronLeft, ChevronRight } from "lucide-react";
import { GetCoursesResponse } from "@/types";
import { useDeleteCourseMutation } from "@/redux/api/courses";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/app/components/ui/dropdown-menu";
import { useCustomToast } from "@/hooks/custom/use-custom-toast";
import { Button } from "@/app/components/ui/button";
import Link from "next/link";
import { ROUTES } from "@/utils";
import Loader from "@/app/components/loader"; // Import Loader component
import { useAuth } from "@/hooks/custom/use-auth";

interface CourseTableProps {
  courses: GetCoursesResponse;
  isLoading: boolean;
  handleRowsPerPageChange: (rows: number) => void;
  handlePageChange: (page: number) => void;
}

const CourseTable = ({
  courses,
  isLoading,
  handleRowsPerPageChange,
  handlePageChange,
}: CourseTableProps) => {
  const { data, meta } = courses;
  const [currentPage, setCurrentPage] = useState(Number(meta?.page) || 1);
  const [rowsPerPage, setRowsPerPage] = useState(Number(meta?.limit) || 10);
  const [deleteCourse] = useDeleteCourseMutation();
  const { isAdmin } = useAuth();
  useEffect(() => {
    setCurrentPage(Number(meta?.page) || 1);
    setRowsPerPage(Number(meta?.limit) || 10);
  }, [meta]);
  const { showConfirmationToast, showErrorToast, showSuccessToast } =
    useCustomToast();
  const totalPages = Math.ceil(meta?.total / rowsPerPage);
  const handleDelete = (courseId: string, courseCode: String) => {
    showConfirmationToast(
      `Are you sure you want to delete ${courseCode}?`,
      "Delete",
      async () => {
        try {
          await deleteCourse(courseId).unwrap();

          showSuccessToast(`${courseCode} deleted successfully.`);
        } catch (error) {
          showErrorToast(`Failed to delete ${courseCode}.`);
        }
      }
    );
  };

  const handleNextPage = () => {
    if (currentPage < totalPages) {
      const nextPage = currentPage + 1;
      setCurrentPage(nextPage);
      handlePageChange(nextPage);
    }
  };

  const handlePreviousPage = () => {
    if (currentPage > 1) {
      const prevPage = currentPage - 1;
      setCurrentPage(prevPage);
      handlePageChange(prevPage);
    }
  };

  const handleRowsChange = (rows: number) => {
    setRowsPerPage(rows);
    setCurrentPage(1);
    handleRowsPerPageChange(rows);
  };

  if (isLoading) {
    return <Loader message="Loading courses..." />; // Use the Loader component
  }

  if (!data || data.length === 0) {
    return (
      <div className="text-gray-700 text-center mt-4">
        No courses available.
      </div>
    );
  }

  return (
    <div className="mt-6 text-sm">
      <Card className="shadow-sm rounded-sm border">
        <div className="overflow-x-auto">
          <Table className="min-w-full bg-white rounded-md">
            <TableHeader>
              <TableRow className="bg-gray-50">
                <TableHead className="px-4 py-3 text-xs font-medium text-gray-600">
                  Course Code
                </TableHead>
                <TableHead className="px-4 py-3 text-xs font-medium text-gray-600">
                  Course Name
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {data.map((course, index) => (
                <TableRow key={course.CourseID}>
                  <TableCell className="px-4 py-3">
                    <Link
                      href={`${ROUTES.COURSES}/${course.CourseID}`}
                      passHref
                    >
                      {course.CourseCode}
                    </Link>
                  </TableCell>
                  <TableCell className="px-4 py-3">
                    <div>
                      <span>{course.CourseName}</span>
                      <div className="text-xs text-gray-500 mt-1">
                        <span>{course.Campus.CampusName}</span>
                        {` · `}
                        <span>{course.SemesterName}</span>
                        {` · `}
                        <span>{course.Year}</span>
                        {` · `}
                        <span>{course.SectionNumber}</span>
                      </div>
                    </div>
                  </TableCell>
                  <TableCell className="text-center px-3 py-3">
                    <DropdownMenu>
                      <DropdownMenuTrigger asChild>
                        <Button variant="ghost" size="icon">
                          <span className="text-gray-500">⋮</span>
                        </Button>
                      </DropdownMenuTrigger>
                      <DropdownMenuContent>
                        <DropdownMenuItem className="text-sm cursor-pointer">
                          <Link
                            href={`${ROUTES.COURSES}/${course.CourseID}`}
                            passHref
                          >
                            <div className="flex items-center">
                              <Eye className="mr-2 h-4 w-4 text-blue-500" />
                              <span>View</span>
                            </div>
                          </Link>
                        </DropdownMenuItem>

                        {isAdmin && (
                          <DropdownMenuItem
                            className="text-sm"
                            onClick={() =>
                              handleDelete(course.CourseID, course.CourseCode)
                            }
                          >
                            <Trash2
                              className={`mr-2 h-4 w-4 cursor-pointer text-red-500`}
                            />
                            Delete
                          </DropdownMenuItem>
                        )}
                      </DropdownMenuContent>
                    </DropdownMenu>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        {meta?.total > 0 && (
          <div className="px-4 py-3 flex justify-between items-center">
            <div className="flex items-center">
              <span className="text-sm mr-2">Rows per page:</span>
              <Select
                onValueChange={(value) => handleRowsChange(Number(value))}
                defaultValue={rowsPerPage.toString()}
              >
                <SelectTrigger className="w-20 text-sm">
                  <SelectValue placeholder={rowsPerPage.toString()} />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="10">10</SelectItem>
                  <SelectItem value="20">20</SelectItem>
                  <SelectItem value="50">50</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center space-x-2">
              <button
                onClick={handlePreviousPage}
                disabled={currentPage === 1}
                className="text-gray-500 disabled:text-gray-300"
              >
                <ChevronLeft />
              </button>
              <span className="text-sm">
                Page {currentPage} of {totalPages}
              </span>
              <button
                onClick={handleNextPage}
                disabled={currentPage === totalPages}
                className="text-gray-500 disabled:text-gray-300"
              >
                <ChevronRight />
              </button>
            </div>
          </div>
        )}
      </Card>
    </div>
  );
};

export default CourseTable;