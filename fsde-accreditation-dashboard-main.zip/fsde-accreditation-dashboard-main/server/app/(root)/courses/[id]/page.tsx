import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Course from "./components/course";
import { getCourseDetailsWithLODistribution } from "@/lib/api/generic";
import { isValidUUID } from "@/utils";

// Use Next.js built-in types
export async function generateMetadata({
  params,
}: {
  params: { id: string };
}): Promise<Metadata> {
  const courseDetails = await fetchCourseDetails(params.id);

  if (!courseDetails) {
    return { title: "Course Not Found | Curriculum Accreditation" };
  }

  return {
    title: `${courseDetails.course.CourseName} | Curriculum Accreditation`,
    description: `Explore details for the ${courseDetails.course.CourseName} course.`,
  };
}

// Fetch Course Data
async function fetchCourseDetails(id: string) {
  if (!isValidUUID(id)) {
    return null;
  }
  return await getCourseDetailsWithLODistribution(id);
}

// Use inline type definition instead of referencing CoursePageProps
export default async function CoursePage({
  params,
}: {
  params: { id: string };
}) {
  const id = params.id;

  // Validate UUID before making a request
  if (!isValidUUID(id)) {
    notFound();
  }

  const courseDetails = await getCourseDetailsWithLODistribution(id);

  if (!courseDetails) {
    notFound();
  }

  return (
    <div>
      <Course courseDetails={courseDetails} />
    </div>
  );
}
