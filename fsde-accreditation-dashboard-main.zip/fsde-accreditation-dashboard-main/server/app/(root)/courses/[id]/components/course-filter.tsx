import {
  Select,
  SelectItem,
  SelectTrigger,
  SelectContent,
  SelectGroup,
  SelectValue,
} from "../../../../components/ui/select";
import { Card, CardContent, CardHeader } from "../../../../components/ui/card";
import { Button } from "../../../../components/ui/button";
import { GetCourseMappingQuery, GetCoursesQuery, Semester } from "@/types";
import { Filter } from "lucide-react";
import { MappingVersionResponse } from "@/lib/api/generic";
const SEMESTERS = Semester ? Object.values(Semester) : [];

const CourseFilter = ({
  mappingVersions,
  filters,
  handleFilterChange,
  resetFilters,
  applyFilters,
}: {
  mappingVersions: MappingVersionResponse[];
  filters: GetCourseMappingQuery;
  handleFilterChange: (name: string, value: string) => void;
  resetFilters: () => void;
  applyFilters: () => void;
}) => {
  return (
    <Card className="mb-6 border-gray-200 shadow-sm border rounded-sm">
      <CardHeader className="bg-gray-50 p-4 flex items-center justify-between rounded-t-lg">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-800">
          <Filter className="h-4 w-4 text-blue-600" /> {/* Icon */}
          Filter Mapping Version
        </div>
      </CardHeader>
      <CardContent className="p-6">
        <div className="">
          {/* mappingVersion Filter */}
          <div className="">
            <Select
              value={filters.mappingVersion || ""}
              onValueChange={(value) =>
                handleFilterChange("mappingVersion", value)
              }
            >
              <SelectTrigger className="w-full rounded-md  focus:ring-2 focus:ring-blue-400">
                <SelectValue placeholder="Choose Mapping Version" />
              </SelectTrigger>
              <SelectContent>
                <SelectGroup>
                  {mappingVersions &&
                    mappingVersions.map((mappingVersion) => (
                      <SelectItem
                        key={mappingVersion.MappingVersion}
                        value={mappingVersion.MappingVersion}
                        className="hover:bg-gray-100"
                      >
                        {mappingVersion.MappingVersion}{" "}
                        {mappingVersion.IsCurrent && "(Current)"}
                      </SelectItem>
                    ))}
                </SelectGroup>
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Reset and Apply Buttons */}
        <div className="flex justify-end gap-4 mt-6">
          <Button
            variant="outline"
            className="bg-white border border-gray-300 hover:bg-gray-50 text-gray-700 rounded-md shadow-sm px-4 py-2"
            onClick={resetFilters}
          >
            Reset
          </Button>
          <Button
            className="bg-blue-600 hover:bg-blue-700 text-white rounded-md shadow-md px-4 py-2"
            onClick={applyFilters}
          >
            Apply
          </Button>
        </div>
      </CardContent>
    </Card>
  );
};

export default CourseFilter;
