import { Card, CardHeader } from "@/app/components/ui/card";
import { Course } from "@prisma/client";
import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/app/components/ui/table";
import { Book, Filter } from "lucide-react";

type CourseInfoProps = {
  courseInfo: Course;
};

const CourseInfo = ({ courseInfo }: CourseInfoProps) => {
  console.log(courseInfo, "Course Info");
  return (
    <Card className="mb-6 border-gray-200 shadow-sm border rounded-sm">
      <CardHeader className="bg-gray-50 p-4 flex items-center justify-between rounded-t-lg">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-800">
          <Book className="h-4 w-4 text-blue-600" /> {/* Icon */}
          Course Summary
        </div>
      </CardHeader>
      <Table className="min-w-full bg-white rounded-md">
        <TableBody>
          <TableRow key={courseInfo.CourseID}>
            <TableCell className="px-4 py-3">{courseInfo.CourseCode}</TableCell>
            <TableCell className="px-4 py-3">
              <div>
                <span className="font-medium">{courseInfo.CourseName}</span>
                <div className="text-gray-500 text-xs mt-1">
                  <span>{courseInfo.SemesterName}</span>
                  {` · `}
                  <span>{courseInfo.Year}</span>
                  {` · `}
                  <span>Section {courseInfo.SectionNumber}</span>
                </div>
              </div>
            </TableCell>
          </TableRow>
        </TableBody>
      </Table>
    </Card>
  );
};

export default CourseInfo;
