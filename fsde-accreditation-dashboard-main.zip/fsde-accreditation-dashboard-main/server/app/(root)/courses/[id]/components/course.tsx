"use client";
import React, { useState } from "react";
import CourseFilter from "./course-filter";
import { useCustomToast } from "@/hooks/custom/use-custom-toast";
import {
  CourseDetailsDto,
  GetCourseDetailsResponseDto,
  GetCourseMappingQuery,
} from "@/types";
import { MappingVersionResponse } from "@/lib/api/generic";
import CourseLOPerformanceDistributionChart from "./course-lo-performance-distribution-chart";
import CourseInfo from "./course-info";
import {
  useGetCourseLOPerformanceQuery,
  useGetCourseMappingDetailsQuery,
  usePostStudentGradeSheetInformationMutation,
  useUpdateCourseInformationMutation,
} from "@/redux/api/courses";
import Loader from "@/app/components/loader";
import CourseDetailsTable from "./course-mapping-details";
import AppExcelFileUploader from "@/app/components/app-file-upload";
import {
  extractGradesFromExcel,
  parseSingleSheetExcelToCourseInformation,
} from "@/utils/uploading-logic";
import { useSession } from "next-auth/react";

type CoursePageProp = {
  courseDetails: CourseDetailsDto;
};

const Course = ({ courseDetails }: CoursePageProp) => {
  const currentMappingVersion =
    courseDetails.mappingVersions.find(
      (mappingVersion) => mappingVersion.IsCurrent
    )?.MappingVersion || undefined;
  const [
    updateCourseInformation,
    {
      isLoading: isUpdatingCourseInformationLoading,
      error: updatingCOurseInformationError,
      isError: hasUpdateCourseInformationError,
    },
  ] = useUpdateCourseInformationMutation();
  const [
    updateStudentGradeSheet,
    {
      isLoading: isUpdatingStudentGradeSheetLoading,
      error: updatingStudentGradeSheetError,
      isError: hasUpdateStudentGradeShetError,
    },
  ] = usePostStudentGradeSheetInformationMutation();

  const {
    data: clientLODistribution,
    isLoading: isLoPerformanceLoading,
    isError: hasLOPerformanceError,
  } = useGetCourseLOPerformanceQuery(
    {
      mappingVersion: currentMappingVersion as string,
      courseId: courseDetails.course.CourseID as string,
    },
    { skip: !currentMappingVersion || !courseDetails.course.CourseID }
  );

  const [filters, setFilters] = useState<GetCourseMappingQuery>({
    mappingVersion:
      courseDetails.mappingVersions.find(
        (mappingVersion) => mappingVersion.IsCurrent
      )?.MappingVersion || undefined,
  });
  const [isStudentGradesDialogOpen, setIsStudentGradesDialog] = useState(false);
  const [isCourseInfoDialogOpen, setIsCourseInfoDialog] = useState(false);

  const { showSuccessToast, showErrorToast } = useCustomToast();
  const [canUploadFile, setCanUploadFile] = useState(false);
  const {
    data: courseMappingDetails,
    isLoading: iscourseMappingDetailsLoading,
  } = useGetCourseMappingDetailsQuery(
    {
      courseID: courseDetails.course.CourseID,
      mappingVersion: filters.mappingVersion as string,
    },
    {
      skip: !filters.mappingVersion || !courseDetails.course.CourseID,
    }
  );
  const { data: session } = useSession();

  const [tempFilters, setTempFilters] = useState<GetCourseMappingQuery>({
    mappingVersion: undefined,
  });

  const handleTempFilterChange = (name: string, value: string) => {
    setTempFilters((prev: GetCourseMappingQuery) => ({
      ...prev,
      [name]: value,
    }));
  };

  console.log(session, "CLIBSSB");

  const loDistribution = clientLODistribution;

  const applyFilters = () => {
    setFilters((prev: GetCourseMappingQuery) => ({
      ...tempFilters,
      page: "1",
    }));
  };

  //   useEffect(() => {
  //     setCanUploadFile(Boolean(tempFilters.));
  //   }, [tempFilters]);

  const resetFilters = () => {
    setFilters({
      mappingVersion: currentMappingVersion,
    });
    setTempFilters({
      mappingVersion: undefined,
    });
  };

  if (iscourseMappingDetailsLoading) {
    return <Loader message="Loading course details..." />;
  }

  return (
    <div>
      <div className="w-full flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
        <div className="w-full sm:w-auto flex justify-start">
          <AppExcelFileUploader // Show I want you to show
            entityId={courseDetails.course.CourseID}
            programId={courseDetails.programId}
            campusId={courseDetails.course.CampusID}
            dialogTitle={"Upload Student Grades"}
            dialogTriggerText={"Upload Student Grades"}
            isDialogOpen={isStudentGradesDialogOpen}
            setIsDialogOpen={setIsStudentGradesDialog}
            excelSheetParser={extractGradesFromExcel}
            informationSheetType={"studentGradeSheet"}
            uploadInformationSheet={updateStudentGradeSheet}
            requestDto={{
              canUploadFileourseID: courseDetails.course.CourseID,
              programID: courseDetails.programId,
              campusID: courseDetails.course.CampusID,
              courseID: courseDetails.course.CourseID,
            }}
            reload={true}
          />
        </div>

        <div className="w-full sm:w-auto flex justify-end">
          <AppExcelFileUploader
            entityId={courseDetails.course.CourseID}
            programId={courseDetails.programId}
            campusId={courseDetails.course.CampusID}
            dialogTitle={"Update Course Information"}
            dialogTriggerText={"Update Course Information"}
            isDialogOpen={isCourseInfoDialogOpen}
            setIsDialogOpen={setIsCourseInfoDialog}
            excelSheetParser={parseSingleSheetExcelToCourseInformation}
            informationSheetType={"courseInformationSheet"}
            uploadInformationSheet={updateCourseInformation}
            requestDto={{ courseId: courseDetails.course.CourseID }}
            reload={true}
          />
        </div>
      </div>

      <CourseInfo courseInfo={courseDetails.course} />

      <CourseLOPerformanceDistributionChart
        loDistribution={loDistribution}
        isLoPerformanceLoading={isLoPerformanceLoading}
      />
      <CourseFilter
        mappingVersions={
          courseDetails.mappingVersions as MappingVersionResponse[]
        }
        filters={tempFilters}
        handleFilterChange={handleTempFilterChange}
        resetFilters={resetFilters}
        applyFilters={applyFilters}
      />

      <CourseDetailsTable
        courseMappingDetails={
          courseMappingDetails as GetCourseDetailsResponseDto
        }
      />
    </div>
  );
};

export default Course;
