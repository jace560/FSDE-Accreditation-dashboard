import { Card, CardHeader } from "@/app/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/app/components/ui/table";
import { GetCourseDetailsResponseDto } from "@/types";
import { Table2 } from "lucide-react";

interface CourseDetailsProps {
  courseMappingDetails: GetCourseDetailsResponseDto;
}

const CourseDetailsTable: React.FC<CourseDetailsProps> = ({
  courseMappingDetails,
}) => {
  return (
    <div className="text-sm">
      <Card className="mb-6 border-gray-200 shadow-sm border rounded-sm">
        <CardHeader className="bg-gray-50 p-4 flex items-center justify-between rounded-sm">
          <div className="flex items-center gap-2 text-sm font-bold text-gray-800">
            <Table2 className="h-4 w-4 text-blue-600" /> {/* Icon */}
            {"Course Mappings"}
          </div>
        </CardHeader>
        <div className="overflow-x-auto p-6 space-y-6">
          {/* Learning Objectives Table */}
          <div className="flex items-center gap-2 text-sm font-bold text-gray-800">
            Learning Objectives - Performnace Indicator Mapping
          </div>
          <Table className="min-w-full bg-white rounded-sm shadow-sm mb-6">
            <TableHeader>
              <TableRow className="">
                <TableHead className="px-6 py-4 text-sm font-medium text-gray-700">
                  LO Name
                </TableHead>

                <TableHead className="px-6 py-4 text-sm font-medium text-gray-700">
                  Description
                </TableHead>
                <TableHead className="px-6 py-4 text-sm font-medium text-gray-700">
                  Performance Indicators
                </TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {courseMappingDetails?.LearningObjectives.map((objective) => (
                <TableRow
                  key={objective.LOID || objective.LOName}
                  className="hover:bg-gray-50"
                >
                  <TableCell className="px-6 py-4 text-sm font-medium text-gray-900">
                    {objective.LOName}
                  </TableCell>
                  <TableCell className="px-6 py-4 text-sm font-medium text-gray-900">
                    {objective.LODescription}
                  </TableCell>

                  <TableCell className="px-6 py-4 text-sm text-gray-700">
                    {objective.LearningObjectivePerformanceIndicatorMappings.map(
                      (pi, index) => (
                        <span key={index} className="text-sm text-gray-700">
                          {pi.PIName}
                          {index <
                            objective
                              .LearningObjectivePerformanceIndicatorMappings
                              .length -
                              1 && ", "}
                        </span>
                      )
                    )}
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>

          {/* Assessment Tools Table */}
          <div className="flex items-center gap-2 text-sm font-bold text-gray-800">
            Assessment Tools - Learning Objective Mappings
          </div>
          <Table className="min-w-full bg-white rounded-sm shadow-sm overflow-x-auto">
            <TableHeader>
              <TableRow className="">
                <TableHead className="px-6 py-4 text-sm font-medium text-nowrap text-gray-700">
                  AT Name
                </TableHead>
                <TableHead className="px-6 py-4  text-nowrap text-sm font-medium text-gray-700">
                  Weight (%)
                </TableHead>
                <TableHead className="px-6 py-4 text-sm font-medium text-gray-700">
                  Description
                </TableHead>
                {courseMappingDetails?.LearningObjectives.map((lo) => (
                  <TableHead
                    key={lo.LOID || lo.LOName}
                    className="px-6 py-4 text-sm font-medium text-nowrap text-gray-700"
                  >
                    {lo.LOName}
                  </TableHead>
                ))}
              </TableRow>
            </TableHeader>
            <TableBody>
              {courseMappingDetails?.AssessmentTools.map((tool) => (
                <TableRow
                  key={tool.ATID || tool.ATName}
                  className="hover:bg-gray-50"
                >
                  <TableCell className="px-6 py-4 text-sm font-medium text-gray-900">
                    {tool.ATName}
                  </TableCell>
                  <TableCell className="px-6 py-4 text-sm text-gray-700">
                    {tool.Weight}
                  </TableCell>
                  <TableCell
                    className="px-6 py-4 text-sm truncate hover:overflow-visible text-gray-700"
                    title={tool.Description}
                  >
                    {tool.Description.length > 50
                      ? `${tool.Description.substring(0, 50)}...`
                      : tool.Description}
                  </TableCell>
                  {courseMappingDetails.LearningObjectives.map((lo) => {
                    const mapping =
                      tool.AssessmentToolLearningObjectiveMappings.find(
                        (m) => m.LOName === lo.LOName
                      );
                    return (
                      <TableCell
                        key={lo.LOID || lo.LOName}
                        className="px-6 py-4 text-sm text-center text-gray-700"
                      >
                        {mapping ? `${mapping.Weight}` : "-"}
                      </TableCell>
                    );
                  })}
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </Card>
    </div>
  );
};

export default CourseDetailsTable;
