import React, { useRef } from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { LODistributionCountsWithPercentages } from "@/types/weights";
import { Card, CardHeader } from "@/app/components/ui/card";
import { Alert, AlertTitle, AlertDescription } from "@/app/components/ui/alert";
import { BarChart3, Filter, Info } from "lucide-react";
import { Button } from "@/app/components/ui/button";
import * as htmlToImage from "html-to-image";
import Loader from "@/app/components/loader";

type LOBarChartProps = {
  loDistribution: { data: LODistributionCountsWithPercentages[] };
};

// Custom tooltip formatter
const tooltipFormatter = (value: number, name: string) => {
  // Map the keys (dataKey) to clean labels
  const labelMap: Record<string, string> = {
    exceedsPercentage: "Exceeds",
    acceptablePercentage: "Acceptable",
    marginalPercentage: "Marginal",
    failPercentage: "Fail",
  };

  // Use the mapped label if it exists, or fall back to the original name
  const cleanName = labelMap[name] || name;

  return [`${value}`, cleanName]; // Format: [value, label]
};

const CourseLOPerformanceDistributionChart = ({
  loDistribution,
  isLoPerformanceLoading,
}: any) => {
  // Transform loDistribution (object) to an array of objects for BarChart
  if (isLoPerformanceLoading) {
    return <Loader message="Loading LO Distribution...." />;
  }

  const chartData =
    loDistribution?.data &&
    Object.values(loDistribution.data).map((item: any) => ({
      LOName: item.LOName,
      Exceeds: item.exceedsPercentage,
      Acceptable: item.acceptablePercentage,
      Marginal: item.marginalPercentage,
      Fail: item.failPercentage,
    }));
  if (!chartData || chartData.length === 0) {
    return (
      <Card className="border border-yellow-400 rounded-lg shadow-sm mb-6 p-6 bg-yellow-50">
        <div className="flex flex-col sm:flex-row items-start gap-4 ">
          <Info className="h-4 w-4 text-yellow-600 flex-shrink-0" />
          <div>
            <AlertTitle className="text-yellow-700 font-semibold text-sm mb-2">
              Warning: No Data Available
            </AlertTitle>
            <AlertDescription className="text-yellow-800 text-sm ">
              There is no data available for Learning Objectives Distribution.
              Please update student grades to view the chart.
            </AlertDescription>
          </div>
        </div>
      </Card>
    );
  }
  const chartRef = useRef<HTMLDivElement>(null);

  const handleExport = async () => {
    if (chartRef.current) {
      try {
        const dataUrl = await htmlToImage.toPng(chartRef.current); // Convert to PNG
        const link = document.createElement("a");
        link.href = dataUrl;
        link.download = "LO_Performance_Distribution.png"; // File name
        link.click(); // Trigger the download
      } catch (error) {
        console.error("Failed to export the chart as an image:", error);
      }
    } else {
      console.error(
        "chartRef is not defined or not attached to the DOM element."
      );
    }
  };

  return (
    <Card className="border border-gray-200 rounded-md shadow-sm mb-6">
      <CardHeader className="bg-gray-50 p-4 flex items-center justify-between rounded-t-lg">
        <div className="flex items-center gap-2 text-sm font-bold text-gray-800">
          <BarChart3 className="h-4 w-4 text-blue-600" /> {/* Icon */}
          {"Learning Objective Performance Distribution"}
        </div>
      </CardHeader>
      <div ref={chartRef} className="w-full h-[500px] bg-white">
        <ResponsiveContainer>
          <BarChart
            data={chartData}
            margin={{ top: 20, right: 20, left: 60, bottom: 80 }} // Added bottom margin to avoid legend overlap
          >
            <CartesianGrid strokeDasharray="3 3" />
            <XAxis
              dataKey="LOName"
              tick={{ className: "text-gray-600 text-sm" }}
              label={{
                value: "Learning Objectives",
                position: "insideBottom",
                className: "text-gray-700 text-sm",
                dy: 25, // Adjusted for better spacing
              }}
            />
            <YAxis
              tickFormatter={(value) => `${value}%`}
              tick={{ className: "text-gray-600 text-sm" }}
              label={{
                value: "Percentage (%)",
                angle: -90,
                position: "insideLeft",
                className: "text-gray-700 text-sm",
                dx: -40, // Adjusted to prevent overlap
              }}
            />
            <Tooltip
              cursor={{
                fill: "rgba(0, 0, 0, 0.1)",
                style: { cursor: "pointer" },
              }}
              content={({ payload, label }) => {
                if (payload && payload.length) {
                  return (
                    <div className="bg-white border border-gray-300 rounded-md p-2 shadow">
                      <p className="text-gray-800 font-semibold mb-1">
                        {label}
                      </p>
                      {payload.map((entry, index) => (
                        <p
                          key={`item-${index}`}
                          className="text-sm"
                          style={{ color: entry.color }}
                        >
                          {entry.name}: {Math.round(entry.value as number)}%
                        </p>
                      ))}
                    </div>
                  );
                }
                return null;
              }}
            />
            <Legend
              verticalAlign="bottom"
              align="center"
              wrapperStyle={{ paddingTop: 30 }}
              payload={[
                { value: "Exceeds", type: "square", color: "#4CAF50" }, // Green
                {
                  value: "Acceptable ",
                  type: "square",
                  color: "#8BC34A",
                }, // Light Green
                { value: "Marginal", type: "square", color: "#FFC107" }, // Yellow
                { value: "Fail", type: "square", color: "#F44336" }, // Red
              ]}
              iconType="square"
            />
            <Bar dataKey="Exceeds" fill="#4CAF50" /> {/* Green */}
            <Bar dataKey="Acceptable" fill="#8BC34A" /> {/* Light Green */}
            <Bar dataKey="Marginal" fill="#FFC107" /> {/* Yellow */}
            <Bar dataKey="Fail" fill="#F44336" /> {/* Red */}
          </BarChart>
        </ResponsiveContainer>
      </div>

      <div className="flex justify-end m-4">
        <Button
          onClick={handleExport}
          className="bg-blue-600 hover:bg-blue-700 text-white px-4 py-2"
        >
          Export as PNG
        </Button>
      </div>
    </Card>
  );
};

export default CourseLOPerformanceDistributionChart;
