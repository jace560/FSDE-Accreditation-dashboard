import React from "react";
import { Metadata } from "next";
import CoursesPage from "./components/courses";
import logger from "@/lib/logger";
import {
  fetchInitialCourses,
  fetchPrograms,
  getUniqueYears,
} from "@/lib/api/generic";

export const metadata: Metadata = {
  title: "Courses | Curriculum Accreditation",
  description: "Explore and manage accredited courses.",
};
const page = async () => {
  logger.info("Fetching programs and courses and years started.");

  const [programs, initialCourses, uniqueYears] = await Promise.all([
    fetchPrograms(),
    fetchInitialCourses(),
    getUniqueYears(),
  ]);

  logger.info("Successfully fetched programs and courses.");

  return (
    <>
      <CoursesPage
        programs={programs}
        initialCourses={initialCourses}
        uniqueYears={uniqueYears}
      />
    </>
  );
};

export default page;
