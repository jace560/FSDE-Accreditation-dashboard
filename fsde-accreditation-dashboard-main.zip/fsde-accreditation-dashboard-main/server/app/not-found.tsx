"use client";

import {
  Card,
  CardHeader,
  CardTitle,
  CardDescription,
  CardFooter,
} from "./components/ui/card";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import { Button } from "./components/ui/button";

export default function NotFound() {
  const router = useRouter();

  return (
    <div className="flex items-center justify-center min-h-screen bg-gray-100 p-6">
      <motion.div
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.4, ease: "easeOut" }}
      >
        <Card className="w-full max-w-md border border-gray-300 rounded-xl shadow-xs bg-white p-8">
          <CardHeader className="text-center">
            <motion.div
              initial={{ y: -10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, ease: "easeOut" }}
            >
              <CardTitle className="text-8xl font-extrabold text-blue-600 drop-shadow-2xl">
                404
              </CardTitle>
            </motion.div>
            <motion.div
              initial={{ y: 10, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.6, ease: "easeOut", delay: 0.1 }}
            >
              <CardDescription className="text-gray-700 mt-4 text-lg">
                Oops! The page you’re looking for doesn’t exist.
              </CardDescription>
            </motion.div>
          </CardHeader>
          <CardFooter className="flex flex-col space-y-4 mt-6">
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Link href="/">
                <Button className="w-full bg-gradient-to-r from-blue-500 to-blue-700 py-6  text-white font-semibold text-lg  hover:opacity-90 transition-all duration-300">
                  Go to Homepage
                </Button>
              </Link>
            </motion.div>
            <motion.div whileHover={{ scale: 1.05 }} whileTap={{ scale: 0.95 }}>
              <Button
                variant="outline"
                className="w-full border-gray-400 text-gray-700 font-semibold text-lg py-6  hover:border-gray-600 hover:text-gray-900 transition-all duration-300"
                onClick={() => router.back()}
              >
                Go Back
              </Button>
            </motion.div>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
}
