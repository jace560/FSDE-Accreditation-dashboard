import { SessionProvider } from "next-auth/react";
import AppAuthPage from "./components/app-auth-page";
import { Metadata } from "next";

export const metadata: Metadata = {
  title: "Auth | Curriculum Accreditation",
  description: "Access your account securely.",
};

export default function Home() {
  return <AppAuthPage />;
}
