"use client";
import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import ReduxProvider from "./components/redux-provider";
import { Toaster } from "./components/ui/toaster";
import { SessionProvider } from "next-auth/react";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

// export const metadata: Metadata = {
//   title: {
//     template: "%s | Curriculum Accreditation Dashboard",
//     default: "Curriculum Accreditation Dashboard",
//   },
//   // description: 'The official Next.js Learn Dashboard built with App Router.',
//   // metadataBase: new URL('https://next-learn-dashboard.vercel.sh'),
// };

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <SessionProvider>
          <ReduxProvider>
            <div className="flex h-screen w-full overflow-hidden">
              <div className="flex-1 flex flex-col overflow-hidden">
                <main className="">{children}</main>
                <Toaster />
              </div>
            </div>
          </ReduxProvider>
        </SessionProvider>
      </body>
    </html>
  );
}
