"use client";

import React, { useRef, useState } from "react";
import { Plus, Upload } from "lucide-react";
import { useCustomToast } from "@/hooks/custom/use-custom-toast";
import { usePostCourseInformationMutation } from "@/redux/api/courses";
import { CourseInformationSheet, StudentGrade } from "@/types";
import { Input } from "./ui/input";
import { Button } from "./ui/button";
import {
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  Dialog,
} from "./ui/dialog";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/custom/use-auth";

type CourseFileUploadProps = {
  entityId: string;
  programId: string;
  campusId: string;
  setIsDialogOpen: React.Dispatch<React.SetStateAction<boolean>>;
  isDialogOpen: boolean;
  dialogTitle: string;
  dialogTriggerText: string;
  excelSheetParser: any;
  informationSheetType: keyof InformationSheetTypeMapping;
  uploadInformationSheet: any;
  requestDto: any;
  reload?: boolean;
};

type InformationSheetTypeMapping = {
  courseInformationSheet?: CourseInformationSheet;
  courseInformationSheets?: CourseInformationSheet[];
  studentGradeSheet?: StudentGrade[];
};

const AppExcelFileUploader: React.FC<CourseFileUploadProps> = ({
  entityId,
  programId,
  campusId,
  dialogTitle,
  dialogTriggerText,
  isDialogOpen,
  setIsDialogOpen,
  excelSheetParser,
  informationSheetType,
  uploadInformationSheet,
  requestDto,
  reload = false,
}) => {
  const router = useRouter();
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState<number>(0);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const { showSuccessToast, showErrorToast } = useCustomToast();
  const { isAdmin } = useAuth();

  if (!isAdmin) return null;

  const validateFile = (file: File | null) => {
    if (!file) return setError("No file selected."), setSelectedFile(null);

    const isExcel =
      file.type ===
        "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet" ||
      file.type === "application/vnd.ms-excel";

    if (isExcel) setSelectedFile(file), setError(null);
    else
      setError(
        "Invalid file type. Please upload an Excel file (.xlsx or .xls)."
      ),
        setSelectedFile(null);
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) =>
    validateFile(e.target.files?.[0] || null);

  const handleDrop = (e: React.DragEvent<HTMLDivElement>) => {
    e.preventDefault();
    validateFile(e.dataTransfer.files?.[0] || null);
  };

  const triggerFileInput = () => fileInputRef.current?.click();

  const handleUpload = async () => {
    if (!selectedFile) return setError("No file selected.");

    setProgress(20); // Start progress to indicate processing
    const reader = new FileReader();

    reader.onload = async (e) => {
      try {
        const fileContent = e.target?.result;
        if (!fileContent) throw new Error("Failed to read file.");

        console.log(programId, campusId, entityId, fileContent, "FILECONTENT");

        const informationSheet: InformationSheetTypeMapping[typeof informationSheetType] =
          excelSheetParser(
            programId,
            campusId,
            entityId,
            fileContent,
            showSuccessToast,
            showErrorToast
          );

        requestDto[informationSheetType] = informationSheet;

        await uploadInformationSheet(requestDto).unwrap();
        console.log(requestDto, "requestDto");

        setProgress(100);
        showSuccessToast("Course Information Sheet updated successfully.");
        if (reload) window.location.reload();
        setIsDialogOpen(false);
        setSelectedFile(null);
        setProgress(0);
      } catch (error: any) {
        setProgress(0);

        console.log(error, "ERROR");
        showErrorToast(
          error?.data?.error ||
            "An unexpected error occurred. Please try again."
        );
      }
    };
    reader.readAsArrayBuffer(selectedFile);
  };

  return (
    <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
      <DialogTrigger asChild>
        <Button className="flex bg-blue-600 hover:bg-blue-700 w-full items-center justify-center px-6 py-6 font-bold text-white">
          <Plus className="h-5 w-5 mr-1" />
          <span className="text-md">{dialogTriggerText}</span>
        </Button>
      </DialogTrigger>

      <DialogContent>
        <DialogHeader>
          <DialogTitle>{dialogTitle}</DialogTitle>
        </DialogHeader>
        <div className="flex flex-col items-center gap-4 p-6 rounded-md max-w-md mx-auto">
          <div
            className="w-full border-2 border-dashed border-gray-300 rounded-lg p-6 flex flex-col items-center justify-center gap-2 cursor-pointer hover:bg-gray-100 transition-all"
            onDragOver={(e) => e.preventDefault()}
            onDrop={handleDrop}
            onClick={triggerFileInput}
          >
            <Upload className="h-10 w-10 text-gray-400" />
            <p className="text-gray-500 text-sm">
              Drag & drop or click to upload Excel file
            </p>
            <Input
              ref={fileInputRef}
              type="file"
              accept=".xlsx, .xls"
              onChange={handleFileChange}
              className="hidden"
            />
          </div>

          {error && <p className="text-red-500 text-sm">{error}</p>}
          {selectedFile && (
            <p className="text-green-500 text-sm">
              Selected File: {selectedFile.name}
            </p>
          )}

          <Button
            onClick={handleUpload}
            disabled={!selectedFile}
            className={`w-full py-2 text-white rounded shadow transition-all ${
              selectedFile
                ? "bg-blue-600 hover:bg-blue-700"
                : "bg-gray-500 cursor-not-allowed"
            }`}
          >
            Upload
          </Button>

          {progress > 0 && (
            <div className="w-full bg-gray-200 rounded-full h-4 mt-2">
              <div
                className="bg-blue-600 h-4 rounded-full"
                style={{ width: `${progress}%` }}
              ></div>
            </div>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
};

export default AppExcelFileUploader;
