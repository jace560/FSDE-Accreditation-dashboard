"use client";
import React, { useEffect, useRef, useState } from "react";
import { Button } from "./ui/button";
import { signIn } from "next-auth/react";
import {
  useForgotPasswordMutation,
  useRegisterMutation,
  useResetPasswordMutation,
  useVerifyAccountMutation,
} from "@/redux/api/auth";

import { zodResolver } from "@hookform/resolvers/zod";
import { usePathname, useRouter } from "next/navigation";

import { useForm } from "react-hook-form";

import * as z from "zod";
import { Input } from "./ui/input";
import { Label } from "./ui/label";
import {
  loginSchema,
  ROUTES,
  signUpSchema,
  forgotPasswordSchema,
  resetPasswordSchema,
} from "@/utils";
import Link from "next/link";
import { useCustomToast } from "@/hooks/custom/use-custom-toast";
import { useSession } from "next-auth/react";
import { SetStateBoolean, SetStateString } from "@/types";
import { tree } from "next/dist/build/templates/app-page";
import { useAuth } from "@/hooks/custom/use-auth";
import { Eye, EyeOff } from "lucide-react";

const AppAuthPage = () => {
  const [isLogin, setIsLogin] = useState(true);
  const pathname = usePathname();
  const router = useRouter();
  const { showWarningToast } = useCustomToast();
  const hasShownToast = useRef(false); // ✅ Prevent infinite loop
  const [message, setMessage] = useState<string | null>(null);
  const [authView, setAuthView] = useState(() => {
    if (typeof window !== "undefined") {
      const urlParams = new URLSearchParams(window.location.search);
      return urlParams.get("view") || "login";
    }
    return "login";
  });
  const [hasTriggeredToast, setHasTriggeredToast] = useState(false);

  const toggleForm = () => {
    if (authView === "login") {
      setAuthView("signup");
    }

    if (authView == "signup") {
      setAuthView("login");
    }

    if (authView === "reset" || authView === "forgot") {
      setAuthView("login");
    }
  };
  // ✅ Prevent double triggers
  useEffect(() => {
    // ✅ Read the message from the URL (works even on manual typing)
    const urlParams = new URLSearchParams(window.location.search);
    const messageParam = urlParams.get("message");
    const viewParam = urlParams.get("view");

    if (messageParam) {
      setMessage(messageParam);
    }
    if (viewParam) setAuthView(viewParam);
  }, []);

  useEffect(() => {
    if (!message) return;

    if (message === "login_required") {
      showWarningToast("You must be logged in to access this page.");
    }

    if (message === "unauthorized") {
      showWarningToast("You are not authorized to access this page.");
    }

    // ✅ Remove query param from URL after showing the toast
    const newUrl = pathname;
    // @ts-ignore
    router.replace(newUrl, undefined, { scroll: false });

    setMessage(null); // Prevent future re-renders
  }, [message, pathname, router, showWarningToast]);

  return (
    <div className="flex min-h-screen flex-col md:flex-row">
      {/* Left side - Image */}
      <div className="hidden w-full md:block md:w-1/2 bg-gradient-to-br from-blue-600 to-indigo-800">
        <div className="flex h-full items-center justify-center p-4 sm:p-6 md:p-8 lg:p-12">
          <div className="text-center text-white">
            <h1 className="text-2xl sm:text-3xl md:text-4xl font-bold mb-4 sm:mb-6">
              Curriculum Accreditation Dashboard
            </h1>
            <div className="w-12 sm:w-16 h-1 bg-white mx-auto rounded-full mb-4 sm:mb-6 md:mb-8"></div>
            <p className="text-sm sm:text-md mb-4 sm:mb-6 md:mb-8">
              Streamline your accreditation process
            </p>
          </div>
        </div>
      </div>

      {/* Right side - Form */}
      <div className="flex w-full items-center justify-center p-8 md:w-1/2">
        <div className="w-full max-w-md space-y-8">
          <div className="text-center">
            {/* <Link href={ROUTES.USER_DASHBOARD}>
             <Image src={logo} alt="Example Image" width={300} height={300} /> 
            </Link> */}

            <h2 className="mt-6 text-3xl font-bold tracking-tight text-gray-900">
              {(() => {
                switch (authView) {
                  case "login":
                    return "Sign in to your account";
                  case "signup":
                    return "Create a new account";
                  case "verify":
                    return "Verify Your Account";
                  case "forgot":
                    return "Forgot Password";
                  case "reset":
                    return "Reset Password";
                  default:
                    return "Sign in to your account"; // Fallback
                }
              })()}
            </h2>

            <p className="mt-2 text-sm text-gray-600">
              {(() => {
                switch (authView) {
                  case "login":
                    return "Sign in to your account";
                  case "signup":
                    return "Create a new account";
                  case "verify":
                    return "Your account is already verified?";
                  case "forgot":
                  case "reset":
                    return "Remembered your Password?";
                  default:
                    return "Sign in to your account"; // Fallback
                }
              })()}

              <Button
                variant="link"
                onClick={toggleForm}
                className="ml-1 p-0 text-blue-600 hover:text-blue-800"
              >
                {(() => {
                  switch (authView) {
                    case "login":
                      return "Sign up";
                    case "signup":
                    case "verify":
                      return "Sign in";
                    case "reset":
                    case "forgot":
                      return "Log in";
                    default:
                      return "Sign up"; // Fallback
                  }
                })()}
              </Button>
            </p>
          </div>
          {(() => {
            switch (authView) {
              case "login":
                return <Login setAuthView={setAuthView} />;
              case "signup":
                return <SignUp setAuthView={setAuthView} />;
              // case "verify":
              //   return <VerifyAccount setAuthView={setAuthView} />;
              // case "forgot":
              //   return <ForgotPassword setAuthView={setAuthView} />;
              case "forgot":
                return <ResetPassword setAuthView={setAuthView} />;
              default:
                return <Login setAuthView={setAuthView} />;
            }
          })()}
        </div>
      </div>
    </div>
  );
};

export default AppAuthPage;

const Login = ({ setAuthView }: { setAuthView: SetStateString }) => {
  type LoginFormData = z.infer<typeof loginSchema>;

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm<LoginFormData>({
    resolver: zodResolver(loginSchema),
  });
  const router = useRouter();
  const { showWarningToast, showErrorToast, showSuccessToast } =
    useCustomToast();
  const { status, session } = useAuth();
  const [isLoggingIn, setIsLoggingIn] = useState(false);
  const [isUserLoggingIn, setIsUserLoggingIn] = useState(false);

  const onSubmit = async (data: LoginFormData) => {
    try {
      if (status === "authenticated") {
        showWarningToast("You are already logged in.");
        router.push("/courses");
        return;
      }
      setIsLoggingIn(true);
      setIsUserLoggingIn(true);
      const result = await signIn("credentials", {
        redirect: false,
        Email: data.Email,
        Password: data.Password,
      });

      if (result?.error) {
        showErrorToast(
          result?.error || "Incorrect email or password. Please try again."
        );
        setIsLoggingIn(false);

        return;
      }
    } catch (error) {
      console.error("Login Error:", error);
      showErrorToast(
        "An error occurred while logging in. Please check your network and try again."
      );
      setIsUserLoggingIn(false);
      setIsLoggingIn(false);
    }
  };

  const toggleForm = () => {
    setAuthView("forgot");

    console.log("I WAS CLAAED");
  };

  useEffect(() => {
    if (isUserLoggingIn && status === "authenticated" && session) {
      showSuccessToast("Login successful! Redirecting to courses...");
      setTimeout(() => {
        router.push("/courses");

        reset();
      }, 400);
    }
  }, [status, router, isLoggingIn]);

  return (
    <>
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <div>
          <Label htmlFor="email" className="text-gray-700">
            Email address
          </Label>
          <Input
            id="email"
            type="email"
            {...register("Email")}
            className="mt-1 bg-white"
          />
          {errors.Email && (
            <p className="mt-1 text-sm text-red-600">{errors.Email.message}</p>
          )}
        </div>
        <div>
          <Label htmlFor="password" className="text-gray-700">
            Password
          </Label>
          {/* <Input
            id="password"
            type="password"
            {...register("Password")}
            className="mt-1 bg-white"
          />
          {errors.Password && (
            <p className="mt-1 text-sm text-red-600">
              {errors.Password.message}
            </p>
          )} */}
          <PasswordInput register={register} name="Password" errors={errors} />
        </div>
        <div className="flex items-center justify-end">
          <Button
            variant="link"
            type="button"
            onClick={toggleForm}
            className="ml-1 p-0 text-blue-600 hover:text-blue-800"
          >
            Forgot your password?
          </Button>
        </div>

        <Button
          type="submit"
          disabled={isLoggingIn}
          className="w-full bg-blue-600 hover:bg-blue-700 text-white"
        >
          {isLoggingIn ? "Signing in..." : "Sign in"}
        </Button>
      </form>
    </>
  );
};

const SignUp = ({ setAuthView }: { setAuthView: SetStateString }) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
    watch,
  } = useForm<SignUpFormData>({
    resolver: zodResolver(signUpSchema),
  });
  const [registerUser, { isError, error, isLoading }] = useRegisterMutation();
  const router = useRouter();
  const Password = watch("Password") || "";
  const { showErrorToast, showSuccessToast } = useCustomToast();

  console.log(errors, "ERROSZ");

  const onSubmit = async (data: SignUpFormData) => {
    try {
      await registerUser(data).unwrap();
      showSuccessToast(
        "User created successfully. Check your email for verification."
      );
      setAuthView("login");

      reset();
    } catch (error: any) {
      showErrorToast(
        error?.data?.error || "An unexpected error occurred. Please try again."
      );
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div className="grid grid-cols-2 gap-4">
        <div>
          <Label htmlFor="firstName" className="text-gray-700">
            First Name
          </Label>
          <Input
            id="firstName"
            type="text"
            {...register("FirstName")}
            className="mt-1 bg-white"
          />
          {errors.FirstName && (
            <p className="mt-1 text-sm text-red-600">
              {errors.FirstName.message}
            </p>
          )}
        </div>
        <div>
          <Label htmlFor="lastName" className="text-gray-700">
            Last Name
          </Label>
          <Input
            id="lastName"
            type="text"
            {...register("LastName")}
            className="mt-1 bg-white"
          />
          {errors.LastName && (
            <p className="mt-1 text-sm text-red-600">
              {errors.LastName.message}
            </p>
          )}
        </div>
      </div>
      <div>
        <Label htmlFor="email" className="text-gray-700">
          Email address
        </Label>
        <Input
          id="email"
          type="email"
          {...register("Email")}
          className="mt-1 bg-white"
        />
        {errors.Email && (
          <p className="mt-1 text-sm text-red-600">{errors.Email.message}</p>
        )}
      </div>
      <div>
        <Label htmlFor="password" className="text-gray-700">
          Password
        </Label>
        {/* <Input
          id="password"
          type="password"
          {...register("Password")}
          className="mt-1 bg-white"
        />
        {errors.Password && (
          <p className="mt-1 text-sm text-red-600">{errors.Password.message}</p>
        )} */}
        <PasswordInput register={register} name="Password" errors={errors} />

        <PasswordStrengthIndicator password={Password} />
      </div>
      <div>
        <Label htmlFor="confirmPassword" className="text-gray-700">
          Confirm Password
        </Label>
        {/* <Input
          id="confirmPassword"
          type="password"
          {...register("ConfirmPassword")}
          className="mt-1 bg-white"
        />
        {errors.ConfirmPassword && (
          <p className="mt-1 text-sm text-red-600">
            {errors.ConfirmPassword.message}
          </p>
        )} */}

        <PasswordInput
          register={register}
          name="ConfirmPassword"
          errors={errors}
        />
      </div>
      <Button
        type="submit"
        disabled={isLoading}
        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
      >
        {isLoading ? "Creating Account..." : "Create account"}
      </Button>
    </form>
  );
};

export type SignUpFormData = z.infer<typeof signUpSchema>;

interface SignUpProps {
  logo: string;
}

interface PasswordStrengthIndicatorProps {
  password: string | undefined;
}

function PasswordStrengthIndicator({
  password,
}: PasswordStrengthIndicatorProps) {
  const [strength, setStrength] = useState(0);

  useEffect(() => {
    const calculateStrength = () => {
      if (!password) {
        setStrength(0);
        return;
      }

      let score = 0;
      if (password.length >= 8) score++;
      if (password.match(/[a-z]/) && password.match(/[A-Z]/)) score++;
      if (password.match(/\d/)) score++;
      if (password.match(/[^a-zA-Z\d]/)) score++;
      setStrength(score);
    };

    calculateStrength();
  }, [password]);

  const getColor = () => {
    switch (strength) {
      case 0:
      case 1:
        return "bg-red-500";
      case 2:
        return "bg-yellow-500";
      case 3:
        return "bg-blue-500";
      case 4:
        return "bg-green-500";
      default:
        return "bg-gray-200";
    }
  };

  return (
    <div className="mt-2">
      <div className="flex h-2 overflow-hidden rounded bg-gray-200">
        <div
          className={`${getColor()} transition-all duration-300 ease-in-out`}
          style={{ width: `${(strength / 4) * 100}%` }}
        ></div>
      </div>
      <p className="mt-1 text-sm text-gray-600">
        {strength === 0 && "Very weak"}
        {strength === 1 && "Weak"}
        {strength === 2 && "Fair"}
        {strength === 3 && "Good"}
        {strength === 4 && "Strong"}
      </p>
    </div>
  );
}

const VerifyAccount = ({ setAuthView }: { setAuthView: SetStateString }) => {
  const token = new URLSearchParams(window.location.search).get("token");
  const [verifyAccount, { isLoading }] = useVerifyAccountMutation();
  const { showSuccessToast, showErrorToast } = useCustomToast();

  const handleVerify = async () => {
    if (!token) return showErrorToast("Invalid verification link.");
    try {
      await verifyAccount({ token }).unwrap();
      showSuccessToast("Account verified successfully! Please log in.");

      const url = new URL(window.location.href);
      url.searchParams.delete("token");
      url.searchParams.delete("view");
      window.history.replaceState({}, document.title, url.toString());

      setAuthView("login");
    } catch (error: any) {
      console.log(error, "ERROR");
      showErrorToast(error?.data?.error || "Verification failed.");
    }
  };

  return (
    <Button
      className="w-full bg-blue-600 hover:bg-blue-700 text-white"
      onClick={handleVerify}
      disabled={isLoading}
    >
      {isLoading ? "Verifying..." : "Verify Account"}
    </Button>
  );
};

const ForgotPassword = ({ setAuthView }: { setAuthView: SetStateString }) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(forgotPasswordSchema),
  });
  const { showSuccessToast, showErrorToast } = useCustomToast();
  const [forgotPassword, { isLoading }] = useForgotPasswordMutation();

  const onSubmit = async (data: { Email: string }) => {
    try {
      await forgotPassword(data).unwrap();
      showSuccessToast("Reset link sent to your email.");
      reset();
      setAuthView("login");
    } catch (error: any) {
      showErrorToast(error?.data?.error || "Error sending reset link.");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <Label>Email Address</Label>
        <Input {...register("Email")} />
        {errors.Email && (
          <p className="mt-1 text-sm text-red-600">{errors.Email.message}</p>
        )}
      </div>

      <Button
        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
        type="submit"
        disabled={isLoading}
      >
        {isLoading ? "Sending..." : "Send Reset Link"}
      </Button>
    </form>
  );
};

const ResetPassword = ({ setAuthView }: { setAuthView: SetStateString }) => {
  const {
    register,
    handleSubmit,
    reset,
    formState: { errors },
  } = useForm({
    resolver: zodResolver(resetPasswordSchema),
  });
  const { showSuccessToast, showErrorToast } = useCustomToast();
  const [resetPassword, { isLoading }] = useResetPasswordMutation();

  const onSubmit = async (data: {
    Password: string;
    ConfirmPassword: string;
  }) => {
    try {
      await resetPassword({ ...data }).unwrap();
      showSuccessToast("Password reset successfully!");
      const url = new URL(window.location.href);
      url.searchParams.delete("view");
      window.history.replaceState({}, document.title, url.toString());
      setAuthView("login");
    } catch (error: any) {
      showErrorToast(error?.data?.error || "Error resetting password.");
    }
  };

  return (
    <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
      <div>
        <Label htmlFor="email" className="text-gray-700">
          Email address
        </Label>
        <Input
          id="email"
          type="email"
          {...register("Email")}
          className="mt-1 bg-white"
        />
        {errors.Email && (
          <p className="mt-1 text-sm text-red-600">{errors.Email.message}</p>
        )}
      </div>
      <div>
        <Label>New Password</Label>
        <PasswordInput register={register} name="Password" errors={errors} />
      </div>

      <div>
        <Label className="mt-4">Confirm Password</Label>
        <PasswordInput
          register={register}
          name="ConfirmPassword"
          errors={errors}
        />
      </div>

      <Button
        className="w-full bg-blue-600 hover:bg-blue-700 text-white"
        type="submit"
        disabled={isLoading}
      >
        {isLoading ? "Resetting..." : "Reset Password"}
      </Button>
    </form>
  );
};

const PasswordInput = ({
  register,
  name,
  errors,
}: {
  register: any;
  name: string;
  errors: any;
}) => {
  const [showPassword, setShowPassword] = useState(false);
  return (
    <div className="relative ">
      <Input
        type={showPassword ? "text" : "password"}
        {...register(name)}
        className="pr-10"
      />
      <button
        type="button"
        className="absolute inset-y-0 right-0 flex items-center px-2"
        onClick={() => setShowPassword((prev) => !prev)}
      >
        {showPassword ? (
          <EyeOff className="h-4 w-4" />
        ) : (
          <Eye className="h-4 w-4" />
        )}
      </button>
      {errors[name] && (
        <p className="mt-1 text-sm text-red-600">{errors[name].message}</p>
      )}
    </div>
  );
};
