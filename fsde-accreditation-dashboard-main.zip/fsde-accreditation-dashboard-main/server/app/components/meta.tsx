import React from "react";
import Head from "next/head";

interface MetaProps {
  title: string;
  description?: string;
  keywords?: string;
  robots?: string;
}

const Meta: React.FC<MetaProps> = ({
  title,
  description,
  keywords,
  robots,
}) => {
  return (
    <Head>
      <title>{title}</title>
      {description && <meta name="description" content={description} />}
      {keywords && <meta name="keywords" content={keywords} />}
      {robots && <meta name="robots" content={robots} />}
    </Head>
  );
};

export default Meta;
