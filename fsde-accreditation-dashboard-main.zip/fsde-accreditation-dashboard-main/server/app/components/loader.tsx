import React from "react";
import { Spinner } from "./ui/spinner";

const Loader = ({ message }: { message?: string }) => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[200px]">
      <Spinner className="w-10 h-10 animate-spin text-blue-500" />
      {message && <p className="mt-2 text-gray-600">{message}</p>}
    </div>
  );
};

export default Loader;
