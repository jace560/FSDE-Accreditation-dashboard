"use client";

import * as React from "react";
import {
  LayoutDashboard,
  BookOpen,
  Settings,
  User,
  LogIn,
  LogOut,
} from "lucide-react";
import { ROUTES } from "../../utils";
import {
  Sidebar,
  SidebarContent,
  SidebarGroup,
  SidebarGroupContent,
  SidebarHeader,
  SidebarMenu,
  SidebarMenuButton,
  SidebarMenuItem,
  SidebarRail,
  SidebarFooter,
} from "./ui/sidebar";
import Link from "next/link";
import { usePathname } from "next/navigation";
import Image from "next/image";
import logo from "../../assets/app-logo.png";
import { Separator } from "./ui/separator";
import { signOut } from "next-auth/react";
import { useRouter } from "next/navigation";
import { useAuth } from "@/hooks/custom/use-auth";
import { useCustomToast } from "@/hooks/custom/use-custom-toast";
const iconMap = {
  LayoutDashboard,
  BookOpen,
  Settings,
  User,
  LogIn,
};

const LucideIcon: React.FC<{
  name: keyof typeof iconMap;
  [key: string]: any;
}> = ({ name, ...props }) => {
  const Icon = iconMap[name];
  return Icon ? <Icon {...props} /> : null;
};

export function AppSidebar() {
  const [selectedVersion, setSelectedVersion] = React.useState("1.0.0");
  const [isLoggedIn, setIsLoggedIn] = React.useState(true);
  const router = useRouter();
  const { isAdmin } = useAuth();
  const { showSuccessToast } = useCustomToast();

  const pathname = usePathname();
  const logOut = () => {
    showSuccessToast("You have been logged out successfully.");
    setTimeout(() => {
      signOut({ callbackUrl: "/" });
    }, 500);
  };

  const menuItems = [
    {
      title: "Dashboard",
      icon: "LayoutDashboard" as const,
      path: ROUTES.USER_DASHBOARD,
    },
    { title: "Courses", icon: "BookOpen" as const, path: ROUTES.COURSES },
    { title: "Admin", icon: "Settings" as const, path: ROUTES.ADMIN },
  ];

  return (
    <Sidebar>
      <SidebarHeader className="p-4">
        <Link href={ROUTES.USER_DASHBOARD} prefetch={false}>
          <Image
            src={logo}
            alt="Curriculum Accreditation Dashboard Logo"
            width={300}
            height={300}
          />
        </Link>
      </SidebarHeader>

      <SidebarContent>
        <SidebarGroup>
          <SidebarGroupContent>
            <SidebarMenu>
              {menuItems
                .filter((item) => !(item.path === ROUTES.ADMIN && !isAdmin))
                .map((item) => (
                  <SidebarMenuItem
                    key={item.title}
                    className={
                      pathname === item.path
                        ? "text-primary hover:text-primary"
                        : "hover:text-primary"
                    }
                  >
                    <SidebarMenuButton asChild>
                      <Link
                        href={item.path}
                        className="flex items-center gap-3"
                      >
                        <LucideIcon name={item.icon} className="h-4 w-4" />
                        <span className="text-xs">{item.title}</span>
                      </Link>
                    </SidebarMenuButton>
                  </SidebarMenuItem>
                ))}
            </SidebarMenu>
          </SidebarGroupContent>
        </SidebarGroup>
      </SidebarContent>

      <SidebarFooter>
        <SidebarMenu>
          <SidebarMenuItem>
            <SidebarMenuButton
              className="cursor-pointer"
              onClick={logOut}
              asChild
            >
              <div className="flex items-center gap-3">
                <LogOut className="h-4 w-4" />
                <span className="text-xs">Log Out</span>
              </div>
            </SidebarMenuButton>
          </SidebarMenuItem>
        </SidebarMenu>
      </SidebarFooter>

      <SidebarRail />
    </Sidebar>
  );
}
