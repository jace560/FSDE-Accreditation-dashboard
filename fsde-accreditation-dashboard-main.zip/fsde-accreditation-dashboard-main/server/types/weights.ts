export type ATLOContribution = {
  ATID: string;
  contribution: number;
};

export type ATLONormalizedWeight = {
  ATID: string;
  weight: number;
};

export type ATLOWeightsByLO = {
  [LOID: string]: {
    totalWeight: number;
    atWeights: ATLOContribution[];
  };
};

export type NormalizedATLOWeightsByLO = {
  [LOID: string]: ATLONormalizedWeight[];
};

export type StudentLOGrades = Record<string, number>;

export type AllStudentLOGrades = Record<string, StudentLOGrades>;

export type LODistributionCountsWithPercentages = {
  LOID: string; // ID of the Learning Objective
  LOName: string; // Name of the Learning Objective
  exceeds: number; // Students scoring >= 80%
  exceedsPercentage: number; // Percentage of students scoring >= 80%
  acceptable: number; // Students scoring >= 65%
  acceptablePercentage: number; // Percentage of students scoring >= 65%
  marginal: number; // Students scoring >= 50%
  marginalPercentage: number; // Percentage of students scoring >= 50%
  fail: number; // Students scoring < 50%
  failPercentage: number; // Percentage of students scoring < 50%
  total: number; // Total students assessed for the LO
};
// Type for the complete distribution of all LOs
export type AllLODistributionsWithPercentages = Record<
  string,
  LODistributionCountsWithPercentages
>;
