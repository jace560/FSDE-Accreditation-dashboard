import NextAuth, { DefaultSession, DefaultUser } from "next-auth";

export type User = {
  UserID?: string;
  FirstName: string;
  LastName: string;
  FullName: string;
  Email: string;
  Role: string;
  Initials: string;
  Status: string;
};

export type Token = User & {
  exp?: number;
  iat?: number;
};

declare module "next-auth" {
  interface Session {
    user: User & DefaultSession["user"];
  }
}
