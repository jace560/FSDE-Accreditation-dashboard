import { MappingVersionResponse } from "@/lib/api/generic";
import { Course, Prisma } from "@prisma/client";
import { LODistributionCountsWithPercentages } from "./weights";
import { CourseLevelColor, PILevelColor } from "@/utils";
import { Value } from "@radix-ui/react-select";

export type ProgramWithRelations = Prisma.ProgramGetPayload<{
  include: {
    Campuses: {
      include: {
        Campus: {
          select: {
            CampusID: true;
            CampusName: true;
          };
        };
      };
    };
  };
}>;

export type ApiResponse<T> = {
  data?: T;
  error?: {
    message: string;
    status: number;
  };
};

type CourseWithCampusName = Prisma.CourseGetPayload<{
  select: {
    CourseID: true;
    CourseCode: true;
    CourseName: true;
    SectionNumber: true;
    Year: true;
    SemesterName: true;
    Campus: {
      select: {
        CampusName: true;
        CampusID: true;
      };
    };
  };
}>;

export type CoursesPageProps = {
  programs: ProgramWithRelations[];
  initialCourses: GetCoursesResponse;
  uniqueYears: string[];
};

export type GetCoursesQuery = {
  programId?: string;
  campusId?: string;
  year?: string;
  semester?: string;
  page?: string;
  limit?: string;
  courseNameQuery?: string;
};

export type GetCourseMappingQuery = {
  mappingVersion?: string;
};

export type GetCoursesResponse = {
  data: CourseWithCampusName[];
  meta: {
    total: number;
    page: number;
    totalPages: number;
    limit: number;
  };
};

export enum PILevel {
  Introduce = "I",
  Develop = "D",
  Apply = "A",
}

export enum Semester {
  Fall = "Fall",
  Winter = "Winter",
  Summer = "Summer",
}

export type AssessmentTools = {
  ATID?: string;
  ATName: string;
  Weight: number;
  Description: string;
  AssessmentToolLearningObjectiveMappings: AssessmentToolLearningObjectiveMapping[];
};

export type LearningObjective = {
  LOID?: string;
  LOName: string;
  LODescription?: string;
  LearningObjectivePerformanceIndicatorMappings: LearningObjectivePerformanceIndicatorMapping[];
};

export type AssessmentToolLearningObjectiveMapping = {
  Weight: number;
  LOName: string;
};

export type LearningObjectivePerformanceIndicatorMapping = {
  PIName: string; // 2A, 5D, .etc
};

export type CourseCreateInput = {
  CourseCode: string;
  CourseName: string;
  SemesterName: string;
  SectionNumber: number;
  Year: string;
  AssessmentTools: AssessmentTools[];
  LearningObjectives: LearningObjective[];
};

// CIS holds all information needed to create db entrees for Course, LearningObjective, AssessmentTool, AssessmentToolLearningObjectiveMapping, and LearningObjectivePerformanceIndicatorMapping
export type CourseInformationSheet = {
  Course: CourseCreateInput;
  ProgramID: string;
  CampusID: string;
};

export type CourseInformationSheetDto = {
  courseInformationSheets: CourseInformationSheet[];
};

export type GetCourseDetailsQuery = {
  courseID: string;
  mappingVersion: string;
};
export type GetCourseDetailsParamsQuery = {
  params: GetCourseDetailsQuery;
};

export type GetCourseDetailsResponseDto = {
  LearningObjectives: LearningObjective[];
  AssessmentTools: AssessmentTools[];
};

export type PILevelType = `${PILevel}`; // "I" | "A" | "D"

export type SemesterType = `${Semester}`; // "Winter" | "Summer" | "Fall" | "Spring"

export type CourseDetailsDto = {
  course: Course;
  mappingVersions: MappingVersionResponse[]; // All mapping versions
  loDistribution?: LODistributionCountsWithPercentages[]; // Empty if no grades
  programId: string;
};

export type UpdateCourseInformationDto = {
  courseId: string;
  courseInformationSheet: CourseInformationSheet;
};

export type StudentGrade = {
  StudentIdentifier: string;
  Grades: {
    ATName: string;
    GradePercentage: number;
  }[];
};

export type GradeRequestDto = {
  courseID: string;
  programID: string;
  campusID: string;
  studentGradeSheet: StudentGrade[];
};

export type SetStateBoolean = React.Dispatch<React.SetStateAction<boolean>>;

export type SetStateString = React.Dispatch<React.SetStateAction<string>>;

export enum ChartType {
  GA_BY_COURSE_LEVEL = "GA_BY_COURSE_LEVEL",
  GA_BY_IDA = "GA_BY_IDA",
  GA_BY_COURSE_AND_IDA = "GA_BY_COURSE_AND_IDA",
  COURSE_LEVEL_COMBINING_ALL_GA = "COURSE_LEVEL_COMBINING_ALL_GA",
  IDA_LEVEL_COMBINING_ALL_GA = "IDA_LEVEL_COMBINING_ALL_GA",
  BY_GA_AND_BY_COURSE_LEVEL = "BY_GA_AND_BY_COURSE_LEVEL",
  BY_GA_AND_BY_IDA_LEVEL = "BY_GA_AND_BY_IDA_LEVEL",
  GA_COURSE_PI_MAPPING = "GA_COURSE_PI_MAPPING",
  EXCEL_SHEET = "EXCEL_SHEET",
}

export const ChartTypesLabel = [
  { value: "GA_BY_IDA", label: "GA by IDA Level" },
  { value: "GA_BY_COURSE_LEVEL", label: "GA by Course Level" },
  { value: "GA_BY_COURSE_AND_IDA", label: "GA by Course Level and IDA" },
  {
    value: "COURSE_LEVEL_COMBINING_ALL_GA",
    label: "Course Level Combining All GA",
  },
  {
    value: "IDA_LEVEL_COMBINING_ALL_GA",
    label: " IDA Level Combining All GA",
  },
  {
    value: "BY_GA_AND_BY_COURSE_LEVEL",
    label: "By GA and By Course Level",
  },
  {
    value: "BY_GA_AND_BY_IDA_LEVEL",
    label: "By GA and By IDA Level",
  },
  {
    value: "EXCEL_SHEET",
    label: "Excel Sheets",
  },
];

export type ChartLabels = {
  xAxisLabel: string;
  yAxisLabel: string;
  mainTitle: string;
};

export type Chart = {
  type: ChartType;
  labels: ChartLabels;
  data: ChartDataType;
  color?: typeof PerformanceColors | PILevelColor | CourseLevelColor;
};

export type ChartQueryParams = {
  programId: string;
  campusId: string;
  chartType?: ChartType | string;
  year?: string;
  semester?: string;
  graduateAttribute?: string;
};

export type ChartDataReturnDto = Chart;

export type SelectType = {
  value: string;
  label: string;
};

export const PerformanceColors = {
  Exceeds: "#008000",
  Acceptable: "#8BC34A",
  Marginal: "#FFD700",
  Fail: "#FF0000",
} as const;

export type PerformanceCategory = {
  category: "Exceeds" | "Acceptable" | "Marginal" | "Fail";
  percentage: number;
};

export type ChartDataType =
  | GAChartData[]
  | GA_LO_Distribution
  | COURSE_LEVEL_BY_GA_LO_DISTRIBUTION[]
  | IDA_LEVEL_COMBINING_ALL_GA[]
  | BY_GA_BY_COURSE_LEVEL[]
  | BY_GA_BY_IDA_LEVEL[];

export type BY_GA_BY_COURSE_LEVEL = {
  gaName: string;
  courseLevelPerformance: COURSE_LEVEL_BY_GA_LO_DISTRIBUTION[];
};

export type BY_GA_BY_IDA_LEVEL = {
  gaName: string;
  IDALevelPerformance: IDA_LEVEL_BY_GA_LO_DISTRIBUTION[];
};
export type COURSE_LEVEL_BY_GA_LO_DISTRIBUTION = PerformanceDistribution & {
  CourseLevel: string;
};

export type IDA_LEVEL_BY_GA_LO_DISTRIBUTION = PerformanceDistribution & {
  IDALevel: string;
};

export type IDA_LEVEL_COMBINING_ALL_GA = PerformanceDistribution & {
  IDALevel: string;
};

export type GAChartData = {
  graduateAttribute: string;
  GAID: string;
  values: {
    label: string; // Category label (e.g., "I", "D", "A" for PI or "1000", "2000" for Course Level)
    count: number;
    color: CourseLevelColor | PILevelColor; // Hex or RGB color passed from backend
  }[];
};

export type CourseLOPerformance = {
  courseID: string;
  courseCode: string;
  performance: PerformanceCategory[];
  coursePILevel?: PILevelType;
};

export type GA_LO_Distribution = {
  graduateAttribute: string;
  GAID: string;
  colors: typeof PerformanceColors;
  courses: CourseLOPerformance[];
};

export type PerformanceDistribution = {
  Exceeds: number;
  Acceptable: number;
  Marginal: number;
  Fail: number;
};

export type PerformanceLevels = {
  Exceeds: 0;
  Acceptable: 0;
  Marginal: 0;
  Fail: 0;
  total: 0;
};

export type User = {
  UserID?: string;
  FirstName: string;
  LastName: string;
  FullName: string;
  Email: string;
  Role: string;
  Initials: string;
  Status: string;
};

export type UsersReturnDto = {
  Users: User[];
  meta: {
    totalUsers: number;
    page: number;
    totalPages: number;
    limit: number;
  };
};

export type GetUsersQuery = {
  page?: string;
  limit?: string;
  role?: string;
  nameSearchQuery?: string;
};

export enum USER_ROLE {
  USER = "USER",
  ADMIN = "ADMIN",
  SUPER_ADMIN = "SUPER_ADMIN",
}

export const USER_ROLE_OPTIONS = [
  {
    value: "USER",
    label: "User",
  },
  {
    value: "ADMIN",
    label: "Admin",
  },
  {
    value: "SUPER_ADMIN",
    label: "Super Admin",
  },
];

export const USER_STATUS_OPTIONS = [
  {
    value: "UNAUTHENTICATED",
    label: "Unauthenticated",
  },
  {
    value: "ACTIVE",
    label: "Active",
  },
  {
    value: "BLOCKED",
    label: "Blocked",
  },
];

export enum USER_STATUS {
  ACTIVE = "ACTIVE",
  BLOCKED = "BLOCKED",
  UNAUTHENTICATED = "UNAUTHENTICATED",
}

export type ROLE_TYPE = `${USER_ROLE}`;

export type STATUS_TYPE = `${USER_STATUS}`;

export type ThresholdNameType = "Exceed" | "Acceptable" | "Marginal" | "Fail";

export type Threshold = {
  thresholdName: ThresholdNameType;
  thresholdValue: number;
};

export type ThresholdUpdateRequest = {
  thresholds: Threshold[];
};
export type updateUserRoleDto = {
  userID: string;
  role: ROLE_TYPE;
};

export type updateStatusRoleDto = {
  userID: string;
  status: STATUS_TYPE;
};

export type VerifyAccountDto = {
  token: string;
};

export type ForgotPasswordDto = {
  Email: string;
};

export type ResetPasswordDto = {
  Password: string;
  ConfirmPassword: string;
  // token: string;
};

export type AuthResponseDto = {
  success: boolean;
  message: string;
};
