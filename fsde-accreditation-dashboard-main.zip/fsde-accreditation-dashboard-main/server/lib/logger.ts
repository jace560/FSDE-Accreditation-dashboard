import { createLogger, format, transports } from "winston";
import path from "path";

const logDir = "/tmp"; // Change the log directory to /tmp

const logger = createLogger({
  level: "info",
  format: format.combine(
    format.timestamp({ format: "YYYY-MM-DD HH:mm:ss" }),
    format.printf(({ timestamp, level, message }) => {
      return `[${timestamp}] ${level.toUpperCase()}: ${message}`;
    })
  ),
  transports: [
    new transports.Console(), // Logs to console (visible in Vercel logs)
    new transports.File({
      filename: path.join(logDir, "error.log"),
      level: "error",
    }), // Logs errors in /tmp/
    new transports.File({ filename: path.join(logDir, "combined.log") }), // Logs everything in /tmp/
  ],
});

export default logger;
