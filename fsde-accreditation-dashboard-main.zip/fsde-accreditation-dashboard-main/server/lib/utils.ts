import { clsx, type ClassValue } from "clsx";
import { twMerge } from "tailwind-merge";

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

import { NextApiResponse } from "next";

export function successResponse(
  res: NextApiResponse,
  data: any,
  statusCode = 200
): void {
  res.status(statusCode).json({
    success: true,
    data,
  });
}

export function errorResponse(
  res: NextApiResponse,
  message: string,
  statusCode = 500
): void {
  res.status(statusCode).json({
    success: false,
    error: message,
  });
}
