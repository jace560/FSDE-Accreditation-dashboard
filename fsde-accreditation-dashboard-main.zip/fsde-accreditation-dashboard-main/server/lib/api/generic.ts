import {
  CourseDetailsDto,
  GetCoursesResponse,
  ProgramWithRelations,
  SelectType,
} from "@/types";
import logger from "../logger";
import prisma from "../prisma";
import { LODistributionCountsWithPercentages } from "@/types/weights";
import { Course, Prisma } from "@prisma/client";
import { Label } from "recharts";
import {
  AllLODistributionsWithPercentages,
  AllStudentLOGrades,
  ATLOContribution,
  ATLOWeightsByLO,
  NormalizedATLOWeightsByLO,
} from "@/types/weights";
const baseUrl = process.env.NEXT_PUBLIC_BASE_URL || "http://localhost:3000";
export const fetchPrograms = async (): Promise<ProgramWithRelations[]> => {
  const programs = await prisma.program.findMany({
    include: {
      Campuses: {
        include: {
          Campus: {
            select: {
              CampusID: true,
              CampusName: true,
            },
          },
        },
      },
    },
    orderBy: {
      ProgramName: "asc",
    },
  });

  return programs;
};

export const getUniqueYears = async (): Promise<string[]> => {
  try {
    logger.info("Fetching unique years started.");
    const uniqueYears = await prisma.course.findMany({
      distinct: ["Year"],
      select: {
        Year: true,
      },
      orderBy: {
        Year: "desc",
      },
    });
    console.log(uniqueYears, "uniqueYears");
    logger.info(`Fetching unique years completed.`, { uniqueYears });

    return uniqueYears.map((course) => course.Year);
  } catch (error: any) {
    logger.error("Error fetching unique years", error);
    return ["Data"];
  }
};

export type MappingVersionResponse = {
  IsCurrent: boolean;
  MappingVersion: string;
};

export const getUniqueMappingVersion = async (
  courseId: string
): Promise<MappingVersionResponse[]> => {
  try {
    logger.info(`Fetching unique mapping versions for course ID: ${courseId}`);

    const mappingVersions = await prisma.learningObjective.findMany({
      where: {
        CourseID: courseId,
      },
      select: {
        MappingVersion: true,
        IsCurrent: true,
      },
      distinct: ["MappingVersion"],
    });

    logger.info(
      `Successfully fetched ${mappingVersions.length} unique mapping version(s) for course ID: ${courseId}`
    );

    const mappingVersionsResult: MappingVersionResponse[] = mappingVersions.map(
      (item) => ({
        MappingVersion: item.MappingVersion,
        IsCurrent: item.IsCurrent,
      })
    );

    return mappingVersionsResult;
  } catch (error) {
    logger.error("Error fetching unique mapping versions", error);
    throw new Error("Failed to fetch unique mapping versions.");
  }
};

export const fetchInitialCourses = async (): Promise<GetCoursesResponse> => {
  const page = 1;
  const limit = 10;
  const offset = (page - 1) * limit;

  try {
    const courses = await prisma.course.findMany({
      select: {
        CourseID: true,
        CourseCode: true,
        CourseName: true,
        Year: true,
        SemesterName: true,
        SectionNumber: true,
        Campus: {
          select: {
            CampusName: true,
            CampusID: true,
          },
        },
      },
      orderBy: [
        { Year: "desc" },
        { SemesterName: "asc" },
        { CourseName: "asc" },
        { SectionNumber: "asc" },
      ],
      skip: offset,
      take: limit,
    });

    const totalCourses = await prisma.course.count();

    const totalPages = Math.ceil(totalCourses / limit);

    return {
      data: courses,
      meta: {
        total: totalCourses,
        page,
        totalPages,
        limit,
      },
    };
  } catch (error) {
    console.error("Error fetching courses:", error);
    throw new Error("Failed to fetch initial courses");
  }
};

export async function getCourseDetailsWithLODistribution(
  courseId: string
): Promise<CourseDetailsDto> {
  try {
    // Step 1: Get Course Details and Mapping Versions
    logger.info(
      `Fetching details and mapping versions for course ID: ${courseId}`
    );
    const course = await prisma.course.findUnique({
      where: { CourseID: courseId },
      select: {
        CourseName: true,
        CourseID: true,
        CourseCode: true,
        SemesterName: true,
        Year: true,
        SectionNumber: true,
        CampusID: true,
        LearningObjectives: {
          select: {
            MappingVersion: true,
            IsCurrent: true,
          },
          distinct: ["MappingVersion"],
        },
        Campus: {
          select: {
            Programs: {
              select: {
                Program: {
                  select: {
                    ProgramID: true,
                    ProgramName: true,
                  },
                },
              },
            },
          },
        },
      },
    });

    const programId = course?.Campus?.Programs?.[0]?.Program.ProgramID;

    if (!course) {
      logger.error(`Course not found for ID: ${courseId}`);
      throw new Error("Course not found.");
    }

    const {
      CourseName,
      CourseCode,
      SemesterName,
      Year,
      SectionNumber,
      LearningObjectives,
      CampusID,
      CourseID,
    } = course;

    const mappingVersions: MappingVersionResponse[] = LearningObjectives.map(
      (lo) => ({
        MappingVersion: lo.MappingVersion,
        IsCurrent: lo.IsCurrent,
      })
    );

    logger.info(
      `Fetched ${mappingVersions.length} mapping version(s) for course ID: ${courseId}`
    );

    // Step 2: Get the latest mapping version using `IsCurrent`
    const latestMappingVersion = mappingVersions.find((mv) => mv.IsCurrent);

    if (!latestMappingVersion) {
      logger.info(
        `No current mapping version found for course ID: ${courseId}. Returning an empty LO distribution.`
      );
      return {
        course: {
          CourseName: CourseName,
          CourseCode: CourseCode,
          SemesterName: SemesterName,
          CourseID: CourseID,
          Year: Year,
          CampusID: CampusID,
          SectionNumber: SectionNumber,
        },
        mappingVersions,
        programId: programId as string,
        loDistribution: [],
      };
    }

    logger.info(
      `Latest mapping version for course ID: ${courseId} is ${latestMappingVersion.MappingVersion}`
    );

    // Step 3: Check if grades exist for the course
    logger.info(`Checking if grades exist for course ID: ${courseId}`);
    const gradesCount = await prisma.grade.count({
      where: { CourseID: courseId },
    });

    if (gradesCount === 0) {
      logger.info(
        `No grades found for course ID: ${courseId}. Returning an empty LO distribution.`
      );
      return {
        course: {
          CourseName: CourseName,
          CourseCode: CourseCode,
          SemesterName: SemesterName,
          CourseID: CourseID,
          Year: Year,
          CampusID: CampusID,
          SectionNumber: SectionNumber,
        },
        programId: programId as string,
        mappingVersions,
        loDistribution: [],
      };
    }

    // Step 4: Fetch LO distribution from the API
    // logger.info(
    //   `Fetching LO distribution for course ID: ${courseId} using API with mapping version: ${latestMappingVersion.MappingVersion}`
    // );
    // const response = await fetch(
    //   `${baseUrl}/api/courses/${courseId}/lo-performance?mappingVersion=${latestMappingVersion.MappingVersion}`
    // );

    // if (!response.ok) {
    //   logger.error(
    //     `API request failed for course ID: ${courseId} and mapping version: ${latestMappingVersion.MappingVersion}`
    //   );
    //   throw new Error("Failed to fetch LO distribution from API.");
    // }

    // const loDistribution: LODistributionCountsWithPercentages[] =
    //   await response.json();

    // logger.info(
    //   `Successfully fetched LO distribution for course ID: ${courseId} with ${loDistribution.length} items.`
    // );

    // Step 5: Return course details, mapping versions, and LO distribution
    return {
      course: {
        CourseName: CourseName,
        CourseCode: CourseCode,
        SemesterName: SemesterName,
        CourseID: CourseID,
        Year: Year,
        CampusID: CampusID,
        SectionNumber: SectionNumber,
      },
      programId: programId as string,
      mappingVersions,
      // loDistribution,
    };
  } catch (error) {
    logger.error("Error in getCourseDetailsWithLODistribution function", error);
    throw new Error("Failed to retrieve course details and LO distribution.");
  }
}

export const fetchGraduateAttributes = async (): Promise<
  SelectType[] | undefined
> => {
  try {
    logger.error("fetching graduate attributes...");
    const graduateAttributes = await prisma.graduateAttribute.findMany({
      select: {
        GAID: true,
        GAName: true,
      },
    });

    return graduateAttributes.map((graduateAttribute) => ({
      value: graduateAttribute.GAID,
      label: graduateAttribute.GAName,
    }));
  } catch (error: any) {
    logger.error("Error getting graduate attributes...", error);
    throw new Error("Error getting graduate attributes...");
  }
};

export async function calculateATLOWeights(
  courseID: string,
  mappingVersion: string
): Promise<NormalizedATLOWeightsByLO> {
  try {
    // Step 1: Fetch all AT-LO mappings for the course and matching MappingVersion
    console.log(mappingVersion, courseID, "COURSEID MAPPING VERSION");
    const mappings =
      await prisma.assessmentToolLearningObjectiveMapping.findMany({
        where: {
          CourseID: courseID,
          AssessmentTool: {
            MappingVersion: mappingVersion, // Filter by MappingVersion
          },
        },
        include: {
          AssessmentTool: true, // To get AT weights
        },
      });
    // Step 2: Group mappings by LO
    const loWeights: ATLOWeightsByLO = {};

    mappings.forEach((mapping) => {
      const { LOID, ATID, Weight: mappingWeight, AssessmentTool } = mapping;
      const atWeight = AssessmentTool.Weight;

      // Initialize LO entry if it doesn't exist
      if (!loWeights[LOID]) {
        loWeights[LOID] = { totalWeight: 0, atWeights: [] };
      }

      // Calculate contribution for this AT-LO pair
      const contribution = atWeight * mappingWeight;

      // Add contribution to the LO's total
      loWeights[LOID].totalWeight += contribution;

      // Save the individual AT-LO contribution
      loWeights[LOID].atWeights.push({ ATID, contribution });
    });

    // Step 3: Normalize weights for each LO
    const normalizedWeights: NormalizedATLOWeightsByLO = {};

    Object.entries(loWeights).forEach(([loid, { totalWeight, atWeights }]) => {
      normalizedWeights[loid] = atWeights.map(
        ({ ATID, contribution }: ATLOContribution) => ({
          ATID,
          weight: contribution / totalWeight, // Normalize contribution
        })
      );
    });

    return normalizedWeights; // Returns weights grouped by LO
  } catch (error) {
    console.error("Error calculating AT-LO weights:", error);
    throw error;
  }
}

export async function calculateStudentGradesUnderLO(
  courseID: string,
  mappingVersion: string
): Promise<AllStudentLOGrades> {
  try {
    // Step 1: Fetch AT-LO weights
    const atLOWeights = await calculateATLOWeights(courseID, mappingVersion);

    // Step 2: Fetch student grades along with AT weights
    const studentGrades = await prisma.grade.findMany({
      where: { CourseID: courseID },
      include: {
        AssessmentTool: { select: { Weight: true } }, // Fetch AT weight from the AssessmentTool model
      },
    });

    // Step 3: Initialize LO grades
    const loGrades: AllStudentLOGrades = {}; // { StudentID: { LOID: Grade } }

    // Step 4: Apply the formula for each LO
    studentGrades.forEach((grade) => {
      const studentID = grade.StudentIdentifier;
      const atID = grade.ATID;
      const atGrade = grade.GradePercentage; // Raw grade for the AT
      const atWeight = grade.AssessmentTool.Weight; // Weight of the AT in the course

      Object.entries(atLOWeights).forEach(([loID, atWeights]) => {
        const atLOWeight = atWeights.find((weight) => weight.ATID === atID);

        if (atLOWeight) {
          // Skip if the AT weight is zero
          if (atWeight === 0) return;

          // Apply the formula:
          const contribution = ((atGrade * atLOWeight.weight) / atWeight) * 100;

          // Initialize student's LO entry if not already present
          if (!loGrades[studentID]) loGrades[studentID] = {};
          if (!loGrades[studentID][loID]) loGrades[studentID][loID] = 0;

          // Add the contribution to the LO grade
          loGrades[studentID][loID] += contribution;
        }
      });
    });

    return loGrades;
  } catch (error) {
    console.error("Error calculating student grades under LOs:", error);
    throw error;
  }
}

export async function calculateLODistributionWithPercentages(
  studentLOGrades: AllStudentLOGrades
): Promise<AllLODistributionsWithPercentages> {
  // Initialize the distribution
  const loDistribution: AllLODistributionsWithPercentages = {};

  if (!studentLOGrades || Object.keys(studentLOGrades).length === 0) {
    return {};
  }

  // Fetch all LO details (LOID and LOName) to map LOIDs to LOName
  const allLOs = await prisma.learningObjective.findMany({
    where: {
      LOID: {
        in: Object.keys(studentLOGrades[Object.keys(studentLOGrades)[0]]), // Only fetch LOs that exist in the grades
      },
    },
    select: {
      LOID: true,
      LOName: true,
    },
  });

  // Create a map of LOID to LOName
  const loMap = allLOs.reduce((acc, lo) => {
    acc[lo.LOID] = lo.LOName;
    return acc;
  }, {} as Record<string, string>);

  console.log(studentLOGrades, "STUDENTLOGARDES");

  // Iterate through all student grades
  Object.values(studentLOGrades).forEach((studentGrades) => {
    Object.entries(studentGrades).forEach(([loID, grade]) => {
      // Initialize LO distribution if not already present
      if (!loDistribution[loID]) {
        loDistribution[loID] = {
          LOID: loID,
          LOName: loMap[loID] || "Unknown LO", // Map LOID to LOName
          exceeds: 0,
          exceedsPercentage: 0,
          acceptable: 0,
          acceptablePercentage: 0,
          marginal: 0,
          marginalPercentage: 0,
          fail: 0,
          failPercentage: 0,
          total: 0,
        };
      }

      // Categorize the grade
      if (grade >= 80) {
        loDistribution[loID].exceeds += 1;
      } else if (grade >= 65) {
        loDistribution[loID].acceptable += 1;
      } else if (grade >= 50) {
        loDistribution[loID].marginal += 1;
      } else {
        loDistribution[loID].fail += 1;
      }

      // Increment total count
      loDistribution[loID].total += 1;
    });
  });

  // Calculate percentages for each LO
  Object.values(loDistribution).forEach((counts) => {
    if (counts.total > 0) {
      counts.exceedsPercentage = (counts.exceeds / counts.total) * 100;
      counts.acceptablePercentage = (counts.acceptable / counts.total) * 100;
      counts.marginalPercentage = (counts.marginal / counts.total) * 100;
      counts.failPercentage = (counts.fail / counts.total) * 100;
    }
  });

  return loDistribution;
}
