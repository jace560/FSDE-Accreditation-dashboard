export class ApiError extends Error {
  statusCode: number;

  constructor(message: string, statusCode: number, cause?: unknown) {
    super(message);
    this.statusCode = statusCode;

    if (cause) {
      (this as any).cause = cause;
    }

    Object.setPrototypeOf(this, new.target.prototype);
  }
}
