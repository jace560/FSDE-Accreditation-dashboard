"use server";
import { Resend } from "resend";

const NEXT_RESEND_API_KEY = process.env.NEXT_RESEND_API_KEY;
console.log("API Key from .env:", NEXT_RESEND_API_KEY);

export async function sendVerificationEmail(
  email: string,
  verificationLink: string
) {
  try {
    const resend = new Resend(
      NEXT_RESEND_API_KEY || "re_b4HZNrV9_LmdSVP637LZHLDgLhYysWUfK"
    );
    await resend.emails.send({
      from: "onramp@resend.dev",
      to: email,
      subject: "Verify Your Email - Welcome to Our Platform!",
      html: `
      <div style="font-family: Arial, sans-serif; max-width: 600px; margin: auto; padding: 20px; background: #f9f9f9; border-radius: 8px; text-align: center;">
        <h2 style="color: #333;">Welcome to Our Platform! 🎉</h2>
        <p style="color: #555; font-size: 16px;">
          You're almost there! Click the button below to verify your email and activate your account.
        </p>
        <a href="${verificationLink}" 
          style="display: inline-block; background-color: #007bff; color: #ffffff; text-decoration: none; padding: 12px 20px; font-size: 16px; border-radius: 5px; margin: 20px 0; font-weight: bold;">
          Verify My Email
        </a>
        <p style="color: #777; font-size: 14px;">
          If you didn’t request this, you can safely ignore this email.
        </p>
        <hr style="border: none; border-top: 1px solid #ddd; margin: 20px 0;">
        <p style="color: #999; font-size: 12px;">
          Need help? Contact our support team at 
          <a href="mailto:support@yourdomain.com" style="color: #007bff;">support@yourdomain.com</a>.
        </p>
      </div>
      `,
    });
  } catch (error) {
    console.error("❌ Error sending verification email:", error);
  }
}
