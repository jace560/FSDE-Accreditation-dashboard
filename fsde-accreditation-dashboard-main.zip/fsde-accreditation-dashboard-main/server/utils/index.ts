import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";

export const ROUTES = {
  DASHBOARD: "/analytics",
  COURSES: "/courses",
  ADMIN: "/admin",
  USER_DASHBOARD: "/dashboard",
};

export const UUID_REGEX =
  /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

export enum PILevelColor {
  I = "#4F81BD",
  D = "#C0504D",
  A = "#9BBB59",
}

export const colors = {
  Exceeds: "#008000",
  Acceptable: "#8BC34A",
  Marginal: "#FFD700",
  Fail: "#FF0000",
};

export enum CourseLevelColor {
  LEVEL_1000 = "#4F81BD",
  LEVEL_2000 = "#C0504D",
  LEVEL_3000 = "#9BBB59",
  LEVEL_4000 = "#8064A2",
}

export const loginSchema = z.object({
  Email: z.string().email("Invalid email address"),
  Password: z.string().min(8, "Password must be at least 8 characters"),
});

export const signUpSchema = z
  .object({
    FirstName: z.string().min(2, "First name must be at least 2 characters"),
    LastName: z.string().min(2, "Last name must be at least 2 characters"),
    Email: z.string().email("Invalid email address"),
    Password: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .regex(
        /^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$/,
        "Password must contain at least one uppercase letter, one lowercase letter, one number, and one special character"
      ),
    ConfirmPassword: z.string(),
  })
  .refine((data) => data.Password === data.ConfirmPassword, {
    message: "Passwords don't match",
    path: ["confirmPassword"],
  });

export const GradeSchema = z.object({
  StudentIdentifier: z.string().regex(UUID_REGEX, "Invalid UUID format"),
  Grades: z.array(
    z.object({
      ATName: z.string().min(2, "Assessment Tool Name is required"),
      GradePercentage: z.number().min(0, "Grade must be a number"),
    })
  ),
});

export const GradeRequestSchema = z.object({
  programID: z.string().regex(UUID_REGEX, "Invalid UUID format"),
  courseID: z.string().regex(UUID_REGEX, "Invalid UUID format"),
  campusID: z.string().regex(UUID_REGEX, "Invalid UUID format"),
  studentGradeSheet: z
    .array(GradeSchema)
    .min(1, "Grades array cannot be empty"),
});

export function isValidUUID(uuid: string): boolean {
  const uuidRegex =
    /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;
  return uuidRegex.test(uuid);
}

export const resetPasswordSchema = z
  .object({
    Email: z.string().email("Invalid email address"),
    Password: z
      .string()
      .min(8, "Password must be at least 8 characters")
      .regex(/[A-Z]/, "Password must contain at least one uppercase letter")
      .regex(/[a-z]/, "Password must contain at least one lowercase letter")
      .regex(/[0-9]/, "Password must contain at least one number")
      .regex(/[\W_]/, "Password must contain at least one special character"),
    ConfirmPassword: z.string(),
  })
  .refine((data) => data.Password === data.ConfirmPassword, {
    message: "Passwords do not match",
    path: ["ConfirmPassword"],
  });

export const forgotPasswordSchema = z.object({
  Email: z.string().email("Invalid email address"),
});
