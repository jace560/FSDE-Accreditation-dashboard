import * as XLSX from "xlsx";
import { z } from "zod";
import {
  Semester,
  CourseInformationSheet,
  CourseCreateInput,
  AssessmentTools,
  AssessmentToolLearningObjectiveMapping,
  LearningObjective,
  LearningObjectivePerformanceIndicatorMapping,
  StudentGrade,
  GradeRequestDto,
} from "../types";
import { v4 as uuid4 } from "uuid";
import { useGetCourseMappingDetailsQuery } from "@/redux/api/courses";
import { GradeRequestSchema } from ".";

function getGraduateAttributes(worksheet: XLSX.WorkSheet, searchTerm: string) {
  const result: Record<string, { fullName: string; PIlevel: string }> = {};

  let startCol: string | null = null;
  let startRow: number | null = null;

  for (const cellAddress in worksheet) {
    if (cellAddress[0] === "!") continue;

    if (worksheet[cellAddress]?.v === searchTerm) {
      startCol = cellAddress.match(/[A-Z]+/)![0];
      startRow = parseInt(cellAddress.match(/\d+/)![0]) - 1;
      break;
    }
  }

  if (!startCol || !startRow) return result;

  const endCol = String.fromCharCode(startCol.charCodeAt(0) + 11);
  const endRow = startRow + 3;

  for (
    let colCode = startCol.charCodeAt(0);
    colCode <= endCol.charCodeAt(0);
    colCode++
  ) {
    const colLetter = String.fromCharCode(colCode);
    const values: any[] = [];

    for (let row = startRow; row <= endRow; row++) {
      const cellAddress = `${colLetter}${row}`;
      const cellVal = worksheet[cellAddress]?.v ?? "";
      values.push(cellVal);
    }

    const [id, shortName, fullName, PIlevel] = values;

    if (id && PIlevel !== "") {
      result[id] = {
        fullName,
        PIlevel,
      };
    }
  }

  return result;
}

function getLearningObjectives(worksheet: XLSX.WorkSheet) {
  const result: LearningObjective[] = [];

  let startCol: string | null = null;
  let startRow: number | null = null;

  for (const cellAddress in worksheet) {
    if (cellAddress[0] === "!") continue;

    if (worksheet[cellAddress]?.v === "LO 1") {
      startCol = cellAddress.match(/[A-Z]+/)![0];
      startRow = parseInt(cellAddress.match(/\d+/)![0]);
      break;
    }
  }

  if (!startCol || !startRow) return result;

  const descriptionCol = String.fromCharCode(startCol.charCodeAt(0) + 1);
  const piMappingCol = String.fromCharCode(startCol.charCodeAt(0) + 13);

  for (let row = startRow; row <= startRow + 19; row++) {
    const loNumber = worksheet[`${startCol}${row}`]?.v;
    const description = worksheet[`${descriptionCol}${row}`]?.v;
    const loToPi = worksheet[`${piMappingCol}${row}`]?.v;

    if (loNumber && loToPi) {
      const piMappings = loToPi.split(",").map(
        (pi: string): LearningObjectivePerformanceIndicatorMapping => ({
          PIName: pi.trim(),
        })
      );

      if (piMappings.length > 0) {
        result.push({
          LOName: loNumber,
          LearningObjectivePerformanceIndicatorMappings: piMappings,
          LODescription: description || "",
        });
      }
    }
  }

  return result;
}

function getAssessmentTools(worksheet: XLSX.WorkSheet) {
  const result: AssessmentTools[] = [];

  let startCol: string | null = null;
  let startRow: number | null = null;

  for (const cellAddress in worksheet) {
    if (cellAddress[0] === "!") continue;

    if (worksheet[cellAddress]?.v === "AT 1") {
      startCol = cellAddress.match(/[A-Z]+/)![0];
      startRow = parseInt(cellAddress.match(/\d+/)![0]);
      break;
    }
  }

  if (!startCol || !startRow) return result;

  const startCode = startCol.charCodeAt(0);
  const endCode = startCode + 14;
  const endRow = startRow + 15;

  for (let row = startRow; row <= endRow; row++) {
    const atNumber = worksheet[`${startCol}${row}`]?.v;

    if (atNumber && atNumber.startsWith("AT")) {
      let description = "";
      let weight = 0;
      const atToLo: AssessmentToolLearningObjectiveMapping[] = [];

      for (let colCode = startCode; colCode <= endCode; colCode++) {
        const colLetter = String.fromCharCode(colCode);
        const cellValue = worksheet[`${colLetter}${row}`]?.v;

        if (colCode === startCode + 1) {
          description = cellValue || "";
        } else if (colCode === startCode + 4) {
          weight = normalizeWeight(cellValue);
          console.log(weight, "WEIGHT");
        } else if (colCode > startCode + 2) {
          if (cellValue) {
            let loWeight = normalizeWeight(cellValue);

            if (loWeight > 0) {
              atToLo.push({
                LOName: `LO ${colCode - startCode - 4}`,
                Weight: loWeight,
              });
            }
          }
        }
      }

      if (weight > 0) {
        result.push({
          ATName: atNumber,
          Weight: weight,
          Description: description,
          AssessmentToolLearningObjectiveMappings: atToLo,
        });
      }
    }
  }

  return result;
}

function getCourseName(worksheet: XLSX.WorkSheet): string | undefined {
  for (const cellAddress in worksheet) {
    if (cellAddress[0] === "!") continue;

    if (worksheet[cellAddress]?.v === "Course Name") {
      const currentCol = cellAddress.match(/[A-Z]+/)![0];
      const row = cellAddress.match(/\d+/)![0];
      const targetCol = String.fromCharCode(currentCol.charCodeAt(0) + 2);
      const targetCell = `${targetCol}${row}`;

      return worksheet[targetCell]?.v;
    }
  }

  return undefined;
}

export function parseExcelToCourseInformationSheetType(
  programId: string,
  campusId: string,
  _: string,
  buffer: ArrayBuffer,
  showSuccessToast: (message: string) => void,
  showErrorToast: (message: string) => void
): CourseInformationSheet[] {
  const workbook = XLSX.read(buffer, { type: "buffer" });

  // Ensure there's exactly one sheet
  if (workbook.SheetNames.length === 0) {
    showErrorToast("The uploaded Excel file cannot be empty.");
    throw new Error("The uploaded Excel file cannot be empty.");
  }

  return workbook.SheetNames.map((sheetName, index) => {
    const worksheet = workbook.Sheets[sheetName];

    const GA = getGraduateAttributes(worksheet, "KB");
    const LO = getLearningObjectives(worksheet);
    const AT = getAssessmentTools(worksheet);

    const courseNumber = worksheet["M3"]?.v;
    let courseSection: string | undefined;
    let baseCourseNumber = courseNumber;

    if (
      courseNumber &&
      typeof courseNumber === "string" &&
      courseNumber.includes("-")
    ) {
      const [baseNumber, sectionNum] = courseNumber.split("-");
      courseSection = sectionNum;
      baseCourseNumber = baseNumber;
    }

    const courseData: CourseCreateInput = {
      CourseCode: baseCourseNumber,
      CourseName: getCourseName(worksheet) || "",
      SemesterName: worksheet["M5"]?.v || "",
      SectionNumber: parseInt(courseSection || "1"),
      Year: worksheet["M4"]?.v || "",
      AssessmentTools: AT,
      LearningObjectives: LO,
    };

    console.log(LO, "LEARNING OBJECTOVES");

    const result = {
      Course: courseData,
      ProgramID: programId,
      CampusID: campusId,
    };
    validateData(result, [`CourseInformationSheet[${index}]`]);
    showSuccessToast("Data extracted and parsed successfully");

    return result;
  });
}

export function parseSingleSheetExcelToCourseInformation(
  programId: string,
  campusId: string,
  _: string,
  buffer: ArrayBuffer,
  showSuccessToast: (message: string) => void,
  showErrorToast: (message: string) => void
): CourseInformationSheet | undefined {
  try {
    const workbook = XLSX.read(buffer, { type: "buffer" });

    // Ensure there's exactly one sheet
    if (workbook.SheetNames.length !== 1) {
      showErrorToast(
        '"The uploaded Excel file must contain exactly one sheet."'
      );
      throw new Error(
        "The uploaded Excel file must contain exactly one sheet."
      );
    }

    const sheetName = workbook.SheetNames[0]; // Get the single sheet
    const worksheet = workbook.Sheets[sheetName];

    console.log(programId, campusId, "PROGRAM CAMPUS ID - SINGLE SHEET");

    const GA = getGraduateAttributes(worksheet, "KB");
    const LO = getLearningObjectives(worksheet);
    const AT = getAssessmentTools(worksheet);

    const courseNumber = worksheet["M3"]?.v;
    let courseSection: string | undefined;
    let baseCourseNumber = courseNumber;

    if (
      courseNumber &&
      typeof courseNumber === "string" &&
      courseNumber.includes("-")
    ) {
      const [baseNumber, sectionNum] = courseNumber.split("-");
      courseSection = sectionNum;
      baseCourseNumber = baseNumber;
    }

    const courseData: CourseCreateInput = {
      CourseCode: baseCourseNumber,
      CourseName: getCourseName(worksheet) || "",
      SemesterName: worksheet["M5"]?.v || "",
      SectionNumber: parseInt(courseSection || "1"),
      Year: worksheet["M4"]?.v || "",
      AssessmentTools: AT,
      LearningObjectives: LO,
    };

    const result = {
      Course: courseData,
      ProgramID: programId,
      CampusID: campusId,
    };

    validateData(result, [`CourseInformationSheet`]);
    showSuccessToast("Data extracted and parsed successfully");
    // console.log(result, "RESULT");
    return result;
  } catch (error: any) {
    console.log(error);
    // showErrorToast(error);
  }
}

export const extractCourseInformstionFromExcel = (
  workbook: XLSX.WorkBook,
  sheetName: string,
  index: number,
  programId: string,
  campusId: string
) => {
  const worksheet = workbook.Sheets[sheetName];

  const GA = getGraduateAttributes(worksheet, "KB");
  const LO = getLearningObjectives(worksheet);
  const AT = getAssessmentTools(worksheet);

  const courseNumber = worksheet["M3"]?.v;
  let courseSection: string | undefined;
  let baseCourseNumber = courseNumber;

  if (
    courseNumber &&
    typeof courseNumber === "string" &&
    courseNumber.includes("-")
  ) {
    const [baseNumber, sectionNum] = courseNumber.split("-");
    courseSection = sectionNum;
    baseCourseNumber = baseNumber;
  }

  const courseData: CourseCreateInput = {
    CourseCode: baseCourseNumber,
    CourseName: getCourseName(worksheet) || "",
    SemesterName: worksheet["M5"]?.v || "",
    SectionNumber: parseInt(courseSection || "1"),
    Year: worksheet["M4"]?.v || "",
    AssessmentTools: AT,
    LearningObjectives: LO,
  };

  const result = {
    Course: courseData,
    ProgramID: programId,
    CampusID: campusId,
  };
  validateData(result, [`CourseInformationSheet[${index}]`]);

  return result;
};

// Validate course data to ensure it adheres to the defined types and constraints
const validateData = (data: any, path: string[] = []): void => {
  if (data === null || data === undefined || data === "") {
    throw new Error(
      `Validation error at ${path.join(
        "."
      )}: Value cannot be null, undefined, or an empty string.`
    );
  }

  if (typeof data === "object" && !Array.isArray(data)) {
    if (path.length === 0 && data.Course) {
      // Validate Course structure
      const {
        CourseCode,
        CourseName,
        SemesterName,
        SectionNumber,
        Year,
        AssessmentTools,
        LearningObjectives,
      } = data.Course;
      if (typeof CourseCode !== "string" || CourseCode.trim() === "") {
        throw new Error(
          `Validation error at Course.CourseCode: Must be a non-empty string.`
        );
      }
      if (typeof CourseName !== "string" || CourseName.trim() === "") {
        throw new Error(
          `Validation error at Course.CourseName: Must be a non-empty string.`
        );
      }
      if (typeof SemesterName !== "string" || SemesterName.trim() === "") {
        throw new Error(
          `Validation error at Course.SemesterName: Must be a non-empty string.`
        );
      }
      if (typeof SectionNumber !== "number" || isNaN(SectionNumber)) {
        throw new Error(
          `Validation error at Course.SectionNumber: Must be a valid number.`
        );
      }
      if (typeof Year !== "string" || Year.trim() === "") {
        throw new Error(
          `Validation error at Course.Year: Must be a non-empty string.`
        );
      }
      if (!Array.isArray(AssessmentTools)) {
        throw new Error(
          `Validation error at Course.AssessmentTools: Must be an array.`
        );
      }
      if (!Array.isArray(LearningObjectives)) {
        throw new Error(
          `Validation error at Course.LearningObjectives: Must be an array.`
        );
      }
    }

    Object.entries(data).forEach(([key, value]) =>
      validateData(value, [...path, key])
    );
  } else if (Array.isArray(data)) {
    data.forEach((item, index) => validateData(item, [...path, `[${index}]`]));
  } else {
    if (typeof data === "string" && data.trim() === "") {
      throw new Error(
        `Validation error at ${path.join(".")}: String cannot be empty.`
      );
    }
    if (typeof data === "number" && isNaN(data)) {
      throw new Error(
        `Validation error at ${path.join(".")}: Number cannot be NaN.`
      );
    }
  }
};

function normalizeWeight(cellValue: any): number {
  if (!cellValue) return 0; // Handle empty values

  let weightStr = cellValue.toString().trim();
  let weight = 0;
  let hadPercentage = weightStr.includes("%"); // Check if the original input had %

  if (hadPercentage) {
    // Remove '%' and parse as float (Excel already converts percentages to decimals)
    weight = parseFloat(weightStr.replace("%", "").trim());
  } else {
    // Convert to float
    let numericWeight = parseFloat(weightStr);
    if (!isNaN(numericWeight)) {
      // If Excel auto-converted, correct it (only if there was NO % originally)
      weight = numericWeight < 1 ? numericWeight * 100 : numericWeight;
    }
  }

  return weight;
}

interface ExtractGradesProps {
  buffer: ArrayBuffer;
  courseID: string;
  programID: string;
  campusID: string;
}

type ExcelRow = (string | number | undefined)[];
/**
 * Extracts grades from an Excel file following the provided column structure.
 *
 * @param {ExtractGradesProps} props - Contains buffer, courseID, programID, and campusID.
 * @returns {GradeRequestDto} - Extracted grades in a structured format.
 *
 */

export function extractGradesFromExcel(
  programID: string,
  campusID: string,
  courseID: string,
  buffer: ArrayBuffer,
  showSuccessToast: (message: string) => void,
  showErrorToast: (message: string) => void
): StudentGrade[] {
  try {
    console.log("Buffer First Bytes:", new Uint8Array(buffer).slice(0, 20));

    // Read workbook from buffer
    const workbook = XLSX.read(new Uint8Array(buffer), { type: "buffer" });

    // Validate that only one sheet exists
    if (workbook.SheetNames.length === 0) {
      throw new Error("No sheets found in the provided Excel file.");
    }

    if (workbook.SheetNames.length > 1) {
      throw new Error("The uploaded file should contain only one sheet.");
    }

    console.log("Available Sheets:", workbook.SheetNames);

    // Select the first (and only) sheet
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];

    console.log("Sheet Name:", sheetName);
    console.log("Worksheet Object:", worksheet);
    console.log("Worksheet Range:", worksheet["!ref"]);

    // Convert sheet to JSON
    const sheetData = XLSX.utils.sheet_to_json<{ [key: string]: unknown }>(
      worksheet,
      { header: 1 }
    );

    if (sheetData.length === 0) {
      throw new Error("No data found in the Excel sheet.");
    }

    if (sheetData.length < 3) {
      console.error("Parsed sheet data is too short:", sheetData);
      throw new Error("Insufficient data in the Excel sheet.");
    }

    // Extract headers from the first row
    const headers = sheetData[0] as unknown as string[];

    const normalizedHeaders = headers.map((h) =>
      h.split("-")[0].trim().toUpperCase()
    );

    // Identify assessment tool (AT) columns
    const assessmentColumns = normalizedHeaders
      .map((header, index) => ({ name: header, index }))
      .filter(({ name }) => name.includes("AT"))
      .reduce((acc: { name: string; index: number }[], current) => {
        const existingIndex = acc.findIndex(
          ({ name }) => name === current.name
        );
        if (existingIndex !== -1) {
          acc[existingIndex] = current;
        } else {
          acc.push(current);
        }
        return acc;
      }, []);

    if (assessmentColumns.length === 0) {
      throw new Error(
        "No assessment tool (AT) columns found in the Excel sheet."
      );
    }

    const gradesList: StudentGrade[] = [];

    for (let i = 1; i < sheetData.length; i++) {
      const row = sheetData[i] as unknown as ExcelRow;

      if (!row) continue; // Skip empty rows

      const studentId = uuid4();
      console.log(`Processing Student: ${studentId}`);

      const studentGrades = assessmentColumns
        .map(({ name, index }) => {
          const cellValue = row[index];

          if (
            cellValue === undefined ||
            cellValue === null ||
            cellValue === "" ||
            isNaN(Number(cellValue))
          ) {
            return undefined;
          }

          const gradeValue = parseFloat(
            String(cellValue).replace("%", "").trim()
          );

          return {
            ATName: name,
            GradePercentage: gradeValue < 1 ? gradeValue * 100 : gradeValue,
          };
        })
        .filter(
          (grade): grade is { ATName: string; GradePercentage: number } =>
            grade !== undefined
        );

      if (studentGrades.length === 0) {
        console.error(`No grades found for student ${studentId}`);
        continue;
      }

      gradesList.push({
        StudentIdentifier: studentId,
        Grades: studentGrades,
      });
    }

    console.log(
      "Final Extracted Grades List:",
      JSON.stringify(gradesList, null, 2)
    );

    // Validate extracted data using Zod
    const validationResult = GradeRequestSchema.safeParse({
      programID,
      courseID,
      campusID,
      studentGradeSheet: gradesList,
    });

    if (!validationResult.success) {
      console.error("Validation Error:", validationResult.error.format());
      showErrorToast("Invalid data format in extracted grades.");
      throw new Error("Extracted grades data is invalid.");
    }

    showSuccessToast("Grades extracted successfully!");
    return gradesList;
  } catch (error) {
    console.error("Error extracting grades:", error);
    showErrorToast(
      error instanceof Error ? error.message : "An unknown error occurred."
    );
    return [];
  }
}
