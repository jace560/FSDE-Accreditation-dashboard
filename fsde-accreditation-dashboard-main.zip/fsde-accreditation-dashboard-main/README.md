### **Setting Up the Repository**

#### **Prerequisites**

1. **Install Docker Desktop**

   - Download and install [Docker Desktop](https://www.docker.com/products/docker-desktop) based on your operating system (Windows or Mac).

2. **Install VS Code**

   - Download and install [Visual Studio Code](https://code.visualstudio.com/).

3. **Install Node.js**
   - Ensure Node.js is installed on your machine. You can download it [here](https://nodejs.org/).

---

#### **Steps to Set Up the Repository**

1. **Generate a GitHub Token**

   - Create a personal access token on GitHub:
     - Navigate to **Settings > Developer Settings > Personal Access Tokens > Tokens (classic)**.
     - Generate a token with appropriate permissions.
   - Keep this token secure, as you'll need it for authentication when cloning the repository.

2. **Clone the Repository**

   - Clone the main branch of the repository using your GitHub token:
     ```bash
     git clone https://<your-github-username>:<your-github-token>@github.com/charles-akintunde/fsde-accreditation-dashboard.git
     ```
   - Navigate into the repository folder:
     ```bash
     cd <repository-folder>
     ```

3. **Add a `.env` File**

   - In the `server` folder, create a file named `.env` and add the following content:
     ```plaintext
     DATABASE_URL=postgresql://fsde_user:fsde_password@localhost:5432/fsde_db
     ```

4. **Install Docker Containers for the Database**

   - From the root of the repository folder, build and start the Docker containers (database only):
     ```bash
     docker-compose up --build
     ```

5. **Enter the Server Directory**

   - Navigate to the `server` folder:
     ```bash
     cd server
     ```

6. **Install Dependencies**

   - Install the required Node.js packages:
     ```bash
     npm ci
     ```

7. **Run Prisma Migrations**

   - Apply the existing Prisma migrations to configure the database:
     ```bash
     npx prisma migrate dev
     ```

8. **Generate Prisma Client**

   - Generate the Prisma client:
     ```bash
     npx prisma generate
     ```

9. **Reset the Database and seed data**

   - Populate the database with initial data:
     ```bash
     npx prisma migrate reset
     ```

10. **Run the Application**

    - Start the application locally:
      ```bash
      npm run dev
      ```

11. **Verify Setup**
    - Test the API by visiting: `http://localhost:3000/api/test-db`. If you see JSON data, the API is correctly set up.
    - Access the application by visiting: `http://localhost:3000`. If you see the app running (recommend using Edge browser), then the setup is complete.

---

#### **Troubleshooting**

1. **Clear the Database in Case of Conflicts**

   - If there are conflicts in the database, clear it by resetting Prisma migrations:
     ```bash
     npx prisma migrate reset
     ```
   - This command will:
     - Drop all data.
     - Recreate the database schema from scratch.
     - Optionally, re-seed the database.

2. **Rebuild Docker Containers**

   - If the issue persists, rebuild Docker containers:
     ```bash
     docker-compose down --volumes
     docker-compose up --build
     ```

3. **Check for Outdated Dependencies**

   - Ensure all dependencies are up-to-date:
     ```bash
     npm install
     ```

4. **Inspect Docker Logs**
   - View logs for troubleshooting Docker-related issues:
     ```bash
     docker logs <container-id>
     ```

---
